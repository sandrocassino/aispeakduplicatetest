import { blue, inputRed, lightBlue, veryLightRed, textGray } from "../constants";

export const useInputStyles = ({
  activeField,
  nameError = "",
  emailError = "",
  passwordError = "",
  styles,
}) => {

const getInputStyle = (fieldName) => {
  // Don't show error style while the field is active/focused
  const isError =
    (fieldName === "name" && nameError) ||
    (fieldName === "email" && emailError) ||
    (fieldName === "password" && passwordError);

  if (isError && fieldName !== activeField) {
    return [
      styles.inputWrapperYellow,
      { borderColor: inputRed, borderWidth: 1, backgroundColor: veryLightRed },
    ];
  }

  // Active field style
  if (fieldName === activeField) {
    return [
      styles.inputWrapperYellow,
      { borderColor: blue, borderWidth: 1, backgroundColor: lightBlue },
    ];
  }

  // Default style
  return [styles.inputWrapperYellow];
};

  const getIconColor = (fieldName) => {
    if (fieldName === activeField) return blue;

    if (
      (fieldName === "name" && nameError) ||
      (fieldName === "email" && emailError) ||
      (fieldName === "password" && passwordError)
    ) {
      return inputRed;
    }

    return textGray;
  };

  return { getInputStyle, getIconColor };
};