import React, {
  useState,
  useRef,
  useMemo,
  useEffect,
  useCallback,
} from "react";
import * as ScreenOrientation from "expo-screen-orientation";
import * as Notifications from "expo-notifications";
import * as ImagePicker from "expo-image-picker";
import { createClient } from "@supabase/supabase-js";
import "react-native-url-polyfill/auto";
import {
  AppState,
  View,
  Image,
  Text,
  StyleSheet,
  TouchableOpacity,
  PanResponder,
  TextInput,
  ScrollView,
  TouchableWithoutFeedback,
  PixelRatio,
  Platform,
  Keyboard,
  Alert,
  Animated,
  Dimensions,
  Linking,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import styles from "./Styles";
import "react-native-gesture-handler";
import ChatScreen from "./screens/Chat/ChatScreen";
import SubscriptionScreen from "./screens/Subscription/SubscriptionScreen";
import HomeScreen from "./HomeScreen";
import MyProgressScreen from "./screens/MyProgress/MyProgressScreen";
import SettingsScreen from "./SettingsScreen";
import OnboardingScreens from "./screens/Onboarding/OnboardingScreens";
import LegalScreens from "./LegalScreens";
import RegisterScreen from "./screens/LoginAndRegister/RegisterScreen";
import ProfilePage from "./ProfilePage";
import LoginScreen from "./screens/LoginAndRegister/LoginScreen";
import Purchases from "react-native-purchases";
import IntroScreen from "./screens/IntroScreen";
import LevelSelectionScreen from "./screens/LevelSelectionScreen";
import NameInputScreen from "./screens/NameInputScreen";
import ProfilePromptScreen from "./screens/ProfilePromptScreen";
import NotificationPromptScreen from "./screens/NotificationPromptScreen";
import LevelOverviewScreen from "./screens/LevelOverviewScreen";
import ForgotPasswordPage from "./screens/LoginAndRegister/ForgotPasswordPage";
import Styles from "./Styles";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { Provider as PaperProvider } from "react-native-paper";
import { dark } from "./constants";
import * as Font from "expo-font";
import ChangePasswordEmail from "./screens/LoginAndRegister/ChangePasswordEmail";
import supabase from "./supabaseClient";
import { useFonts } from "expo-font";
import {
  nunitoBlack,
  nunitoBold,
  nunito,
  sourceSansBold,
  sourceSans,
} from "./constants";

export default function App() {
  const [fontsLoaded] = useFonts({
    [nunitoBlack]: require("./assets/fonts/Nunito-Black.ttf"),
    [nunitoBold]: require("./assets/fonts/Nunito-Bold.ttf"),
    [nunito]: require("./assets/fonts/Nunito-Regular.ttf"),
    [sourceSansBold]: require("./assets/fonts/SourceSansPro-Bold.otf"),
    [sourceSans]: require("./assets/fonts/SourceSansPro-Regular.otf"),
  });
  const [onboardingLoaded, setOnboardingLoaded] = useState(false);

  useEffect(() => {
    const loadOnboarding = async () => {
      const value = await AsyncStorage.getItem("isOnboardingCompleted");
      if (value !== null) {
        setIsOnboardingCompleted(JSON.parse(value));
        setPage(JSON.parse(value) ? 7 : 1800);
      }
      setOnboardingLoaded(true);
    };
    loadOnboarding();
  }, []);

  useEffect(() => {
    console.log("Resetting name on app start");
    setName("");
  }, []);

  const [isTrialActive, setIsTrialActive] = useState(false);
  const [isMicEnabled, setMicEnabled] = React.useState(true);
  const [isMicEnabled2, setMicEnabled2] = React.useState(false);
  const [showImageOnPage7, setShowImageOnPage7] = useState(false);

  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [page, setPage] = useState(1);
  const [originPage, setOriginPage] = useState(null);
  const [previousPage, setPreviousPage] = useState(null);
  const [currentScreen, setCurrentScreen] = useState(null);

  const [loginFlowSource, setLoginFlowSource] = useState(null); // To control from which flow is opened LoginScreen.js

  const handleSetPage = (newPage, origin = null) => {
    if (origin !== null) {
      setOriginPage(origin);
    }
    setPage(newPage);
  };
  const [showImage5] = useState(true);
  const [showImage, setShowImage] = useState(false);
  const [showText, setShowText] = useState(false);
  const [showText2, setShowText2] = useState(false);
  const [showText73, setShowText73] = useState(false);
  const [showFinger, setShowFinger] = useState(false);
  const [currentPlan, setCurrentPlan] = useState("Básico"); // User's current plan
  const [currentBillingCycle, setCurrentBillingCycle] = useState("Anual"); // User's current billing cycle
  const [selectedPlan, setSelectedPlan1] = useState(currentPlan);
  const [isSubscribing, setIsSubscribing] = useState(false);

  const [selectedBillingCycle, setSelectedBillingCycle] =
    useState(currentBillingCycle);
  const planDetails = {
    Básico: {
      Mensual: {
        price: "€7.99/",
        cycle: "mes",
      },
      Anual: {
        price: "€69.99/",
        cycle: "año",
      },
      features: [
        "Texto, habla y escucha. ¡Hazlo todo!",
        "Chatea con Aispeak a cualquier nivel",
        "10 chats cada día",
      ],
    },
    Pro: {
      Mensual: {
        price: "€11.99/",
        cycle: "mes",
      },
      Anual: {
        price: "€94.99/",
        cycle: "año",
      },
      features: [
        "Texto, habla y escucha. ¡Hazlo todo!",
        "Chatea con Aispeak a cualquier nivel",
        "Chats ilimitados",
      ],
    },
  };

  const [alreadySelectedPlan, setAlreadySelectedPlan] = useState(false);
  onPress = () => {
    if (selectedBillingCycle) {
      setCurrentPlan(selectedPlan);
      setCurrentBillingCycle(selectedBillingCycle);

      if (!alreadySelectedPlan) {
        setAlreadySelectedPlan(true);
        setPage(7);
      } else {
        //change to page 7
        setPage(7); // Go to home or main screen for plan switch
      }
    } else {
      Alert.alert("Por favor, selecciona un ciclo de facturación");
    }
  };

  useEffect(() => {
    const initializePurchases = async () => {
      try {
        Purchases.configure({
          apiKey: "appl_ZCRKPqKkJXZKsKBndqNVenQETdi",
        });
        await inAppGetSubscriptions(); // Pre-fetch offerings for faster access
      } catch (e) {
        console.error("Failed to initialize purchases:", e);
      }
    };

    initializePurchases();
  }, []);

  // Function to fetch subscriptions (following docs pattern)
  const inAppGetSubscriptions = async () => {
    try {
      const offerings = await Purchases.getOfferings();
      console.log("Fetched offerings:", offerings.current);

      if (
        offerings.current !== null &&
        offerings.current.availablePackages.length !== 0
      ) {
        // Packages available for sale
        // console.log("Available packages:", offerings.current.availablePackages);
      } else {
        Alert.alert(
          "Error",
          "No offerings found. Verify your RevenueCat setup."
        );
      }
    } catch (error) {
      console.error("Error fetching offerings:", error);
      Alert.alert("Error", `Failed to get offerings: ${error.message}`);
    }
  };

  // Function to handle subscription purchase (following docs pattern)
  const inAppBuySubscription = async (selectedPlan) => {
    try {
      // Don't block purchase if already subscribed; allow crossgrade/upgrade/downgrade
      const offerings = await Purchases.getOfferings();

      // Only "Pro" plan is supported now
      const packageId = "pro";
      let fullPackageId =
        packageId + (selectedBillingCycle === "Mensual" ? "Monthly" : "Yearly");

      if (isTrialActive) {
        fullPackageId += "7free";
      }

      const packageToPurchase = offerings.current?.availablePackages.find(
        (pkg) => pkg.identifier === fullPackageId
      );

      if (!packageToPurchase) {
        throw new Error(
          `No ${selectedBillingCycle.toLowerCase()} package found for Pro plan`
        );
      }

      const { customerInfo: purchaseInfo } = await Purchases.purchasePackage(
        packageToPurchase
      );
      console.log("Purchase successful:", purchaseInfo);

      // Check if the purchase is active
      const entitlementsAfter = purchaseInfo.entitlements.active;
      const isActiveAfter = entitlementsAfter["pro"];

      if (isActiveAfter) {
        setCurrentPlan("Pro");
        setCurrentBillingCycle(selectedBillingCycle);

        if (!alreadySelectedPlan) {
          // setPage(4);
          setAlreadySelectedPlan(true);
          AsyncStorage.setItem("alreadySelectedPlan", JSON.stringify(true));
        }
        return true; // Indicate success
      } else {
        Alert.alert(
          "Suscripción no activada",
          "La compra no se activó correctamente. Inténtalo de nuevo."
        );
        return false;
      }
    } catch (error) {
      if (error.userCancelled) {
        Alert.alert("Compra cancelada", "No se realizó ningún cargo.");
      } else {
        console.error("Purchase error:", error);
        Alert.alert("Purchase Error", error.message);
      }
      return false;
    } finally {
      setIsSubscribing(false);
    }
  };

  const [testerUsed, setTesterUsed] = useState(false);
  const [, setTesterEndTime] = useState(null);
  // When the app is opened or navigated to this page, check:
  useEffect(() => {
    const checkTesterStatus = async () => {
      try {
        const used = await AsyncStorage.getItem("testerUsed");
        const endTime = await AsyncStorage.getItem("testerEndTime");
        const now = new Date().getTime();
        if (used === "true" && endTime) {
          const end = parseInt(endTime, 10);
          if (end <= now) {
            // Time expired, redirect again to 4000
            setTesterUsed(true);
            setPage(4000);
          } else {
            // If time has not expired, tester is active.
            setTesterUsed(true);
            setTesterEndTime(end);
          }
        } else {
          // Never used or not in storage
          setTesterUsed(false);
        }
      } catch (e) {
        console.log("Error reading tester status", e);
      }
    };
    checkTesterStatus();
  }, [page]); // You may want to recheck when 'page' changes.

  // This function runs when the 2-week button is pressed.
  const handleTesterButtonPress = async () => {
    try {
      // From now plus 14 days
      const now = new Date().getTime();
      const twoWeeksLater = now + 14 * 24 * 60 * 60 * 1000;
      // Give the user 2 weeks of Pro features
      setCurrentPlan("Pro");
      setCurrentBillingCycle("Mensual"); // Example: monthly Pro
      await AsyncStorage.setItem("testerUsed", "true");
      await AsyncStorage.setItem("testerEndTime", twoWeeksLater.toString());
      setTesterUsed(true);
      setTesterEndTime(twoWeeksLater);
      // After selecting the plan, redirect to page=4
      // setPage(4);
    } catch (e) {
      console.log("Error setting tester data", e);
    }
  };

  const [, setShowImages] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isregistered, setisregistered] = useState(false);
  const [isPopupVisible, setPopupVisible] = useState(false);
  const [chatKey, setChatKey] = useState(1);
  const [chatHistories, setChatHistories] = useState({});

  const addMessageToChatHistory = (message) => {
    setChatHistories((prevHistories) => ({
      ...prevHistories,
      [chatKey]: [...(prevHistories[chatKey] || []), message],
    }));
    setChatHistory((prevChatHistory) => [...prevChatHistory, message]);
  };

  const [chatHistory, setChatHistory] = useState([]);
  const [avatarKey, setAvatarKey] = useState("avatar1");
  const [avatarKey2, setAvatarKey2] = useState("avatar2");
  const [avatarKey3, setAvatarKey3] = useState("avatar3");

  const avatarImages = useMemo(
    () => ({
      avatar1: require("./assets/images/capy-in-white-circle.png"),
      avatar2: require("./assets/images/capy-with-hat-in-white-circle.png"),
      avatar3: require("./assets/images/capy-with-crown-in-white-circle.png"),
    }),
    []
  );

  useEffect(() => {
    const loadAvatars = async () => {
      try {
        const storedAvatarKey = await AsyncStorage.getItem("avatarKey");
        if (storedAvatarKey && avatarImages[storedAvatarKey]) {
          setAvatarKey(storedAvatarKey);
        }
        const storedAvatarKey2 = await AsyncStorage.getItem("avatarKey2");
        if (storedAvatarKey2 && avatarImages[storedAvatarKey2]) {
          setAvatarKey2(storedAvatarKey2);
        }
        const storedAvatarKey3 = await AsyncStorage.getItem("avatarKey3");
        if (storedAvatarKey3 && avatarImages[storedAvatarKey3]) {
          setAvatarKey3(storedAvatarKey3);
        }
      } catch (error) {
        console.log("Error loading avatar keys:", error);
      }
    };

    loadAvatars();
  }, [avatarImages]);

  const [isEmailEditable, setIsEmailEditable] = useState(false);
  const [isNameEditable, setIsNameEditable] = useState(false);
  // other state variables

  // Event handlers
  const [modal2Visible, setModal2Visible] = useState(false);
  const [modalCount, setModalCount] = useState(9);
  const [, setLevel2Locked] = useState(true);

  useEffect(() => {
    if (modalCount === 9 && modal2Visible) {
      const timer = setTimeout(() => {
        setModalCount(10);
        setLevel2Locked(false);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [modalCount, modal2Visible]);

  useEffect(() => {
    if (modal2Visible) {
      const timer = setTimeout(() => {
        setShowImages(true);
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setShowImages(false);
    }
  }, [modal2Visible]);

  const closeModal2 = () => {
    setModal2Visible(false);
  };

  // Add this new state variable
  const [hasModalBeenShown, setHasModalBeenShown] = useState(false);

  useEffect(() => {
    if (page === 820 && !hasModalBeenShown) {
      const timer = setTimeout(() => {
        setModal2Visible(true); // Open the modal after 3 seconds
        setHasModalBeenShown(true); // Set this to true so the modal won't be shown again
      }, 3000);

      return () => {
        clearTimeout(timer);
      };
    }
  }, [page, hasModalBeenShown]); // Add hasModalBeenShown to the dependency array

  const [showFinger2, setShowFinger2] = useState(false);
  const [showsecond, setShowsecond] = useState(false);
  const [showSecond2, setShowsecond2] = useState(false);
  const [showfifth, setShowfifth] = useState(false);
  const [showfirst, setShowfirst] = useState(false);
  const [showfirst2, setShowfirst2] = useState(false);
  const [showthird, setShowthird] = useState(false);
  const [showfourth, setShowfourth] = useState(false);
  const [firstVisit, setFirstVisit] = useState(true);
  const [showImage72, setShowImage72] = useState(false);
  const [showOk, setShowOk] = useState(true);
  const [showOkbutton, setShowOkbutton] = useState(true);

  // Add a new state variable for the blur effect
  const [blur, setBlur] = useState(10);
  const [showText72, setShowText72] = useState(false);
  const [profilePicture, setProfilePicture] = useState(null);

  const pickImage = async () => {
    if (Platform.OS !== "web") {
      const { status } =
        await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        alert("Sorry, we need camera roll permissions to make this work!");
        return;
      }
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result);

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setProfilePicture(uri);

      // Save profile picture URI to AsyncStorage
      AsyncStorage.setItem("profilePicture", uri);
    }
  };

  useEffect(() => {
    if (page === 7.2) {
      const timer = setTimeout(() => {
        setShowImage72(true);
        setShowText72(true);
        setShowFinger2(true);
      }, 500);

      return () => {
        clearTimeout(timer);
      };
    }
  }, [page]);

  useEffect(() => {
    if (page === 4000) {
      const checkSubscriptionStatus = async () => {
        // Connect to the payment queue
        await InAppPurchases.connectAsync();

        // Get the purchase history
        const { results } = await InAppPurchases.getPurchaseHistoryAsync();

        // Check if there's an active subscription
        const hasActiveSubscription = results.some((purchase) => {
          // Check if the purchase is a subscription and is still valid
          return (
            purchase.productId === "your_subscription_id" &&
            purchase.acknowledged
          );
        });

        if (hasActiveSubscription) {
          // If the user has an active subscription, perform the desired action
          setPage(7);
        }
      };

      checkSubscriptionStatus();
    }
  }, [page]);

  useEffect(() => {
    if (page === 4) {
      const timer = setTimeout(() => {
        setShowImage(true);
        setShowText(true);
        setShowFinger(true);
      }, 1000);

      return () => {
        clearTimeout(timer);
      };
    }
  }, [page]);

  useEffect(() => {
    if (page === 7 && firstVisit) {
      const timer = setTimeout(() => {
        setFirstVisit(false);
        setPage(7.2);
      }, 2000);
      return () => {
        clearTimeout(timer);
      };
    }
  }, [page, firstVisit]);

  const [, setShowArrow] = useState(false);
  const [, setClickCount] = useState(0);
  const [, setShowContent] = useState(false);
  const [showContent2, setShowContent2] = useState(false);
  const [name, setName] = useState("");
  const [profileName, setProfileName] = useState(""); // Name state for Profile Page name, to avoid global setting of name and clean name input on Mock Chat
  const [shouldLoadMessages, setShouldLoadMessages] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [chats, setChats] = useState([1]); // Add this line
  const [textColor, setTextColor] = useState(dark); // Default text color
  const [makeUserWant, setMakeUserWant] = useState(false);
  const popAnim = useRef(new Animated.Value(0)).current; // Initial value for opacity: 0

  useEffect(() => {
    if (page === 4000) {
      console.log("Page is 7, setting timer...");
      const timer = setTimeout(() => {
        console.log("Timer triggered, updating state...");
        setTextColor("rgba(0, 0, 0, 0)");
        setMakeUserWant(true);
        Animated.sequence([
          Animated.timing(popAnim, {
            toValue: 1.2, // Scale up to 1.2 times the original size
            duration: 400,
            useNativeDriver: true,
          }),
          Animated.timing(popAnim, {
            toValue: 1, // Scale back to the original size
            duration: 200,
            useNativeDriver: true,
          }),
        ]).start();
      }, 6000);

      // Cleanup the timer if the component unmounts or page changes
      return () => {
        console.log("Cleaning up timer...");
        clearTimeout(timer);
      };
    }
  }, [page, popAnim]);

  useEffect(() => {
    // Lock the screen orientation to portrait mode
    const lockOrientation = async () => {
      await ScreenOrientation.lockAsync(
        ScreenOrientation.OrientationLock.PORTRAIT_UP
      );
    };

    lockOrientation();
  }, []);

  const supabaseUrl = "https://ojcsvhfkvajrpjwdvbkc.supabase.co";
  const supabaseAnonKey =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9qY3N2aGZrdmFqcnBqd2R2YmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc3NDIxNDcsImV4cCI6MjAyMzMxODE0N30.MrjI-nWf70wZJSmvRMEK9qjEz_Iv_9qGhLp82SzvRSE";
  const supabase = createClient(supabaseUrl, supabaseAnonKey);

  const [userId, setUserId] = useState(null);

  const saveToSupabase = useCallback(async () => {
    if (!userId) {
      console.error("Error: userId is undefined");
      return; // Skip if no user is logged in
    }

    console.log("Updating data for userId: ", userId); // Log the userId
    console.log("Current state: ", {
      // Log the current state
      isOnboardingCompleted,
      currentCountPrincipiante,
      currentCountIntermedio,
      currentCountAvanzado,
      isMicEnabled,
      currentChatKey,
      isMicEnabled2,
      selectedOption,
      email,
      name,
      firstVisit,
      currentCount,
      chatHistory,
      questionMarkShown,
      trialChatCount,
      isTimeoutActive,
      currentLevel,
      chatKey,
      chats,
      firstTimeModal,
      currentPlan,
      currentBillingCycle,
      isLoggedIn,
    });

    const { error } = await supabase
      .from("users")
      .update({
        isOnboardingCompleted: isOnboardingCompleted,
        currentCountPrincipiante: currentCountPrincipiante,
        currentCountIntermedio: currentCountIntermedio,
        currentCountAvanzado: currentCountAvanzado,
        isMicEnabled: isMicEnabled,
        currentChatKey: currentChatKey,
        isMicEnabled2: isMicEnabled2,
        selectedOption: selectedOption,
        email: email,
        name: name,
        firstVisit: firstVisit,
        currentCount: currentCount,
        chatHistory: chatHistory,
        firstTimeModal: firstTimeModal,
        questionMarkShown: questionMarkShown,
        trialChatCount: trialChatCount,
        isTimeoutActive: isTimeoutActive,
        currentLevel: currentLevel,
        chatKey: chatKey,
        chats: chats,
        currentPlan: currentPlan,
        currentBillingCycle: currentBillingCycle,
      })
      .eq("auth_id", userId);

    if (error) {
      console.log("Error saving data: ", error);
    } else {
      console.log("Data saved successfully");
    }
  }, [
    userId,
    supabase,
    isOnboardingCompleted,
    currentCountPrincipiante,
    currentCountIntermedio,
    currentCountAvanzado,
    isMicEnabled,
    currentChatKey,
    isMicEnabled2,
    selectedOption,
    email,
    name,
    firstVisit,
    firstTimeModal,
    chatHistory,
    questionMarkShown,
    trialChatCount,
    isTimeoutActive,
    currentCount,
    currentLevel,
    chatKey,
    chats,
    currentPlan,
    currentBillingCycle,
  ]);

  useEffect(() => {
    if (isLoggedIn && userId) {
      const timer = setTimeout(() => {
        saveToSupabase();
      }, 10000); // 10000 milliseconds = 10 seconds

      return () => clearTimeout(timer); // Clear the timer if the component unmounts
    }
  }, [isLoggedIn, userId, saveToSupabase]);
  const [billingCycle, setBillingCycle] = useState("Mensual"); // Default to Yearly
  useEffect(() => {
    if (page === 7 && isregistered) {
      setYouHaveRegistered(true);

      // Hide the view after 10 seconds
      const timer = setTimeout(() => {
        setYouHaveRegistered(false);
        setisregistered(false);
      }, 2000); // 10 seconds

      // Cleanup the timer if the component unmounts
      return () => clearTimeout(timer);
    }
  }, [page, isregistered]);

  const [passwordError, setPasswordError] = useState(""); // State to hold the password error message
  const [currentChatKey, setCurrentChatKey] = useState(0); // Track the current chat key for new chats

  //SIGN UP FUNCTION

  const signUp = async (email, password, registrationName, options = {}) => {
    const { from, onSuccess, navigateAfterSignup = true } = options;

    const { user, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name: registrationName, // ✅ stored in user_metadata
        },
      },
    });

    if (error) {
      console.error("Error creating user account", error);
      setLoginError("Error creating user account");
      return;
    }

    if (!user || !user.id) {
      setName(registrationName);
      setTimeout(() => {
        console.log("Running post-signup navigation...");

        if (typeof onSuccess === "function") {
          onSuccess();
        } else if (navigateAfterSignup) {
          setPage(7);
          setIsLoggedIn(true);
        }
      }, 1500);

      return;
    }

    setTimeout(() => {
      console.log("Running delayed navigation...");
      setPage(7);
      setIsLoggedIn(true);
    }, 1500);
  };

  supabase.auth.onAuthStateChange(async (event, session) => {
    if (event !== "SIGNED_IN") return;

    const user = session.user;
    console.log("✅ SIGNED_IN: Setting userId:", user.id);
    setUserId(user.id);

    try {
      // Fetch user data from Supabase
      const { data, error } = await supabase
        .from("users")
        .select(
          `
        auth_id,
        email,
        name,
        currentCount,
        currentCountPrincipiante,
        currentCountIntermedio,
        currentCountAvanzado,
        currentChatKey,
        isMicEnabled,
        isMicEnabled2,
        selectedOption,
        firstVisit,
        firstTimeModal,
        chatHistory,
        questionMarkShown,
        trialChatCount,
        isTimeoutActive,
        currentLevel,
        chatKey,
        chats,
        currentPlan,
        currentBillingCycle,
        isOnboardingCompleted
      `
        )
        .eq("auth_id", user.id)
        .single();

      if (error && error.code === "PGRST116") {
        // Row not found — create a new one
        console.log("ℹ️ No user found, inserting new row.");
        const { error: insertError } = await supabase
          .from("users")
          .insert([{ auth_id: user.id, email: user.email, currentCount: 1 }]);

        if (insertError) {
          console.error("❌ Error inserting user row:", insertError);
        } else {
          console.log("✅ New user row inserted.");
        }
      } else if (error) {
        // Fetch error (but row exists)
        console.error("❌ Error fetching user data:", error);
      } else {
        // Row exists and was fetched
        console.log("✅ User data fetched:", data);

        // Set state from Supabase row
        setCurrentCount(data.currentCount);
        setIsOnboardingCompleted(data.isOnboardingCompleted);
        setCurrentCountPrincipiante(data.currentCountPrincipiante);
        setCurrentCountIntermedio(data.currentCountIntermedio);
        setCurrentCountAvanzado(data.currentCountAvanzado);
        setMicEnabled(data.isMicEnabled);
        setCurrentChatKey(data.currentChatKey);
        setMicEnabled2(data.isMicEnabled2);
        setSelectedOption(data.selectedOption);
        setEmail(data.email);
        setProfileName(data.name);
        setFirstVisit(data.firstVisit);
        setFirstTimeModal(data.firstTimeModal);
        setChatHistory(data.chatHistory);
        setQuestionMarkShown(data.questionMarkShown);
        setTrialChatCount(data.trialChatCount);
        setIsTimeoutActive(data.isTimeoutActive);
        setCurrentLevel(data.currentLevel);
        setChatKey(data.chatKey);
        setChats(data.chats);
        setCurrentPlan(data.currentPlan);
        setCurrentBillingCycle(data.currentBillingCycle);

        // If plan is Pro, reset any limits
        if (data.currentPlan === "Pro") {
          setIsTimeoutActive(false);
          setChatCount(0);
          setTrialChatCount(0);
        }
      }
      setIsLoggedIn(true);

      // Navigation logic for login
      // If user logs in from onboarding, navigation keep onboarding flow till the end and then navigates to ChatScreen
      // If user signs up on onboarding flow, app asks to log in at the end of onboarding flow and the navigates to ChatScreen
      // If user logs in from app flow, app navigates to ChatScreen
      setTimeout(() => {
        const cameFromOnboarding = previousPage?.source === "onboarding";

        if (cameFromOnboarding && Number(previousPage.page) === 1800) {
          setPage(6);
        } else if (cameFromOnboarding) {
          setPage(23);
        } else {
          setPage(6);
        }
      }, 1000);
    } catch (err) {
      console.error("🔥 Unexpected error in onAuthStateChange:", err);
    }
  });

  const [newModalVisible, setNewModalVisible] = useState(false);
  const [currentCountPrincipiante, setCurrentCountPrincipiante] = useState(0);
  const [currentCountIntermedio, setCurrentCountIntermedio] = useState(0);
  const [currentCountAvanzado, setCurrentCountAvanzado] = useState(0);
  const [showSparkle, setShowSparkle] = React.useState(false);
  const [changeLevelNow, setChangeLevelNow] = useState(null);
  const [hideContent, setHideContent] = useState(false); // New state to hide content immediately

  const closeNewModal = () => {
    setHideContent(true); // Immediately hide button and text

    // Show the sparkling-stars.gif with a short delay (e.g., 500ms)
    setTimeout(() => {
      setShowSparkle(true);
    }, 500); // 500ms delay for the gif to start showing

    // Change the level immediately
    if (changeLevelNow === "Principiante") {
      setSelectedOption("Principiante");
    } else if (changeLevelNow === "Intermedio") {
      setSelectedOption("Intermedio");
    } else if (changeLevelNow === "Avanzado") {
      setSelectedOption("Avanzado");
    }

    // After 3 seconds, hide the sparkle and close the modal
    setTimeout(() => {
      setShowSparkle(false);
      setNewModalVisible(false);
      setHideContent(false); // Reset for future use
    }, 3000);
  };

  const closeNewModal2 = () => {
    setNewModalVisible(false);
  };
  const [isContentReady, setIsContentReady] = useState(false);

  useEffect(() => {
    if (showImage && showText) {
      setIsContentReady(true);
    }
  }, [showImage, showText]);

  const [selectedOption, setSelectedOption] = React.useState("Principiante");
  const [registerSuccess, setRegisterSuccess] = useState("");
  const [youhaveregistered, setYouHaveRegistered] = useState(false);
  const [upgradetopro, setupgradetopro] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState("");

  const logIn = async (email, password) => {
    const { user, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      console.error("Login failed:", error);
      return null;
    }
    return user;
  };

  useEffect(() => {
    const handleAppStateChange = (nextAppState) => {
      if (nextAppState === "active" && (page === 1 || page === 7)) {
        AsyncStorage.getItem("timeoutStartTimestamp")
          .then((value) => {
            if (value !== null) {
              const timeoutStartTimestamp = JSON.parse(value);
              const now = Date.now();
              const timeElapsed = now - timeoutStartTimestamp;
              const twelveHoursInMs = 12 * 60 * 60 * 1000;
              const newRemainingTime = twelveHoursInMs - timeElapsed;

              console.log("timeoutStartTimestamp:", timeoutStartTimestamp);
              console.log("Current time:", now);
              console.log("Time elapsed:", timeElapsed);
              console.log("New remaining time:", newRemainingTime);

              if (newRemainingTime > 0 && currentPlan !== "Pro") {
                setRemainingTime(newRemainingTime);
                setIsTimeoutActive(true);
              } else {
                setRemainingTime(twelveHoursInMs); // Reset remaining time
                setIsTimeoutActive(false);
                AsyncStorage.removeItem("timeoutStartTimestamp"); // Clear outdated timeout
              }
            }
          })
          .catch((error) => {
            console.error("Error fetching timeoutStartTimestamp:", error);
          });
      }
    };
    const subscription = AppState.addEventListener(
      "change",
      handleAppStateChange
    );

    return () => {
      subscription.remove();
    };
  }, [page]);

  useEffect(() => {
    if (page === 1) {
      AsyncStorage.getItem("isOnboardingCompleted").then((value) => {
        if (value !== null) {
          setIsOnboardingCompleted(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("currentCountPrincipiante").then((value) => {
        if (value !== null) {
          setCurrentCountPrincipiante(parseInt(value, 10));
        }
      });

      AsyncStorage.getItem("currentCountIntermedio").then((value) => {
        if (value !== null) {
          setCurrentCountIntermedio(parseInt(value, 10));
        }
      });
      AsyncStorage.getItem("alreadySelectedPlan").then((value) => {
        if (value !== null) {
          setAlreadySelectedPlan(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("currentCountAvanzado").then((value) => {
        if (value !== null) {
          setCurrentCountAvanzado(parseInt(value, 10));
        }
      });
      AsyncStorage.getItem("isMicEnabled").then((value) => {
        if (value !== null) {
          setMicEnabled(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("isLoggedIn").then((value) => {
        if (value !== null) {
          setIsLoggedIn(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("currentChatKey").then((value) => {
        if (value !== null) {
          setCurrentChatKey(parseInt(value, 10));
        }
      });

      AsyncStorage.getItem("isMicEnabled2").then((value) => {
        if (value !== null) {
          setMicEnabled2(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("selectedOption").then((value) => {
        if (value !== null) {
          setSelectedOption(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("email").then((value) => {
        if (value !== null) {
          setEmail(value);
        }
      });

      AsyncStorage.getItem("name").then((value) => {
        if (value !== null) {
          setProfileName(value);
        }
      });
      AsyncStorage.getItem("isFirstChat").then((value) => {
        if (value !== null) {
          isFirstChat = JSON.parse(value);
        }
      });
      AsyncStorage.getItem("currentPlan").then((value) => {
        if (value !== null) {
          setCurrentPlan(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("currentBillingCycle").then((value) => {
        if (value !== null) {
          setCurrentBillingCycle(JSON.parse(value));
        }
      });
      AsyncStorage.getItem("isFirstsentence2").then((value) => {
        if (value !== null) {
          isFirstsentence2 = JSON.parse(value);
        }
      });
      AsyncStorage.getItem("firstVisit").then((value) => {
        if (value !== null) {
          setFirstVisit(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("firstTimeModal").then((value) => {
        if (value !== null) {
          setFirstTimeModal(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("chatHistory").then((value) => {
        if (value !== null) {
          setChatHistory(JSON.parse(value)); // Set chatHistory using setChatHistory
        }
      });

      AsyncStorage.getItem("currentCount").then((value) => {
        if (value !== null) {
          setCurrentCount(parseInt(value, 10));
        }
      });

      AsyncStorage.getItem("hasModalBeenShown").then((value) => {
        if (value !== null) {
          setHasModalBeenShown(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("avatarKey")
        .then((value) => {
          if (value !== null && value in avatarImages) {
            setAvatarKey(value);
          } else {
            // Set default if missing or invalid
            setAvatarKey("avatar1");
            AsyncStorage.setItem("avatarKey", "avatar1");
          }
        })
        .catch((error) => {
          console.error("Error reading avatarKey from AsyncStorage:", error);
          setAvatarKey("avatar1");
          AsyncStorage.setItem("avatarKey", "avatar1");
        });

      AsyncStorage.getItem("avatarKey2")
        .then((value) => {
          if (value !== null && value in avatarImages) {
            setAvatarKey2(value);
          } else {
            setAvatarKey2("avatar2");
            AsyncStorage.setItem("avatarKey2", "avatar2");
          }
        })
        .catch((error) => {
          setAvatarKey2("avatar2");
          AsyncStorage.setItem("avatarKey2", "avatar2");
        });

      AsyncStorage.getItem("avatarKey3")
        .then((value) => {
          if (value !== null && value in avatarImages) {
            setAvatarKey3(value);
          } else {
            setAvatarKey3("avatar3");
            AsyncStorage.setItem("avatarKey3", "avatar3");
          }
        })
        .catch((error) => {
          setAvatarKey3("avatar3");
          AsyncStorage.setItem("avatarKey3", "avatar3");
        });

      AsyncStorage.getItem("originPages").then((value) => {
        if (value !== null) {
          setOriginPages(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("isClickable").then((value) => {
        if (value !== null) {
          setIsClickable(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("questionMarkShown").then((value) => {
        if (value !== null) {
          setQuestionMarkShown(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("chatCount").then((value) => {
        if (value !== null) {
          setChatCount(JSON.parse(value));
        }
      });

      AsyncStorage.getItem("firstChatTimestamp").then((value) => {
        if (value !== null) {
          const firstChatTimestamp = JSON.parse(value);
          console.log("firstChatTimestamp:", firstChatTimestamp);
          setFirstChatTimestamp(firstChatTimestamp);
        }
      });

      AsyncStorage.getItem("trialChatCount").then((value) => {
        if (value !== null) {
          const trialChatCount = JSON.parse(value);
          console.log("trialChatCount:", trialChatCount);
          setTrialChatCount(trialChatCount);
        }
      });

      AsyncStorage.getItem("timeoutStartTimestamp").then((value) => {
        if (value !== null) {
          const timeoutStartTimestamp = JSON.parse(value);
          const now = Date.now();
          const timeElapsed = now - timeoutStartTimestamp;
          const newRemainingTime = 43200000 - timeElapsed; // 12 hours in milliseconds

          console.log("timeoutStartTimestamp:", timeoutStartTimestamp);
          console.log("Current time:", now);
          console.log("Time elapsed:", timeElapsed);
          console.log("New remaining time:", newRemainingTime);

          if (newRemainingTime > 0 && currentPlan !== "Pro") {
            setRemainingTime(newRemainingTime);
            setIsTimeoutActive(true);
          } else {
            setRemainingTime(43200000); // Reset remaining time
            setIsTimeoutActive(false);
          }
        }
      });

      AsyncStorage.getItem("currentLevel").then((value) => {
        if (value !== null) {
          setCurrentLevel(parseInt(value, 10));
        }
      });

      AsyncStorage.getItem("profilePicture").then((uri) => {
        if (uri !== null) {
          setProfilePicture(uri);
        }
      });
      AsyncStorage.getItem("chatKey").then((value) => {
        if (value !== null) {
          setChatKey(parseInt(value, 10)); // Set chatKey using setChatKey
        }
      });

      AsyncStorage.getItem("chats").then((value) => {
        if (value !== null) {
          setChats(JSON.parse(value));
        }
      });
    }
  }, [page, avatarImages]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Save the chat counts, chat history, chat key, and chats to AsyncStorage whenever they change
      AsyncStorage.setItem("avatarKey", avatarKey);
      AsyncStorage.setItem("currentPlan", JSON.stringify(currentPlan));
      AsyncStorage.setItem(
        "currentBillingCycle",
        JSON.stringify(currentBillingCycle)
      );

      AsyncStorage.setItem("avatarKey2", avatarKey2);
      AsyncStorage.setItem("avatarKey3", avatarKey3);
      AsyncStorage.setItem("isFirstChat", JSON.stringify(isFirstChat));
      AsyncStorage.setItem(
        "isFirstsentence2",
        JSON.stringify(isFirstsentence2)
      );
      AsyncStorage.setItem("currentChatKey", currentChatKey.toString());
      AsyncStorage.setItem("currentCount", currentCount.toString());
      AsyncStorage.setItem("firstVisit", JSON.stringify(firstVisit));
      AsyncStorage.setItem("email", email);
      AsyncStorage.setItem("originPages", JSON.stringify(originPages));
      AsyncStorage.setItem("name", name);
      AsyncStorage.setItem(
        "hasModalBeenShown",
        JSON.stringify(hasModalBeenShown)
      );
      AsyncStorage.setItem("isMicEnabled", JSON.stringify(isMicEnabled));
      AsyncStorage.setItem(
        "alreadySelectedPlan",
        JSON.stringify(alreadySelectedPlan)
      );

      AsyncStorage.setItem("isLoggedIn", JSON.stringify(isLoggedIn));
      AsyncStorage.setItem(
        "currentCountPrincipiante",
        currentCountPrincipiante.toString()
      );
      AsyncStorage.setItem(
        "currentCountIntermedio",
        currentCountIntermedio.toString()
      );
      AsyncStorage.setItem(
        "currentCountAvanzado",
        currentCountAvanzado.toString()
      );
      AsyncStorage.setItem("isMicEnabled2", JSON.stringify(isMicEnabled2));
      AsyncStorage.setItem("selectedOption", JSON.stringify(selectedOption));
      AsyncStorage.setItem("chatCount", JSON.stringify(chatCount));
      AsyncStorage.setItem(
        "firstChatTimestamp",
        JSON.stringify(firstChatTimestamp)
      );
      AsyncStorage.setItem("trialChatCount", JSON.stringify(trialChatCount));
      AsyncStorage.setItem(
        "isOnboardingCompleted",
        JSON.stringify(isOnboardingCompleted)
      );
      AsyncStorage.setItem("currentLevel", currentLevel.toString());
      AsyncStorage.setItem("chatHistory", JSON.stringify(chatHistory));
      AsyncStorage.setItem("chatKey", chatKey.toString());
      AsyncStorage.setItem("chats", JSON.stringify(chats));
      AsyncStorage.setItem("isClickable", JSON.stringify(isClickable));

      AsyncStorage.setItem("firstTimeModal", JSON.stringify(firstTimeModal));
    }, 1000); // Change this to the desired interval in milliseconds

    return () => clearInterval(interval); // This is important to clear the interval when the component unmounts
  }, [
    currentChatKey,
    firstTimeModal,
    profilePicture,
    currentCount,
    currentPlan,
    currentBillingCycle,
    currentLevel,
    alreadySelectedPlan,
    hasModalBeenShown,
    questionMarkShown,
    chatHistory,
    chatKey,
    chats,
    isClickable,
    firstVisit,
    email,
    name,
    isMicEnabled,
    isMicEnabled2,
    selectedOption,
    originPages,
    avatarKey,
    avatarKey2,
    avatarKey3,
    isOnboardingCompleted,
    currentCountPrincipiante,
    currentCountIntermedio,
    currentCountAvanzado,
    chatCount,
    firstChatTimestamp,
    trialChatCount,
    isTimeoutActive,
    remainingTime,
    isLoggedIn,
  ]);

  const { width: screenWidth, height: screenHeight } = Dimensions.get("window");

  Dimensions.get("window");

  const isTallAspectRatio =
    screenHeight / screenWidth > 2.2 && screenHeight / screenWidth <= 2.4;

  // Define font sizes based on the aspect ratio
  let fontSizeHuge,
    fontSizeLarge,
    fontSizeMedium,
    fontSizeSmall,
    fontSizeMedium2;

  let fontScale = PixelRatio.getFontScale();
  // Define font sizes based on the aspect ratio and font scaling
  if (isTallAspectRatio && fontScale == 1.0) {
    fontSizeHuge = 30;
    fontSizeLarge = 16;
    fontSizeMedium = 14;
    fontSizeMedium2 = 12;
    fontSizeSmall = 10;
  } else if (fontScale == 1.0) {
    fontSizeHuge = 32;
    fontSizeLarge = 18;
    fontSizeMedium = 16;
    fontSizeMedium2 = 16;
    fontSizeSmall = 12;
  } else if (isTallAspectRatio && fontScale != 1.0) {
    fontSizeHuge = 22.5;
    fontSizeLarge = 12;
    fontSizeMedium = 10.5;
    fontSizeMedium2 = 9;
    fontSizeSmall = 7.5;
  } else {
    fontSizeHuge = 24;
    fontSizeLarge = 13.5;
    fontSizeMedium = 12;
    fontSizeMedium2 = 12;
    fontSizeSmall = 9;
  }

  const [keyboardStatus, setKeyboardStatus] = useState(undefined);
  const _keyboardDidShow = () => setKeyboardStatus("Keyboard Shown");
  const _keyboardDidHide = () => setKeyboardStatus("Keyboard Hidden");

  useEffect(() => {
    if (Platform.OS === "android") {
      Keyboard.addListener("keyboardDidShow", _keyboardDidShow);
      Keyboard.addListener("keyboardDidHide", _keyboardDidHide);
    }

    // cleanup function
    return () => {
      if (Platform.OS === "android") {
        Keyboard.removeListener("keyboardDidShow", _keyboardDidShow);
        Keyboard.removeListener("keyboardDidHide", _keyboardDidHide);
      }
    };
  }, []);

  const bottomPosition = keyboardStatus === "Keyboard Shown" ? 295 : 540;

  const loadAssetsAsync = async () => {
    const imageAssets = cacheImages(images2);
    await Promise.all([...imageAssets]);
  };

  useEffect(() => {
    loadAssetsAsync();
  }, []);

  const [bwImages, setBwImages] = useState([
    require("./assets/images/capy-in-white-circle-yellow-bg.png"),
  ]);

  const [colorImages, setColorImages] = useState([
    require("./assets/images/capy-in-white-circle-yellow-bg.png"),
  ]);

  const [isClickable, setIsClickable] = useState([
    true,
    false,
    false,
    false,
    false,
  ]);
  useEffect(() => {
    const checkPermissions = async () => {
      const { status } = await Notifications.getPermissionsAsync();
      setNotificationsEnabled(status === "granted");
    };

    checkPermissions();
  }, []);

  const [emailError, setEmailError] = useState(""); // State to hold the email error message
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const validateEmail = (text, fromBlur = false) => {
    setEmail(text);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

    if ((hasSubmitted || fromBlur) && text.trim()) {
      if (!emailRegex.test(text)) {
        setEmailError("Introduce un correo electrónico válido.");
      } else {
        setEmailError("");
      }
    } else if ((hasSubmitted || fromBlur) && !text.trim()) {
      setEmailError("Por favor, introduce un correo electrónico válido.");
    } else {
      setEmailError("");
    }
  };

  const [, setNotification] = useState(false);
  const [, setNotificationResponse] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();
  useEffect(() => {
    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        setNotification(notification);
      });

    responseListener.current =
      Notifications.addNotificationResponseReceivedListener(
        async (response) => {
          if (isTimeoutActive) {
            // Ignore the notification if isTimeoutActive is true
            return;
          }

          setNotificationResponse(response);

          // Set page to 7 first
          setPage(7);

          // Wait for the page to be set (add a small delay if needed to ensure the page has rendered)
          await new Promise((resolve) => setTimeout(resolve, 500)); // Adjust the delay based on your app's speed

          // Dismiss the notification
          await Notifications.dismissNotificationAsync(
            response.notification.request.identifier
          );

          if (selectedOption === "Principiante") {
            setCurrentCountPrincipiante((prevCount) => prevCount + 1);
          } else if (selectedOption === "Intermedio") {
            setCurrentCountIntermedio((prevCount) => prevCount + 1);
          } else if (selectedOption === "Avanzado") {
            setCurrentCountAvanzado((prevCount) => prevCount + 1);
          }

          handleStartNewChat();
          isFirstChat = true;
        }
      );

    return () => {
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, [handleStartNewChat, selectedOption, isTimeoutActive]);

  async function schedulePushNotification() {
    await setNotificationCategory();

    // Schedule for 11:00
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Vamos a hablar en inglés! 💬",
        body: "haga clic aquí para iniciar el chat",
        categoryIdentifier: "submit_reply",
      },
      trigger: {
        hour: 18,
        minute: 20,
        repeats: true,
      },
    });

    // Schedule for 16:00
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Vamos a hablar en inglés! 💬",
        body: "haga clic aquí para iniciar el chat",
        categoryIdentifier: "submit_reply",
      },
      trigger: {
        hour: 16,
        minute: 35,
        repeats: true,
      },
    });

    // Schedule for 21:00
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Vamos a hablar en inglés! 💬",
        body: "haga clic aquí para iniciar el chat",
        categoryIdentifier: "submit_reply",
      },
      trigger: {
        hour: 1,
        minute: 45,
        repeats: true,
      },
    });
  }
  //------ [SETTING NOTIFICATION CATEGORY AND ACTIONS  (actions on notification) WITH CUSTOM OPTIONS:]--------------

  async function setNotificationCategory() {
    await Notifications.setNotificationCategoryAsync("submit_reply", [
      {
        identifier: "open_chat",
        buttonTitle: "Responder",
        options: {
          opensAppToForeground: true,
        },
      },
    ]);
  }

  const [currentCount, setCurrentCount] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(1);
  const [firstClick, setFirstClick] = useState(false);
  const [showBlur, setShowBlur] = useState(false);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (page === 7 && firstClick) {
      setTimeout(() => {
        setShowBlur(true);
      }, 2000); // 1000 milliseconds = 1 second
    } else {
      setShowBlur(false);
    }
  }, [page, firstClick]);

  useEffect(() => {
    if (page === 4000) {
      const timerId = setTimeout(() => {
        Animated.sequence([
          Animated.timing(scaleAnim, {
            toValue: 1.2,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }),
        ]).start();
      }, 10000); // Start the animation after 10 seconds

      return () => clearTimeout(timerId); // Clear the timer when the component unmounts
    }
  }, [scaleAnim, page]); // Add page to the dependency array

  const paperworkScale = useRef(new Animated.Value(1)).current;
  const iconScale = useRef(new Animated.Value(1)).current;
  const documentScale = useRef(new Animated.Value(1)).current;
  const handlePressnow = (scaleValue, page) => {
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 1.3,
        duration: 200, // Duration in milliseconds
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 200, // Duration in milliseconds
        useNativeDriver: true,
      }),
    ]).start(() => {
      setPage(page);
      scaleValue.setValue(1); // Reset the scale value to 1 after navigation
    });
  };
  const [scaleValue1] = useState(new Animated.Value(1));
  const [scaleValue2] = useState(new Animated.Value(1));
  const [scaleValue3] = useState(new Animated.Value(1));
  const [scaleValue4] = useState(new Animated.Value(1));
  const [scaleValue5] = useState(new Animated.Value(1));
  const [scaleValue6] = useState(new Animated.Value(1));
  const [scaleValue7] = useState(new Animated.Value(1));
  const [scaleValue8] = useState(new Animated.Value(1));
  const [scaleValue9] = useState(new Animated.Value(1));
  // Add these refs to control the animations
  const scaleValue = useRef(
    Array.from({ length: 10 }, () => new Animated.Value(1))
  );
  const [modalVisible, setModalVisible] = useState(false);
  const [firstTimeModal, setFirstTimeModal] = useState(true); // Add this line

  useEffect(() => {
    if (page === 6 && firstTimeModal) {
      // Check if firstTimeModal is true
      const timer = setTimeout(() => {
        setModalVisible(true);
        setFirstTimeModal(false); // Set firstTimeModal to false after showing the modal
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [page, firstTimeModal]);

  const [showButton, setShowButton] = useState(false);

  const setQuestionMarkAndStorage = async (value) => {
    try {
      setQuestionMarkShown(value);
      await AsyncStorage.setItem("questionMarkShown", JSON.stringify(true));
    } catch (error) {
      console.error("Failed to save questionMarkShown to AsyncStorage", error);
    }
  };

  const [showQuestionMark, setShowQuestionMark] = useState(false);
  const [showPopupnewer, setShowPopupnewer] = useState(false);
  const [questionMarkShown, setQuestionMarkShown] = useState(false);

  useEffect(() => {
    if (page === 7 && isTimeoutActive && !questionMarkShown) {
      setTimeout(() => {
        setShowQuestionMark(true);
      }, 3000);
    }
  }, [page, isTimeoutActive, questionMarkShown]);

  const handleQuestionMarkClick = () => {
    setShowPopupnewer(true);
  };

  const [, setClickCounter] = useState(0);
  const handleCounting = async (prevCount1) => {
    const newCount1 = prevCount1 + 1;
    let threshold = 2;
    let increment = 3;

    while (newCount1 > threshold) {
      threshold += increment;
      increment++;
    }

    if (newCount1 === threshold) {
      setTimeout(() => {
        setupgradetopro(true);
      }, 1000); // 1 second timeout
    }

    // Save the new count to AsyncStorage
    await AsyncStorage.setItem("clickCounter", JSON.stringify(newCount1));

    return newCount1;
  };

  const handleClosePopup = async () => {
    setShowPopupnewer(false);
    const prevCount1 = await AsyncStorage.getItem("clickCounter");
    const newCount1 = await handleCounting(
      prevCount1 ? JSON.parse(prevCount1) : 0
    );
    setClickCounter(newCount1);
  };

  // Use useEffect to load the initial state from AsyncStorage
  useEffect(() => {
    const loadInitialState = async () => {
      const savedCount = await AsyncStorage.getItem("clickCounter");
      if (savedCount !== null) {
        setClickCounter(JSON.parse(savedCount));
      }
    };

    loadInitialState();
  }, []);

  const [showPopup, setShowPopup] = useState(false);
  const [originPages, setOriginPages] = useState([]);
  const [dialogVisible, setDialogVisible] = useState(false);

  const [, setCurrentImage] = useState(
    require("./assets/images/capy-in-white-circle-yellow-bg.png")
  );

  const handlePress = (index) => {
    if (isClickable[index]) {
      // Check if the character is clickable
      setIsClickable((prevState) => {
        const newState = [...prevState];
        newState[index] = true;
        return newState;
      });
      setCurrentImage(colorImages[index]); // Update currentImage
      setDialogVisible(false); // Close the dialog
    }
  };

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(
      (notification) => {
        console.log(notification);
      }
    );

    return () => {
      subscription.remove();
    };
  }, []);

  const askForPermissions = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== "granted") {
      alert("Sin permiso de notificación!");
      return;
    }
    alert("Permisos de notificación concedidos!");
    setNotificationsEnabled(true);
  };

  const [chatCount, setChatCount] = useState(0);
  const [firstChatTimestamp, setFirstChatTimestamp] = useState(null);
  const [trialChatCount, setTrialChatCount] = useState(0);
  const [isTimeoutActive, setIsTimeoutActive] = useState(false);
  const [thirdchat, setthirdchat] = useState(false);
  const [remainingTime, setRemainingTime] = useState(43200000); // 12 hours in milliseconds
  const timeoutRef = useRef(null);
  const intervalRef = useRef(null);
  const handleTimeoutAndInterval = useCallback(() => {
    console.log("isTimeoutActive:", isTimeoutActive);

    // Check if plan is Pro using state variable
    if (currentPlan === "Pro") {
      setIsTimeoutActive(false);
      return; // Exit early if Pro plan
    }

    // Only proceed with timeout logic if not Pro plan
    if (isTimeoutActive) {
      // Set a timeout to reset isTimeoutActive after the remaining time
      timeoutRef.current = setTimeout(() => {
        setIsTimeoutActive(false);
        setRemainingTime(43200000); // Reset remaining time
      }, remainingTime);

      // Set an interval to update the remaining time every second
      intervalRef.current = setInterval(() => {
        setRemainingTime((prevTime) => prevTime - 1000);
      }, 1000); // Update every second
    } else {
      // Clear any existing timeout and interval
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
  }, [isTimeoutActive, remainingTime, currentPlan]);
  useEffect(() => {
    handleTimeoutAndInterval();

    return () => {
      // Cleanup timeout and interval on component unmount
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isTimeoutActive, handleTimeoutAndInterval]);

  const handleStartNewChat = useCallback(() => {
    const now = new Date().getTime();
    if (currentPlan === "Pro") {
      startNewChat();
      return;
    }
    if (currentPlan === "Básico") {
      if (trialChatCount < 10) {
        setTrialChatCount(trialChatCount + 1);
        startNewChat();
      } else {
        if (chatCount < 3) {
          if (chatCount === 0) {
            setFirstChatTimestamp(now);
          }
          setChatCount(chatCount + 1);
          startNewChat();
        } else {
          const timeElapsed = now - firstChatTimestamp;
          const minutesElapsed = timeElapsed / (1000 * 60);

          if (minutesElapsed >= 2) {
            // Change to 12 hours (720 minutes)
            setChatCount(1);
            setFirstChatTimestamp(now);
            setIsTimeoutActive(false);
            startNewChat();
          } else {
            setIsTimeoutActive(true);
            console.log(
              "You have reached the limit of 3 chats in 12 hours. Please wait."
            );
            console.log("isTimeoutActive set to true");
          }
        }
      }
    }

    // Start the timeout after the 3rd chat
    if (chatCount === 2) {
      setIsTimeoutActive(true);
      AsyncStorage.setItem("timeoutStartTimestamp", JSON.stringify(now)); // Save the timestamp when the timeout starts
    }
  }, [chatCount, firstChatTimestamp, trialChatCount]);

  const startNewChat = () => {
    console.log("Starting new chat..");
    isFirstChat = true;

    setCurrentChatKey((prevKey) => {
      const newKey = prevKey + 1; // Increment currentChatKey
      setChatKey(newKey); // Set chatKey to the new key
      setChatHistories((prevHistories) => ({
        ...prevHistories,
        [newKey]: [],
      }));
      setChatHistory([]);
      return newKey;
    });

    setChats((prevChats) => {
      const newChatKey = prevChats.length + 1;
      setOriginPages((prevOriginPages) => {
        return { ...prevOriginPages, [newChatKey]: 6 };
      });
      return [...prevChats, newChatKey];
    });

    setPage(6);
    isFirstChat = true;
    setShouldLoadMessages(false);
    console.log("New chat started.");
  };

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (evt, gestureState) => {
        return Math.abs(gestureState.dx) > 5;
      },
      onPanResponderRelease: (evt, gestureState) => {
        if (gestureState.dx > 0) {
          setPage((prevPage) => Math.max(prevPage - 1, 1));
          setShowArrow(false);
        } else if (gestureState.dx < 0) {
          setPage((prevPage) => Math.min(prevPage + 1, 7));
          setShowArrow(false);
        }
      },
    })
  ).current;
  const panResponder1800 = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderRelease: (evt, gestureState) => {
      if (gestureState.dx < 0) {
        setPage(2);
      }
    },
  });

  const panResponder3 = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderRelease: (evt, gestureState) => {
      if (gestureState.dx < 0) {
        setPage(4000);
      }
    },
  });

  useEffect(() => {
    if (page === 4) {
      setTimeout(() => {
        setShowContent2(true);
      }, 100); // Wait for 2 seconds
    } else {
      setShowContent2(false);
    }
    if (page === 6) {
      userName = name;
    }
  }, [page, name]);
  const [isOnboardingCompleted, setIsOnboardingCompleted] = useState(false);
  useEffect(() => {
    if (page === 1) {
      const timer = setTimeout(() => {
        setPage(isOnboardingCompleted ? 7 : 1800);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [
    page,
    isOnboardingCompleted,
    trialChatCount,
    chatCount,
    firstChatTimestamp,
  ]);

  if (!fontsLoaded || !onboardingLoaded) {
    return null;
  }

  return (
    <SafeAreaProvider>
      <PaperProvider>
        {page === 1 ||
        page === 1800 ||
        page === 2 ||
        page === 3 ||
        page === 23 ? (
          <OnboardingScreens
            page={page}
            setPage={handleSetPage}
            styles={styles}
            screenHeight={screenHeight}
            screenWidth={screenWidth}
            panResponder={panResponder}
            panResponder1800={panResponder1800}
            panResponder3={panResponder3}
            isTallAspectRatio={isTallAspectRatio}
            fontSizeMedium={fontSizeMedium}
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            name={name}
            setName={setName}
            setIsOnboardingCompleted={setIsOnboardingCompleted}
            selectedPlan={selectedPlan}
            selectedBillingCycle={selectedBillingCycle}
            setSelectedBillingCycle={setSelectedBillingCycle}
            currentPlan={currentPlan}
            currentBillingCycle={currentBillingCycle}
            alreadySelectedPlan={alreadySelectedPlan}
            handleTesterButtonPress={handleTesterButtonPress}
            testerUsed={testerUsed}
            setTesterUsed={setTesterUsed}
            isTrialActive={isTrialActive}
            setIsTrialActive={setIsTrialActive}
            setCurrentPlan={setCurrentPlan}
            setCurrentBillingCycle={setCurrentBillingCycle}
            setIsTimeoutActive={setIsTimeoutActive}
            setChatCount={setChatCount}
            setTrialChatCount={setTrialChatCount}
            setRemainingTime={setRemainingTime}
            saveToSupabase={saveToSupabase}
            inAppBuySubscription={inAppBuySubscription}
            setIsSubscribing={setIsSubscribing}
            signUp={signUp}
            email={email}
            setEmail={setEmail}
            setPassword={setPassword}
            password={password}
            onPrimaryAction={() => signUp(email, password)}
            validateEmail={validateEmail}
            emailError={emailError}
            setEmailError={setEmailError}
            passwordError={passwordError}
            setPasswordError={setPasswordError}
            setPreviousPage={setPreviousPage}
            previousPage={previousPage}
            setLoginFlowSource={setLoginFlowSource}
            setIsLoggedIn={setIsLoggedIn}
            isLoggedIn={isLoggedIn}
          />
        ) : page === 4000 ? (
          <SubscriptionScreen
            planDetails={planDetails}
            selectedPlan={selectedPlan}
            setSelectedPlan1={setSelectedPlan1}
            selectedBillingCycle={selectedBillingCycle}
            setSelectedBillingCycle={setSelectedBillingCycle}
            currentPlan={currentPlan}
            currentBillingCycle={currentBillingCycle}
            isSubscribing={isSubscribing}
            alreadySelectedPlan={alreadySelectedPlan}
            setAlreadySelectedPlan={setAlreadySelectedPlan}
            setPage={handleSetPage}
            textColor={textColor}
            fontSizeLarge={fontSizeLarge}
            fontSizeSmall={fontSizeSmall}
            fontSizeHuge={fontSizeHuge}
            makeUserWant={makeUserWant}
            popAnim={popAnim}
            handleTesterButtonPress={handleTesterButtonPress}
            testerUsed={testerUsed}
            setTesterUsed={setTesterUsed}
            isTrialActive={isTrialActive}
            setIsTrialActive={setIsTrialActive}
            setCurrentPlan={setCurrentPlan}
            setCurrentBillingCycle={setCurrentBillingCycle}
            setIsTimeoutActive={setIsTimeoutActive}
            setChatCount={setChatCount}
            setTrialChatCount={setTrialChatCount}
            setRemainingTime={setRemainingTime}
            saveToSupabase={saveToSupabase}
            inAppBuySubscription={inAppBuySubscription}
            setIsSubscribing={setIsSubscribing}
            originPage={originPage}
          />
        ) : page === 4 ? (
          <IntroScreen
            showContent2={showContent2}
            showImage={showImage}
            showText={showText}
            showText2={showText2}
            showFinger={showFinger}
            isContentReady={isContentReady}
            screenHeight={screenHeight}
            styles={styles}
            setClickCount={setClickCount}
            setPage={handleSetPage}
            setShowText={setShowText}
            setShowImage={setShowImage}
            setShowText2={setShowText2}
            setIsContentReady={setIsContentReady}
            fontSizeMedium2={fontSizeMedium2}
            currentPage={page}
          />
        ) : page === 4210 || page === 4211 || page === 4212 ? (
          <LegalScreens
            page={page}
            setPage={handleSetPage}
            originPage={originPage}
          />
        ) : page === 5 ? (
          <LevelSelectionScreen
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            setPage={setPage}
            styles={styles}
            screenHeight={screenHeight}
          />
        ) : page === 5.2 ? (
          <NameInputScreen
            name={name}
            setName={setName}
            setPage={setPage}
            setIsOnboardingCompleted={setIsOnboardingCompleted}
            setChatHistory={setChatHistory}
            setShouldLoadMessages={setShouldLoadMessages}
            setCurrentChatKey={setCurrentChatKey}
            setChatKey={setChatKey}
            selectedOption={selectedOption}
            setCurrentCountPrincipiante={setCurrentCountPrincipiante}
            setCurrentCountIntermedio={setCurrentCountIntermedio}
            setCurrentCountAvanzado={setCurrentCountAvanzado}
            styles={styles}
          />
        ) : page === 6 ? (
          <ChatScreen
            userName={name}
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            key={chatKey}
            chatHistory={chatHistory}
            chatHistories={chatHistories}
            setChatHistory={setChatHistory}
            setChatHistories={setChatHistories}
            addMessageToChatHistory={addMessageToChatHistory}
            isTimeoutActive={isTimeoutActive}
            thirdchat={thirdchat}
            handleQuestionMarkClick={handleQuestionMarkClick}
            avatarKey={avatarKey}
            avatarKey2={avatarKey2}
            avatarKey3={avatarKey3}
            avatarImages={avatarImages}
            setPage={handleSetPage}
            isMicEnabled={isMicEnabled}
            modalVisible={modalVisible}
            setModalVisible={setModalVisible}
            isMicEnabled2={isMicEnabled2}
            setMicEnabled2={setMicEnabled2}
            chatKey={chatKey}
            shouldLoadMessages={shouldLoadMessages}
            setShouldLoadMessages={setShouldLoadMessages}
          />
        ) : page === 7 ? (
          <HomeScreen
            currentLevel={currentLevel}
            currentCount={currentCount}
            currentCountAvanzado={currentCountAvanzado}
            currentCountIntermedio={currentCountIntermedio}
            currentCountPrincipiante={currentCountPrincipiante}
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            isTimeoutActive={isTimeoutActive}
            handleQuestionMarkClick={handleQuestionMarkClick}
            handleStartNewChat={handleStartNewChat}
            setCurrentCountPrincipiante={setCurrentCountPrincipiante}
            setCurrentCountIntermedio={setCurrentCountIntermedio}
            setCurrentCountAvanzado={setCurrentCountAvanzado}
            setCurrentLevel={setCurrentLevel}
            setPage={setPage}
            page={page}
            showImageOnPage7={showImageOnPage7}
            remainingTime={remainingTime}
            currentPlan={currentPlan}
            showQuestionMark={showQuestionMark}
            setShowQuestionMark={setShowQuestionMark}
            setQuestionMarkAndStorage={setQuestionMarkAndStorage}
            dialogVisible={dialogVisible}
            setDialogVisible={setDialogVisible}
            handlePress={handlePress}
            isClickable={isClickable}
            colorImages={colorImages}
            bwImages={bwImages}
            chats={chats}
            chatHistories={chatHistories}
            setChatKey={setChatKey}
            setShouldLoadMessages={setShouldLoadMessages}
            isFirstChat={isFirstChat}
            setthirdchat={setthirdchat}
            upgradetopro={upgradetopro}
            setupgradetopro={setupgradetopro}
            youhaveregistered={youhaveregistered}
            showPopupnewer={showPopupnewer}
            handleClosePopup={handleClosePopup}
            showBlur={showBlur}
            showOk={showOk}
            showOkbutton={showOkbutton}
            setShowOk={setShowOk}
            setShowOkbutton={setShowOkbutton}
            setBlur={setBlur}
            paperworkScale={paperworkScale}
            iconScale={iconScale}
            documentScale={documentScale}
            handlePressnow={handlePressnow}
            screenHeight={screenHeight}
            showImage5={showImage5}
            blur={blur}
          />
        ) : page === 820 ? (
          <MyProgressScreen
            selectedOption={selectedOption}
            setSelectedOption={setSelectedOption}
            paperworkScale={paperworkScale}
            iconScale={iconScale}
            documentScale={documentScale}
            handlePressnow={handlePressnow}
            styles={styles}
            page={page}
            setPage={setPage}
          />
        ) : page === 8 ? (
          <LevelOverviewScreen setPage={setPage} styles={styles} />
        ) : page === 9 ? (
          <SettingsScreen
            setPage={setPage}
            setOriginPage={setOriginPage}
            notificationsEnabled={notificationsEnabled}
            askForPermissions={askForPermissions}
            schedulePushNotification={schedulePushNotification}
            isLoggedIn={isLoggedIn}
            setIsLoggedIn={setIsLoggedIn}
            isPopupVisible={isPopupVisible}
            setPopupVisible={setPopupVisible}
            setEmail={setEmail}
            setPassword={setPassword}
            setName={setName}
          />
        ) : page === 7.2 ? (
          <NotificationPromptScreen
            showfirst2={showfirst2}
            setShowfirst2={setShowfirst2}
            showfirst={showfirst}
            setShowfirst={setShowfirst}
            showsecond={showsecond}
            setShowsecond={setShowsecond}
            showthird={showthird}
            setShowthird={setShowthird}
            showfourth={showfourth}
            setShowfourth={setShowfourth}
            showfifth={showfifth}
            setShowfifth={setShowfifth}
            showPopup={showPopup}
            setShowPopup={setShowPopup}
            showText72={showText72}
            setShowText72={setShowText72}
            showText73={showText73}
            setShowText73={setShowText73}
            showImage72={showImage72}
            setShowImage72={setShowImage72}
            showFinger2={showFinger2}
            setShowFinger2={setShowFinger2}
            showButton={showButton}
            setShowButton={setShowButton}
            screenHeight={screenHeight}
            showSecond2={showSecond2}
            setShowsecond2={setShowsecond2}
            askForPermissions={askForPermissions}
            setPage={setPage}
          />
        ) : page === 121 ? (
          <ProfilePromptScreen setPage={setPage} styles={styles} />
        ) : page === 122 || page === 122.1 || page === 123 ? (
          <RegisterScreen
            page={page}
            setPage={setPage}
            screenHeight={screenHeight}
            validateEmail={validateEmail}
            email={email}
            setEmail={setEmail}
            emailError={emailError}
            setEmailError={setEmailError}
            password={password}
            setPassword={setPassword}
            passwordError={passwordError}
            setPasswordError={setPasswordError}
            signUp={signUp}
            name={name}
            setName={setName}
            setisregistered={setisregistered}
            registerSuccess={registerSuccess}
            setPreviousPage={setPreviousPage}
            setLoginFlowSource={setLoginFlowSource}
          />
        ) : page === 124 ? (
          <LoginScreen
            styles={styles}
            setPage={setPage}
            screenHeight={screenHeight}
            email={email}
            setEmail={setEmail}
            emailError={emailError}
            setEmailError={setEmailError}
            password={password}
            setPassword={setPassword}
            passwordError={passwordError}
            setPasswordError={setPasswordError}
            validateEmail={validateEmail}
            logIn={logIn}
            loginError={loginError}
            setLoginError={setLoginError}
            loginSuccess={loginSuccess}
            name={name}
            setName={setName}
            setIsLoggedIn={setIsLoggedIn}
            previousPage={previousPage}
            setPreviousPage={setPreviousPage}
            setCurrentScreen={setCurrentScreen}
            currentScreen={currentScreen}
            isAppFlow={loginFlowSource === "app"}
            loginFlowSource={loginFlowSource}
            setLoginFlowSource={setLoginFlowSource}
            page={page}
          />
        ) : page === 125 ? (
          <ProfilePage
            styles={styles}
            setPage={setPage}
            pickImage={pickImage}
            profilePicture={profilePicture}
            email={email}
            setEmail={setEmail}
            isEmailEditable={isEmailEditable}
            setIsEmailEditable={setIsEmailEditable}
            name={name}
            setName={setName}
            isNameEditable={isNameEditable}
            setIsNameEditable={setIsNameEditable}
            isLoggedIn={isLoggedIn}
            setProfileName={setProfileName}
            profileName={profileName}
          />
        ) : page === "ForgotPassword" ? (
          <ForgotPasswordPage
            setPage={setPage}
            validateEmail={validateEmail}
            email={email}
            page={page}
            setLoginFlowSource={setLoginFlowSource}
            setEmail={setEmail}
            emailError={emailError}
            setEmailError={setEmailError}
            passwordError={passwordError}
          />
        ) : page === "ChangePasswordEmail" ? (
          <ChangePasswordEmail
            setPage={setPage}
            page={page}
            setLoginFlowSource={setLoginFlowSource}
            setPreviousPage={setPreviousPage}
            currentPage={page}
            setEmail={setEmail}
          />
        ) : null}
      </PaperProvider>
    </SafeAreaProvider>
  );
}

export let isFirstsentence2 = false;
export function setisFirstsentence2(value) {
  isFirstsentence2 = value;
}
export let isFirstChat = true;
export function setisFirstChat(value) {
  isFirstChat = value;
}
let scrollViewRef = React.createRef();
