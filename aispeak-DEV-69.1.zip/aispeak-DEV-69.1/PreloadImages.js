import { Asset } from "expo-asset";

const preloadImages = async () => {
  const imageAssets = [
    // Icons
    require("./assets/icons/black-1-circle-no-bg.jpg"),
    require("./assets/icons/black-2-circle-no-bg.jpg"),
    require("./assets/icons/black-arrow-down-no-bg.png"),
    require("./assets/icons/black-circle-no-bg.png"),
    require("./assets/icons/blue-checkmark-circle-no-bg.png"),
    require("./assets/icons/blue-circle-no-bg.png"),
    require("./assets/icons/blue-circle-white-filled.png"),
    require("./assets/icons/gray-eye-no-bg.png"),
    require("./assets/icons/white-3-dots-blue-bubble-bg.png"),
    require("./assets/icons/white-arrow-up-no-bg.png"),
    require("./assets/icons/white-circle-no-bg-hd.png"),
    require("./assets/icons/white-mic-no-bg.png"),
    require("./assets/icons/white-question-mark-blue-round-bubble-bg.png"),
    require("./assets/icons/white-round-bubble-no-bg.png"),
    require("./assets/icons/white-square-bubble-no-bg.png"),
    require("./assets/icons/transparent-arrow-right-black-bg.png"),

    // Images
    require("./assets/images/3-blue-dots.gif"),
    require("./assets/images/audio-message-recording.gif"),
    require("./assets/images/capy-hd.png"),
    require("./assets/images/capy-in-white-circle-yellow-bg.png"),
    require("./assets/images/capy-in-white-circle.png"),
    require("./assets/images/capy-with-crown-in-white-circle.png"),
    require("./assets/images/capy-with-crown.png"),
    require("./assets/images/capy-with-hat-in-white-circle.png"),
    require("./assets/images/capy-with-hat.png"),
    require("./assets/images/capy.png"),
    require("./assets/images/clock.png"),
    require("./assets/images/explanations-avanzado.png"),
    require("./assets/images/explanations-intermedio.png"),
    require("./assets/images/explanations-principiante.png"),
    require("./assets/images/finger-tapping.gif"),
    require("./assets/images/floating-island.png"),
    require("./assets/images/girl-typing-on-computer-with-cat.gif"),
    require("./assets/images/hold-pressed-bell.png"),
    require("./assets/images/home-menu.png"),
    require("./assets/images/level-avanzado-color.png"),
    require("./assets/images/level-avanzado-grayscale.png"),
    require("./assets/images/level-intermedio-color.png"),
    require("./assets/images/level-intermedio-grayscale.png"),
    require("./assets/images/level-principiante-color.png"),
    require("./assets/images/level-principiante-grayscale.png"),
    require("./assets/images/levels-menu.png"),
    require("./assets/images/loading-circle.gif"),
    require("./assets/images/locked-level.png"),
    require("./assets/images/man-and-woman-solving-puzzle.png"),
    require("./assets/images/man-happy-raising-arms-in-park.png"),
    require("./assets/images/man-looking-at-big-screen.png"),
    require("./assets/images/orange-left-arrow.gif"),
    require("./assets/images/settings-menu.png"),
    require("./assets/images/sparkling-stars.gif"),
    require("./assets/images/timeout-clock.png"),
    require("./assets/images/union-jack.png"),
    require("./assets/images/zzz.gif"),
    // require("./assets/images/old-circle.png"),
    // require("./assets/images/old-logo-and-brand.png"),
    // require("./assets/images/old-capiandchat.png"),
    // require("./assets/images/old-speaker.png"),
    // require("./assets/images/old-translate.png"),
  ];

  const cacheImages = imageAssets.map((image) => {
    return Asset.fromModule(image).downloadAsync();
  });

  return Promise.all(cacheImages);
};

export default preloadImages;