  
  import { createClient } from '@supabase/supabase-js';

  
  const supabaseUrl = "https://ojcsvhfkvajrpjwdvbkc.supabase.co";
  const supabaseAnonKey =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9qY3N2aGZrdmFqcnBqd2R2YmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc3NDIxNDcsImV4cCI6MjAyMzMxODE0N30.MrjI-nWf70wZJSmvRMEK9qjEz_Iv_9qGhLp82SzvRSE";
  const supabase = createClient(supabaseUrl, supabaseAnonKey);
  export default supabase;