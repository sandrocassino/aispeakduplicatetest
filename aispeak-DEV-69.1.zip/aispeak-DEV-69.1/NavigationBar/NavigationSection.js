import { Platform, StyleSheet, View } from "react-native";
import NavigationTabItem from "./NavigationTabItem";
import { BlurView } from "expo-blur";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { dark } from "../constants";

const NavigationSection = ({
  handlePressnow,
  paperworkScale,
  iconScale,
  setPage,
  page,
}) => {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.navigationSectionContainer}>
      {Platform.OS === "android" && <View style={styles.androidContainer} />}

      <View
        style={{
          width: "100%",
          ...Platform.select({
            ios: {
              shadowColor: dark,
              shadowOffset: { width: 0, height: -4 },
              shadowOpacity: 0.25,
              shadowRadius: 12,
            },
          }),
        }}
      >
        <View style={styles.overflowHidden}>
          <BlurView
            intensity={Platform.OS === "ios" ? 10 : 7}
            tint="light"
            style={[styles.blurBox,               
              { paddingBottom: 10 + insets.bottom }
            ]}
          >

            {/* Home Tab */}
            <NavigationTabItem
              onPress={() => {
                setPage(7);
                handlePressnow(iconScale, 7);
              }}
              isActive={page === 7}
              icon={require("../assets/icons/home-simple.png")}
              activeIcon={require("../assets/icons/home-simple-blue.png")}
              label="Home"
            />

            {/* Chat Tab */}
            <NavigationTabItem
              onPress={() => {
                setPage(9);
              }}
              isActive={page === 6}
              icon={require("../assets/icons/chat-lines.png")}
              activeIcon={require("../assets/icons/chat-lines-blue.png")}
              label="Chat"
            />

            {/* My Progress Tab */}
            <NavigationTabItem
              onPress={() => {
                setPage(820);
                handlePressnow(paperworkScale, 820);
              }}
              isActive={page === 820}
              icon={require("../assets/icons/star.png")}
              activeIcon={require("../assets/icons/star-blue.png")}
              label="My Progress"
            />
          </BlurView>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  navigationSectionContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: "center",
    backgroundColor: "transparent",
  },
  androidContainer: {
    width: "90%",
    height: 10,
    backgroundColor: "transparent",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 30,
    zIndex: 1,
  },
  overflowHidden: {
    overflow: "hidden",
    backgroundColor: "transparent",
  },
  blurBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 16,
    backgroundColor:
      Platform.OS === "ios"
        ? "rgba(255, 255, 255, 0.12)"
        : "rgba(255, 255, 255, 0.15)",
    ...Platform.select({
      ios: {
        borderTopWidth: Platform.OS === "ios" ? 0.7 : 0,
        borderTopColor:
          Platform.OS === "ios" ? "rgba(255, 255, 255, 0.5)" : "transparent",
      },
    }),
  },
  reflectionOverlayContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 150,
    flexDirection: "column",
    pointerEvents: "none",
    zIndex: 1,
  },
  reflectionLayer: {
    width: "100%",
    height: 30,
  },
});

export default NavigationSection;
