import { View, TouchableOpacity, Text, Image } from "react-native";
import { lightBlue, newGray, nunito } from "../constants";

const NavigationTabItem = ({ onPress, isActive, icon, activeIcon, label }) => (
  <View style={{ width: 109, height: 60 }}>
    <TouchableOpacity onPress={onPress} style={{ alignItems: "center", justifyContent: "center" }}>
      <View
        style={{
          backgroundColor: isActive ? lightBlue : "transparent",
          borderRadius: 20,
          width: 40,
          height: 40,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 5,
        }}
      >
        <Image source={isActive ? activeIcon : icon} />
      </View>
      <Text
        style={{
          color: newGray,
          fontSize: 12,
          fontWeight: "500",
          lineHeight: 16,
          fontFamily: nunito,
          textAlign: "center",
        }}
      >
        {label}
      </Text>
    </TouchableOpacity>
  </View>
);

export default NavigationTabItem