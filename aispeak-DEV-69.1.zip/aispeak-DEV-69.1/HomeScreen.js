import { BlurView } from "expo-blur";
import "react-native-url-polyfill/auto";
import {
  StyleSheet,
  View,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableWithoutFeedback,
  Platform,
} from "react-native";
import { Animated } from "react-native";
import { Portal, Dialog, Button, Paragraph } from "react-native-paper";
import styles from "./Styles";
import "react-native-gesture-handler";
import { setisFirstChat } from "./App.js";
import { darkBlue, light, dark, yellow, newGray, nunito, blue } from "./constants.js";
import NavigationSection from "./NavigationBar/NavigationSection.js";

export default function HomeScreen(props) {
  // Destructure all the props you need from App.js:
  const {
    currentLevel,
    currentCount,
    currentCountAvanzado,
    currentCountIntermedio,
    currentCountPrincipiante,
    selectedOption,
    setSelectedOption,
    isTimeoutActive,
    handleQuestionMarkClick,
    handleStartNewChat,
    setCurrentCountPrincipiante,
    setCurrentCountIntermedio,
    setCurrentCountAvanzado,
    setCurrentLevel,
    setPage,
    page,
    showImageOnPage7,
    remainingTime,
    currentPlan,
    showQuestionMark,
    setShowQuestionMark,
    setQuestionMarkAndStorage,
    dialogVisible,
    setDialogVisible,
    handlePress,
    isClickable,
    colorImages,
    bwImages,
    chats,
    chatHistories,
    setChatKey,
    setShouldLoadMessages,
    setthirdchat,
    upgradetopro,
    setupgradetopro,
    youhaveregistered,
    showPopupnewer,
    handleClosePopup,
    showBlur,
    showOk,
    showOkbutton,
    setShowOk,
    setShowOkbutton,
    setBlur,
    paperworkScale,
    iconScale,
    documentScale,
    handlePressnow,
    screenHeight,
    showImage5,
    blur,
    // if you want to pass external styles or do your own
  } = props;

  // You can also get screen dimensions here (if needed)
  // const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

  // ---------------
  // Calculate the correct “displayLevel” & “displayCount” from props:
  // ---------------
  let displayLevel = currentLevel;
  let displayCount = currentCount;

  if (selectedOption === "Avanzado") {
    displayLevel = 3;
    displayCount = currentCountAvanzado;
  } else if (selectedOption === "Intermedio") {
    displayLevel = 2;
    displayCount = currentCountIntermedio;
  } else if (selectedOption === "Principiante") {
    displayLevel = 1;
    displayCount = currentCountPrincipiante;
  }


  const startingNewChat = () => {
    console.log("TouchableOpacity pressed - Initial state:", {
                isTimeoutActive,
                displayCount,
                displayLevel,
                selectedOption,
                currentCountPrincipiante,
                currentCountIntermedio,
                currentCountAvanzado,
              });

              // Check if the timeout is active
              if (isTimeoutActive) {
                console.log(
                  "Timeout is active, calling handleQuestionMarkClick"
                );
                handleQuestionMarkClick();
                console.log("Skipping further actions due to timeout");
                return;
              }

              console.log(
                "Timeout check passed, proceeding with count increment"
              );
              let newCount = displayCount + 1;
              console.log("New count calculated:", newCount);

              if (newCount >= 60 && displayLevel < 3 && displayCount < 60) {
                console.log("Entering level upgrade condition:", {
                  newCount,
                  displayLevel,
                  selectedOption,
                });

                if (selectedOption === "Principiante") {
                  console.log("Upgrading from Principiante to Intermedio");
                  setCurrentCountPrincipiante(newCount);
                  console.log("Set currentCountPrincipiante to:", newCount);
                  setSelectedOption("Intermedio");
                  console.log("Selected option changed to Intermedio");
                } else if (selectedOption === "Intermedio") {
                  console.log("Upgrading from Intermedio to Avanzado");
                  setCurrentCountIntermedio(newCount);
                  console.log("Set currentCountIntermedio to:", newCount);
                  setSelectedOption("Avanzado");
                  console.log("Selected option changed to Avanzado");
                } else if (selectedOption === "Avanzado") {
                  console.log("Already at Avanzado, updating count");
                  setCurrentCountAvanzado(newCount);
                  console.log("Set currentCountAvanzado to:", newCount);
                }

                console.log("Incrementing current level from:", displayLevel);
                setCurrentLevel(displayLevel + 1);
              } else if (displayLevel === 3) {
                console.log("At max level (3), updating Avanzado count");
                setCurrentCountAvanzado(newCount);
                console.log("Set currentCountAvanzado to:", newCount);
              } else {
                console.log("Regular count update for current level:", {
                  selectedOption,
                  newCount,
                });

                if (selectedOption === "Principiante") {
                  console.log("Updating Principiante count");
                  setCurrentCountPrincipiante(newCount);
                  console.log("Set currentCountPrincipiante to:", newCount);
                } else if (selectedOption === "Intermedio") {
                  console.log("Updating Intermedio count");
                  setCurrentCountIntermedio(newCount);
                  console.log("Set currentCountIntermedio to:", newCount);
                } else if (selectedOption === "Avanzado") {
                  console.log("Updating Avanzado count");
                  setCurrentCountAvanzado(newCount);
                  console.log("Set currentCountAvanzado to:", newCount);
                }
              }
  }


  return (
    <View style={styles.container}>
      <View>
        <View
          style={{
            position: "absolute",
            top: "70%",
            left: "5%",
            backgroundColor: light,
            height: 25,
            width: 65,
            borderRadius: 5,
            borderColor:
              selectedOption === "Principiante"
                ? "red"
                : selectedOption === "Intermedio"
                ? "green"
                : darkBlue,
            borderWidth: 1,
            justifyContent: "center", // Center vertically
            alignItems: "center", // Center horizontally
            zIndex: 0, // Ensure this container is on top
          }}
        >
          <Text
            style={{
              fontSize: 13,
              fontWeight: "900",
              color: dark,
              textAlign: "center",
              zIndex: 0, // Ensure the text is on top of the view
            }}
          >
            NIVEL {displayLevel}
          </Text>
        </View>

        <View
          style={{
            position: "absolute",
            top: "80%",
            left: "4%",
            backgroundColor:yellow,
            paddingVertical: 6,
            paddingHorizontal: 10,
            borderRadius: 50,
            ...Platform.select({
              ios: {
                shadowColor: dark,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
              },
              android: {
                elevation: 5,
              },
            }),
            zIndex: 0, // Ensure this view is beneath the NIVEL container
          }}
        >
          <Text style={{ fontSize: 22, color: light, fontWeight: "bold" }}>
            {displayCount}/
            {displayLevel === 3 || displayCount >= 60 ? (
              <>
                <Text style={{ fontSize: 22 }}>∞</Text>
              </>
            ) : (
              "60"
            )}
          </Text>
        </View>

        <View>
          <TouchableOpacity
            onPress={() => {
              console.log("TouchableOpacity pressed - Initial state:", {
                isTimeoutActive,
                displayCount,
                displayLevel,
                selectedOption,
                currentCountPrincipiante,
                currentCountIntermedio,
                currentCountAvanzado,
              });

              // Check if the timeout is active
              if (isTimeoutActive) {
                console.log(
                  "Timeout is active, calling handleQuestionMarkClick"
                );
                handleQuestionMarkClick();
                console.log("Skipping further actions due to timeout");
                return;
              }

              console.log(
                "Timeout check passed, proceeding with count increment"
              );
              let newCount = displayCount + 1;
              console.log("New count calculated:", newCount);

              if (newCount >= 60 && displayLevel < 3 && displayCount < 60) {
                console.log("Entering level upgrade condition:", {
                  newCount,
                  displayLevel,
                  selectedOption,
                });

                if (selectedOption === "Principiante") {
                  console.log("Upgrading from Principiante to Intermedio");
                  setCurrentCountPrincipiante(newCount);
                  console.log("Set currentCountPrincipiante to:", newCount);
                  setSelectedOption("Intermedio");
                  console.log("Selected option changed to Intermedio");
                } else if (selectedOption === "Intermedio") {
                  console.log("Upgrading from Intermedio to Avanzado");
                  setCurrentCountIntermedio(newCount);
                  console.log("Set currentCountIntermedio to:", newCount);
                  setSelectedOption("Avanzado");
                  console.log("Selected option changed to Avanzado");
                } else if (selectedOption === "Avanzado") {
                  console.log("Already at Avanzado, updating count");
                  setCurrentCountAvanzado(newCount);
                  console.log("Set currentCountAvanzado to:", newCount);
                }

                console.log("Incrementing current level from:", displayLevel);
                setCurrentLevel(displayLevel + 1);
              } else if (displayLevel === 3) {
                console.log("At max level (3), updating Avanzado count");
                setCurrentCountAvanzado(newCount);
                console.log("Set currentCountAvanzado to:", newCount);
              } else {
                console.log("Regular count update for current level:", {
                  selectedOption,
                  newCount,
                });

                if (selectedOption === "Principiante") {
                  console.log("Updating Principiante count");
                  setCurrentCountPrincipiante(newCount);
                  console.log("Set currentCountPrincipiante to:", newCount);
                } else if (selectedOption === "Intermedio") {
                  console.log("Updating Intermedio count");
                  setCurrentCountIntermedio(newCount);
                  console.log("Set currentCountIntermedio to:", newCount);
                } else if (selectedOption === "Avanzado") {
                  console.log("Updating Avanzado count");
                  setCurrentCountAvanzado(newCount);
                  console.log("Set currentCountAvanzado to:", newCount);
                }
              }

              handleStartNewChat();

              // Log final state after all updates
              console.log("Final state after updates:", {
                newCount,
                displayLevel,
                selectedOption,
                currentCountPrincipiante,
                currentCountIntermedio,
                currentCountAvanzado,
              });
            }}
            style={{
              alignSelf: "center",
              marginTop: "40%",
              marginLeft: "3%",
              width: "42%",
            }}
          >
            {showImageOnPage7 && (
              <Image
                source={require("./assets/images/hold-pressed-bell.png")}
                style={{
                  position: "absolute",
                  zIndex: 200,
                  top: -32,
                  left: 190,
                  width: 50,
                  height: 50,
                }}
              />
            )}
            <View
              style={{
                backgroundColor: light,
                paddingVertical: 27,
                paddingHorizontal: 8,
                borderRadius: 45,
                justifyContent: "center",
                alignItems: "center",
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
                width: "100%",
              }}
            >
              <View
                style={{
                  backgroundColor: "",
                  paddingVertical: 2.7,
                  paddingHorizontal: 20.25,
                  borderRadius: 45,
                }}
              >
                <Text
                  style={{
                    fontWeight: "bold",
                    fontSize: 13,
                    color: dark,
                    position: "absolute",
                    top: -15,
                    left: -13,
                  }}
                >
                  Iniciar un{"\n"}nuevo chat
                </Text>
              </View>
              <Image
                source={
                  selectedOption === "Principiante"
                    ? require("./assets/images/capy-hd.png")
                    : selectedOption === "Intermedio"
                    ? require("./assets/images/capy-with-hat.png")
                    : require("./assets/images/capy-with-crown.png")
                }
                style={{
                  position: "absolute",
                  top: -35,
                  right: "42.5%",
                  width: 52,
                  height: 52,
                }}
              />
            </View>
          </TouchableOpacity>

          {/* <TouchableOpacity
            onPress={() => setPage(1800)}
            style={{ position: "absolute", top: -5, alignSelf: "center" }}
          > */}
            <Image
              source={require("./assets/images/old-logo-and-brand.png")}
              style={{
                width: 100,
                height: 100,
                resizeMode: "contain",
                position: "absolute",
                top: -5, alignSelf: "center"
              }}
            />
          {/* </TouchableOpacity> */}
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              width: 200, // Adjust the width as needed
              height: 200, // Adjust the height as needed
              position: "absolute",
              top:
                screenHeight >= 896
                  ? "40%"
                  : screenHeight >= 820
                  ? "35%"
                  : screenHeight >= 817
                  ? "37%"
                  : "32%",

              right: screenHeight >= 896 ? "-15%" : "-17%",
            }}
          >
            <Image
              source={
                isTimeoutActive
                  ? require("./assets/icons/blue-circle-white-filled.png")
                  : selectedOption === "Principiante"
                  ? require("./assets/images/capy-in-white-circle.png")
                  : selectedOption === "Intermedio"
                  ? require("./assets/images/capy-with-hat-in-white-circle.png")
                  : selectedOption === "Avanzado"
                  ? require("./assets/images/capy-with-crown-in-white-circle.png")
                  : null
              }
              style={{
                width: "33%",
                height: "33%",

                resizeMode: "contain",
              }}
            />
            {isTimeoutActive && (
              <Text
                style={{
                  fontWeight: "bold",
                  position: "absolute",
                  color: dark,
                  fontSize: 15,
                }}
              >
                {
                  remainingTime > 60000
                    ? new Date(remainingTime).toISOString().substr(11, 5) // Show hh:mm format for times greater than 1 minute
                    : `00:${String(
                        Math.floor((remainingTime % 60000) / 1000)
                      ).padStart(2, "0")}` // Show mm:ss for the last minute
                }
              </Text>
            )}
            {isTimeoutActive && currentPlan !== "Pro" && (
              <Image
                source={require("./assets/images/zzz.gif")}
                style={{
                  position: "absolute",
                  top: screenHeight >= 896 ? "18%" : "18%",

                  width: 80,
                  height: 80,
                  resizeMode: "contain",
                }}
              />
            )}
          </View>
          {showQuestionMark && currentPlan !== "Pro" && (
            <TouchableOpacity
              onPress={() => {
                handleQuestionMarkClick();
                setShowQuestionMark(false);
                setQuestionMarkAndStorage(true); // Update state and AsyncStorage
              }}
              style={{
                position: "absolute",
                top:
                  screenHeight >= 896
                    ? "22%"
                    : screenHeight >= 820
                    ? "14%"
                    : screenHeight >= 817
                    ? "19%"
                    : "14%",
                left: screenHeight >= 896 ? "63%" : "58%",
                width: 200,
                height: 200,
              }}
            >
              <Image
                source={require("./assets/icons/white-question-mark-blue-round-bubble-bg.png")}
                style={{
                  width: "100%",
                  height: "100%",
                  resizeMode: "contain",
                }}
              />
            </TouchableOpacity>
          )}
        </View>
      </View>
      <Portal>
        <Dialog
          visible={dialogVisible}
          onDismiss={() => setDialogVisible(false)}
        >
          <Dialog.Title>Elige a tu buddy</Dialog.Title>
          <Dialog.Content>
            <View style={{ width: 200, height: 200, position: "relative" }}>
              <Image
                source={require("./assets/images/old-circle.png")}
                style={{
                  position: "absolute",
                  top: "-15%",
                  right: "-30%",
                  width: 250,
                  height: 250,
                }}
              />
              <TouchableOpacity
                onPress={() => handlePress(0)}
                style={{
                  position: "absolute",
                  top: 50,
                  left: "40%",
                  width: 40,
                  height: 40,
                }}
              >
                <Image
                  source={isClickable[0] ? colorImages[0] : bwImages[0]}
                  style={{ width: "100%", height: "100%" }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handlePress(1)}
                style={{
                  position: "absolute",
                  top: "55%",
                  left: "38%",
                  width: 40,
                  height: 40,
                }}
              >
                <Image
                  source={isClickable[1] ? colorImages[1] : bwImages[1]}
                  style={{ width: "100%", height: "100%" }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handlePress(2)}
                style={{
                  position: "absolute",
                  bottom: 32,
                  left: "62%",
                  width: 40,
                  height: 40,
                }}
              >
                <Image
                  source={isClickable[2] ? colorImages[2] : bwImages[2]}
                  style={{ width: "100%", height: "100%" }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handlePress(3)}
                style={{
                  position: "absolute",
                  top: "42%",
                  right: 0,
                  width: 40,
                  height: 40,
                }}
              >
                <Image
                  source={isClickable[3] ? colorImages[3] : bwImages[3]}
                  style={{ width: "100%", height: "100%" }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handlePress(4)}
                style={{
                  position: "absolute",
                  top: "17%",
                  right: "12%",
                  width: 40,
                  height: 40,
                }}
              >
                <Image
                  source={isClickable[4] ? colorImages[4] : bwImages[4]}
                  style={{ width: "100%", height: "100%" }}
                />
              </TouchableOpacity>
            </View>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDialogVisible(false)}>OK</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
      <ScrollView
        style={{ marginBottom: 200, marginTop: 90 }}
        ref={(ref) => {
          scrollViewRef = ref;
        }}
        onContentSizeChange={() =>
          scrollViewRef.scrollToEnd({ animated: true })
        }
      >
        {chats.map((chat) => (
          <TouchableOpacity
            key={chat}
            onPress={async () => {
              if (isTimeoutActive) {
                setthirdchat(true);
              }

              setPage(6);
              setisFirstChat(false);
              setChatKey(chat);
              setShouldLoadMessages(true);
              setChatHistory(chatHistories[chat] || []);
            }}
            style={{ alignSelf: "center", marginTop: "5%", width: "70%" }}
          >
            <View
              style={{
                backgroundColor: light,
                padding: 9,
                borderRadius: 45,
                justifyContent: "center",
                alignItems: "center",
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
                width: "100%",
              }}
            >
              <View
                style={{
                  backgroundColor: "",
                  paddingVertical: 5.4,
                  paddingHorizontal: 40.5,
                  borderRadius: 45,
                }}
              >
                <Text
                  style={{
                    fontWeight: "bold",
                    fontSize: 19,
                    color: dark,
                  }}
                >
                  Chat {chat}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
        <View style={{ height: 100 }} />
      </ScrollView>
      {upgradetopro && currentPlan !== "Pro" && (
        <BlurView
          style={StyleSheet.absoluteFill}
          blurType="light"
          blurAmount={10}
        >
          <View
            style={{
              position: "absolute",
              top: 310, // Adjusted to center vertically
              zIndex: 200,
              left: 50, // Margin from the left
              right: 50, // Margin from the right
              justifyContent: "center",
              alignItems: "center",
              borderColor: darkBlue,
              borderWidth: 1,
              backgroundColor: light, // White background
              padding: 25, // Padding for space around the text
              borderRadius: 10, // Rounded corners
              ...Platform.select({
                ios: {
                  shadowColor: dark,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                },
                android: {
                  elevation: 5,
                },
              }),
            }}
          >
            <Text style={{ fontSize: 18, color: dark, textAlign: "center" }}>
              ¿Quieres actualizar{"\n"}a Pro y chatear{"\n"}ilimitadamente? 🚀
            </Text>
            <View style={{ flexDirection: "row", marginTop: 20 }}>
              <TouchableOpacity
                onPress={() => {
                  setupgradetopro(false);
                  // Navigate to page 9
                  setPage(4000); // Assuming you have a function or state for setting the current page
                }}
                style={{
                  backgroundColor: yellow,
                  borderRadius: 20,
                  padding: 10,
                  width: 65,
                  borderColor: dark,
                  borderWidth: 2,
                  marginHorizontal: 10,
                }}
              >
                <Text
                  style={{
                    color: dark,
                    textAlign: "center",
                    fontWeight: "bold",
                  }}
                >
                  Sí
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setupgradetopro(false)}
                style={{
                  backgroundColor: yellow,
                  borderRadius: 20,
                  padding: 10,
                  width: 65,
                  borderColor: dark,
                  borderWidth: 2,
                  marginHorizontal: 10,
                }}
              >
                <Text
                  style={{
                    color: dark,
                    textAlign: "center",
                    fontWeight: "bold",
                  }}
                >
                  No
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </BlurView>
      )}

      {youhaveregistered && (
        <BlurView
          style={StyleSheet.absoluteFill}
          blurType="light"
          blurAmount={10}
        >
          <View
            style={{
              position: "absolute",
              top: 310, // Adjusted to center vertically
              zIndex: 200,
              left: 50, // Margin from the left
              right: 50, // Margin from the right
              justifyContent: "center",
              alignItems: "center",
              borderColor: darkBlue,
              borderWidth: 1,
              backgroundColor: light, // White background
              padding: 25, // Padding for space around the text
              borderRadius: 10, // Rounded corners
              ...Platform.select({
                ios: {
                  shadowColor: dark,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                },
                android: {
                  elevation: 5,
                },
              }),
            }}
          >
            <Text style={{ fontSize: 18, color: dark, textAlign: "center" }}>
              ¡Has creado una{"\n"}cuenta con éxito!{"\n"}✅{"\n"}
              Revisa tu correo para verificar tu cuenta. 
            </Text>
          </View>
        </BlurView>
      )}

      {showPopupnewer && currentPlan !== "Pro" && (
        <BlurView
          style={StyleSheet.absoluteFill}
          blurType="light"
          blurAmount={10}
        >
          <View
            style={{
              position: "absolute",
              top: 310, // Adjusted to center vertically
              zIndex: 200,
              left: 50, // Added margin from the left
              right: 50, // Added margin from the right
              justifyContent: "center",
              alignItems: "center",
              borderColor: darkBlue,
              borderWidth: 1,
              backgroundColor: light, // White background
              padding: 25, // Added padding for space around the text
              borderRadius: 10, // Rounded corners
              ...Platform.select({
                ios: {
                  shadowColor: dark,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                },
                android: {
                  elevation: 5,
                },
              }),
            }}
          >
            <Text style={{ fontSize: 18, color: dark, textAlign: "center" }}>
              ¡Tienes que esperar un poco más hasta que puedas chatear de
              nuevo!🤔 Has alcanzado el límite de 3 chats para hoy.
              {"\n\n"}
              ¡Cuando hayan pasado las 12 horas completas, podrás volver a
              chatear con Aispeak 😄
            </Text>
            <Image
              source={require("./assets/images/timeout-clock.png")}
              style={{
                position: "absolute",
                top: -35,
                left: 20,
                width: 60,
                height: 60,
                resizeMode: "contain",
              }}
            />
            <TouchableOpacity
              onPress={handleClosePopup}
              style={{
                position: "absolute",
                top: 10,
                right: 10,
              }}
            >
              <Text
                style={{
                  fontSize: 20,
                  color: darkBlue,
                  fontWeight: "bold",
                }}
              >
                X
              </Text>
            </TouchableOpacity>
          </View>
        </BlurView>
      )}
      {showBlur && showOk && (
        <BlurView intensity={blur} style={StyleSheet.absoluteFill}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              position: "absolute",
              bottom: 0,
              left: 0,
              right: 0,
              paddingVertical: -60,
              top: 750,
            }}
          >
            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 285 : 150,
                right: "75%",
              }}
            >
              <Image
                source={require("./assets/icons/black-arrow-down-no-bg.png")}
                style={[styles.image102, { resizeMode: "contain" }]}
              />
            </View>

            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 275 : 140,
                right: "45%",
              }}
            >
              <Image
                source={require("./assets/icons/black-arrow-down-no-bg.png")}
                style={[styles.image102, { resizeMode: "contain" }]}
              />
            </View>

            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 285 : 150,
                right: "13%",
              }}
            >
              <Image
                source={require("./assets/icons/black-arrow-down-no-bg.png")}
                style={[styles.image102, { resizeMode: "contain" }]}
              />
            </View>

            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 345 : 210,
                right: "60%",
              }}
            >
              <Text
                style={{ color: dark, fontSize: 20, fontWeight: "bold" }}
              >
                Tu progreso
              </Text>
            </View>

            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 320 : 185,
                right: "45%",
              }}
            >
              <Text
                style={{ color: dark, fontSize: 20, fontWeight: "bold" }}
              >
                Inicio
              </Text>
            </View>

            <View
              style={{
                position: "absolute",
                bottom: screenHeight <= 667 ? 345 : 210,
                right: "7%",
              }}
            >
              <Text
                style={{ color: dark, fontSize: 20, fontWeight: "bold" }}
              >
                Configuración
              </Text>
            </View>
          </View>
        </BlurView>
      )}
      {showImage5 && (
        <>
        <NavigationSection currentPage={7} handlePressnow={handlePressnow} paperworkScale={paperworkScale} iconScale={iconScale} setPage={setPage} page={page} documentScale={documentScale} />
        </>       
      )}

      {showBlur && showOkbutton && (
        <View
          style={{
            backgroundColor: yellow,
            borderRadius: 20,
            padding: 10,
            marginRight: 20,
            borderColor: dark,
            borderWidth: 4, // Add this line to apply the border
            zIndex: 200,
            position: "absolute",
            top: 330,
            alignSelf: "center",
            width: 100,
          }}
        >
          <TouchableWithoutFeedback
            onPress={() => {
              setShowOk(false);
              setShowOkbutton(false);
              setBlur(0);
            }}
          >
            <Text
              style={{
                color: dark,
                textAlign: "center",
                fontWeight: "bold",
              }}
            >
              Ok!
            </Text>
          </TouchableWithoutFeedback>
        </View>
      )}
    </View>
  );
}
