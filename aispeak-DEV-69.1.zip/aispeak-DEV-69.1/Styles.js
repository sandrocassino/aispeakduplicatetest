import { StyleSheet, Dimensions, Platform} from "react-native";
import { light, dark, darkGray, yellow, lightGray, blue, gray, red, SourceSans, NunitoBold, NunitoRegular, } from "./constants";

const screenHeight = Dimensions.get("window").height;
const screenWidth = Dimensions.get("window").width;

const Styles = StyleSheet.create({
  // All the original styles remain here - keeping all these intact
  subscriptionContainer: {
    flex: 1,
  },
  subscriptionTop: {
    flex: 1,
    backgroundColor: yellow,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 15, // Decreased from 30
  },
  subscriptionBottomTop: {
    flex: 3,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    paddingTop: 5, // Decreased from 15
    paddingLeft: 20,
  },
  modalContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)", // Semi-transparent black background
  },
  modalContent: {
    backgroundColor: light,
    padding: 20,
    borderRadius: 10,
    width: "80%",
    alignItems: "center",
  },
  subscriptionBottomBottom: {
    flex: 6,
    backgroundColor: yellow,
    justifyContent: "flex-start",
    alignItems: "flex-start",
    paddingTop: 15, // Decreased from 30
    paddingLeft: 20,
  },
  centeredText: {
    fontSize: 20, // Set the font size
    color: light, // Set the text color to light
    fontWeight: "bold", // Make the text bold
  },
  leftText: {
    fontSize: 24, // Set the font size
    color: darkGray, // Set the text color
    fontWeight: "800", // Make the text bold
  },
  leftText2: {
    fontSize: 18, // Set the font size
    color: darkGray, // Set the text color
    fontWeight: "800", // Make the text bold
    zIndex: 21,
  },
  leftText3: {
    fontSize: 14, // Set the font size
    color: darkGray, // Set the text color
    fontWeight: "800", // Make the text bold
    zIndex: 21,
  },
  smallText: {
    fontSize: 14, // Set the font size
    color: darkGray, // Set the text color
    fontWeight: "800", // Make the text bold
    zIndex: 21,
  },
  rectangle: {
    width: "120%", // Set the width to 90% of the parent view
    height: 80, // Set a fixed height
    backgroundColor: light, // Set the background color to light
    marginTop: 20, // Increase the margin to the top
    borderRadius: 20, // Increase the border radius for more rounded corners
    borderColor: "transparent", // Make the border transparent when not selected
    borderWidth: 2, // Always include the border in the layout
  },
  rectanglesmallphone: {
    width: "60%", // Set the width to 90% of the parent view
    height: 40, // Set a fixed height
    backgroundColor: light, // Set the background color to light
    marginTop: 20, // Increase the margin to the top
    borderRadius: 20, // Increase the border radius for more rounded corners
    borderColor: "transparent", // Make the border transparent when not selected
    borderWidth: 2, // Always include the border in the layout
  },
  rectangle2: {
    width: "120%", // Set the width to 90% of the parent view
    height: 80, // Set a fixed height
    backgroundColor: light, // Set the background color to transparent
    marginTop: 20, // Increase the margin to the top
    borderRadius: 20, // Increase the border radius for more rounded corners
    borderColor: "blue", // Make the border blue when selected
    borderWidth: 2, // Always include the border in the layout
    zIndex: 6,
  },
  rectanglenuevo: {
    width: 50, // Adjust as needed
    height: 50, // Adjust as needed
    backgroundColor: light,
    borderRadius: 10,
    borderColor: dark,
    borderWidth: 2,
  },
  lightRectangle: {
    height: 200,
    width: "100%",
    backgroundColor: light,
    alignSelf: "center",
    position: "absolute",
    bottom: screenHeight * 0.24,
    ...Platform.select({
      ios: {
        shadowColor: dark,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  lightRectanglesmall: {
    height: 200,
    width: "100%",
    backgroundColor: light,
    alignSelf: "center",
    position: "absolute",
    bottom: screenHeight * 0.1,
    ...Platform.select({
      ios: {
        shadowColor: dark,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  nextButton: {
    width: "70%",
    height: 40, // Adjust this value as per your requirement
    backgroundColor: light,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    borderRadius: 10, // Add some border radius for curved corners
    bottom: screenHeight * 0.1,
  },
  nextButtonsmall: {
    width: "70%",
    height: 40, // Adjust this value as per your requirement
    backgroundColor: light,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    borderRadius: 10, // Add some border radius for curved corners
    bottom: screenHeight * 0.02,
  },
  nextButtonText: {
    fontSize: 20, // Set the font size
    color: dark, // Set the text color to black
    fontWeight: "bold", // Make the text bold
  },
  container: {
    flex: 1,
    backgroundColor:yellow,
    paddingTop: 20,
    paddingHorizontal: 20,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imageclone: {
    width: 90,
    height: 90,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imagenewer: {
    width: 70,
    height: 70,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imagenewer2: {
    width: 80,
    height: 80,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imagenewersmall: {
    width: 50,
    height: 50,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imagenewersmaller: {
    width: 30,
    height: 30,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  imagenewer3: {
    width: 85,
    height: 85,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image1: {
    width: 350,
    height: 350,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image2: {
    width: 60,
    height: 60,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image3: {
    width: 140,
    height: 140,
  },
  image4: {
    width: 180,
    height: 180,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image44: {
    width: 200,
    height: 200,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image5: {
    width: 35,
    height: 35,
  },
  image6: {
    width: 300,
    height: 300,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image610: {
    width: 230,
    height: 230,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image67: {
    width: 150,
    height: 150,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  image66: {
    width: 50,
    height: 50,
  },
  image90: {
    width: 100,
    height: 100,
    borderRadius: 10,
    alignSelf: "center",
    marginBottom: 15,
  },
  image7: {
    width: 60,
    height: 45,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  rectanglenewer: {
    width: "90%",
    height: "60%", // Adjust as needed
    backgroundColor: light,
    padding: 20,
    bottom: -180,
    left: 20,
    borderColor: dark,
    borderWidth: 4,
  },
  titlenewer: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  textnewer: {
    fontSize: 16,
  },
  image8: {
    width: 100,
    height: 100,
  },
  image88: {
    width: 60,
    height: 60,
  },
  image10: {
    width: 60,
    height: 60,
  },
  image100: {
    width: 70,
    height: 70,
  },
  image101: {
    width: 100,
    height: 100,
  },
  image102: {
    width: 40,
    height: 40,
  },
  image11: {
    width: 120,
    height: 120,
  },
  image80: {
    width: 30,
    height: 30,
    borderRadius: 8,
    alignSelf: "center",
    marginBottom: 15,
  },
  text1: {
    fontFamily: SourceSans,
    fontSize: 25,
    fontWeight: "bold",
    alignSelf: "center",
    marginBottom: 15,
  },
  text01: {
    fontFamily: SourceSans,
    fontSize: 25,
    fontWeight: "bold",
    alignSelf: "center",
    marginBottom: 15,
  },
  text13: {
    fontFamily: SourceSans,
    fontSize: 24,
    fontWeight: "bold",
    alignSelf: "center",
    marginBottom: 15,
  },
  text2: {
    fontFamily: NunitoBold,
    fontSize: 16,
    alignSelf: "center",
  },
  text3: {
    fontFamily: SourceSans,
    fontSize: 16,
    fontWeight: "bold",
    alignSelf: "center",
    marginBottom: 15,
  },
  text31: {
    fontFamily: SourceSans,
    fontSize: 11,
    alignSelf: "center",
    marginBottom: 15,
  },
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  circle: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5,
    backgroundColor: light,
  },
  selectedCircle: {
    backgroundColor: dark,
  },
  arrow: {
    width: 60,
    height: 60,
  },
  blankPage: {
    flex: 1,
    backgroundColor:yellow,
    justifyContent: "center",
    alignItems: "center",
  },
  lightBox: {
    backgroundColor: light,
    paddingVertical: 150,
    paddingHorizontal: 40,
    borderRadius: 10,
  },
  button: {
    backgroundColor: light,
    padding: 10,
    borderRadius: 5,
  },
  question: {
    fontSize: 18,
    fontWeight: "bold",
    marginVertical: 10,
  },
  input: {
    height: 40,
    width: 200,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: dark,
    paddingHorizontal: 10,
  },

  // New styles to match the screenshot
  modernContainer: {
    flex: 1,
    backgroundColor: light,
  },
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: yellow,
    padding: 16,
  },
  headerText: {
    color: light,
    fontSize: 22,
    fontWeight: "bold",
    marginLeft: 8,
  },
  contentContainer: {
    flex: 1,
    padding: 24,
  },
  titleText: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  subtitleText: {
    fontSize: 16,
    color: darkGray,
    marginBottom: 32,
    textAlign: "center",
  },
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 20,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  inputIcon: {
    marginRight: 10,
  },
  modernInput: {
    flex: 1,
    paddingVertical: 14,
  },
  termsContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 24,
  },
  checkbox: {
    marginRight: 8,
    paddingTop: 2,
  },
  termsText: {
    flex: 1,
    color: gray,
    fontSize: 14,
  },
  termsLink: {
    color: blue,
  },
  modernButton: {
    backgroundColor: blue,
    borderRadius: 20,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 16,
  },
  modernButtonText: {
    color: light,
    fontWeight: "bold",
    fontSize: 16,
  },
  errorText: {
    color: "red",
    marginBottom: 8,
  },
  successText: {
    color: "green",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 8,
  },
  loginContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 8,
  },
  loginText: {
    color: gray,
  },
  loginLink: {
    color: blue,
    fontWeight: "bold",
  },
  backArrowContainer: {
    position: "absolute",
    bottom: 20,
    right: 20,
  },

//   /*********************************************/
//   /*      NEW / UPDATED LOGIN SCREEN STYLES    */
//   /*********************************************/

//   // Overall container with yellow background
//   newLoginContainer: {
//     paddingTop: 32,
//     flex: 1,
//     backgroundColor:yellow,
//     justifyContent: "flex-start",
//   },

//   // Header section: big title + subtitle
//   newLoginHeader: {
//     marginTop: 40,
//     paddingHorizontal: 24,
//   },
//   // newLoginTitle: {
//   //   fontSize: 30,
//   //   color: dark,
//   //   marginBottom: 10,
//   //   fontFamily: NunitoRegular,
//   //   fontWeight: 700,
//   //   lineHeight: 36,

//   // },
//   // newLoginSubtitle: {
//   //   fontSize: 16,
//   //   color: dark,
//   //   marginBottom: 45,
//   //   fontFamily: SourceSans,
//   //   fontStyle: 'normal',
//   //   fontWeight: 400,
//   //   lineHeight: 24,
//   // },

//   // Form area for inputs and button
//   newLoginForm: {
//     padding: 8,
//     marginBottom: 24,  
//   },

//   // Wrapper around each TextInput (slightly rounded, light background)
//   inputWrapperYellow: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: light,
//     borderRadius: 24,
//     marginBottom: 16,
//     paddingHorizontal: 16,
//   },
//   newLoginInput: {
//     flex: 1,
//     paddingVertical: 14,
//     fontSize: 15,
//     color: dark,
//   },

//   // Blue login button
//   newLoginButton: {
//     backgroundColor: blue,
//     borderRadius: 24,
//     paddingVertical: 16,
//     alignItems: "center",
//     marginTop: 23,
//     marginBottom: 20,
//   },
//   newLoginButtonText: {
//     color: light,
//     fontWeight: "bold",
//     fontSize: 16,
//   },

//   // "Forgot password" text
//   forgotPassContainer: {
//     alignSelf: "center",
//   },
//   forgotPassText: {
//     color: dark,
//     fontSize: 16,
//   },

//   // Footer (register link) at the bottom
//   newLoginFooter: {
//     position: "absolute",
//     bottom: 40,
//     left: 0,
//     right: 0,
//     flexDirection: "row",
//     justifyContent: "center",
//   },
//   footerQuestion: {
//     color: dark,
//   },
//   footerLink: {
//     color: blue,
//     fontWeight: "bold",
//   },

//   // Optionally reuse your existing errorText & successText styles:
//   errorText: {
//     color: "red",
//     marginBottom: 8,
//     textAlign: "center",
//   },
//   successText: {
//     color: "green",
//     fontSize: 14,
//     textAlign: "center",
//     marginBottom: 8,
//   },

//   errorTextUnderField: {
//     color: red,
//     fontSize: 50,
//     marginTop: 5,
//     marginBottom: 10,
//     marginLeft: 10,
//   },
});

export default Styles;
