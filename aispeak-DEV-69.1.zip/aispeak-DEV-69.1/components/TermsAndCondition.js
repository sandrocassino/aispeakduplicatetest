import { StyleSheet } from "react-native";
import { Text, TouchableOpacity, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import {
  inputRed,
  blue,
  light,
  dark,
  sourceSans,
  sourceSansBold,
} from "../constants";
import { Platform } from "react-native";

const TermsAndConditions = ({ acceptTerms, setAcceptTerms, termsError }) => {
  const openTermsOfService = async () => {
    try {
      await Linking.openURL("https://www.aispeakapp.com/trminos-y-condiciones");
    } catch (error) {
      console.error("Error opening Terms of Service:", error);
    }
  };

  const openPrivacyPolicy = async () => {
    try {
      await Linking.openURL("https://www.aispeakapp.com/poltica-de-privacidad");
    } catch (error) {
      console.error("Error opening Privacy Policy:", error);
    }
  };

  return (
    <>
      <View style={styles.termsAndConditionsContainer}>
        <TouchableOpacity
          onPress={() => setAcceptTerms(!acceptTerms)}
          style={{ marginRight: 10 }}
        >
          <View style={styles.checkboxBox}>
            {acceptTerms && (
              <Ionicons name="checkmark" size={16} color="#017CFE" />
            )}
          </View>
        </TouchableOpacity>
        <Text style={styles.termsAndConditonsText}>
          Al registrarte, aceptas los{" "}
          <Text
            onPress={openTermsOfService}
            style={styles.termsAndConditonsTextBlue}
          >
            Términos y Condiciones
          </Text>{" "}
          de uso del servicio y las{" "}
          <Text
            onPress={openPrivacyPolicy}
            style={styles.termsAndConditonsTextBlue}
          >
            Políticas de Privacidad
          </Text>
          .
        </Text>
      </View>
      {termsError ? (
        <Text style={styles.errorTextUnderField}>{termsError}</Text>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  termsAndConditionsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 32,
    marginBottom: 32,
    paddingHorizontal: Platform.OS === "ios" ? 12 : 16,
  },
  termsAndConditonsText: {
    flex: 1,
    fontSize: 14,
    color: dark,
    lineHeight: 20,
    fontFamily: sourceSans,
  },
  termsAndConditonsTextBlue: {
    color: blue,
    lineHeight: 20,
    fontFamily: sourceSansBold,
    textDecorationLine: "underline",
  },
  errorTextUnderField: {
    color: inputRed,
    fontSize: 16,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: -10,
  },
  successText: {
    backgroundColor: blue,
    color: light,
    fontSize: 16,
  },
  checkboxBox: {
    width: 20,
    height: 20,
    backgroundColor: "white",
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default TermsAndConditions;
