# Aispeak

This README.md aims to set some ground rules and be a single source of truth for the best practices to follow withtin the software engineering team.

Table of Contents:
- [Setting up the development environment](#setting-up-the-development-environment)
- [Git branching best practices](#git-branching-best-practices)
- [Building the app and publishing it](#building-the-app-and-publishing-it)

---

## Setting up the development environment

### **1. Clone the Repository from GitHub**

   - Open a terminal on your PC.
   - Run the following command to clone the repository:
     ```bash
     git clone https://github.com/rwintgen/aispeak.git
     ```

---

### **2. Set Up the Project Locally**

1. **Install Node.js:**

   - Make sure Node.js is installed. Download it from [Node.js Official Site](https://nodejs.org/).

2. **Install Expo CLI:**

   - Expo CLI is required to run and test the Expo app. Install it globally using npm:
     ```bash
     npm install -g expo-cli
     ```

---

### **3. Run and Test the Expo App**

1. **Start the Development Server:**

   - Run the Expo development server:
     ```bash
     npx expo start
     ```

2. **Run the App on Your Device/Emulator:**

   - **On Physical Device:**
     - Install the Expo Go app.
     - Scan the QR code shown in the terminal.
   - **On Emulator/Simulator:**
     - **Android Emulator:**
       - Start an Android Virtual Device (AVD) using Android Studio.
       - Press `a` in the terminal to open the app in the Android emulator.
     - **iOS Simulator (Mac only):**
       - Start the iOS Simulator.
       - Press `i` in the terminal to open the app in the iOS simulator.

3. **Testing with a Development Build:**
   - You can also test your app using a custom development build, which allows you to test native modules and features not available in Expo Go.
   - To open the development build launcher, press `s` in the terminal after running `npx expo start`.
   - For instructions on how to create a development build, see the [Building for iOS](#building-for-ios) or [Building for Android](#building-for-android) sections below.


4. **Debugging and Live Reload:**
   - Modify the code in your editor (e.g., VSCode), and the app will reload automatically.
   - Use `console.log` for debugging.

---

### **4. Commit and Push Code to GitHub**

1. **Stage and Commit Changes:**

   - Check the status of your changes:
     ```bash
     git status
     ```
   - Add the files you modified:
     ```bash
     git add .
     ```
   - Commit the changes with a meaningful message:
     ```bash
     git commit -m "Your commit message"
     ```
   - Push Changes to the Repository:**
      ```bash
      git push
      ```

---

## Git Branching Best Practices

### **Working with Git**

1. **Always sync with the remote repository before starting work:**
   ```bash
   git fetch
   git pull
   ```
2. **Create a new branch for each new feature, fix, or task:**
   ```bash
   git checkout -b <branch-name>
   ```
3. **Open a pull request to merge your branch into the main development branch when your work is ready for review.**

---

### **Branch Naming Convention**

- With the exception of special branches (see below), all branches should follow this structure:
  - **One main branch per project** with a clear, descriptive name.
  - **Feature or task branches** should be named as follows:
    ```
    <project-name>/<Jira-ID>/<short-description-in-kebab-case>
    ```
    *Example:*  
    `aispeak/DEV-123/add-login-screen`

---

### **Special Branches**

- `main`: The latest stable, production-ready version of the app.
- `dev-env`: The primary development branch; most up-to-date and generally stable. All feature branches should be based on `dev-env`.
- `testing-build`: A branch cloned from `dev-env` used specifically for building and testing pre-release versions.
- `code-refactor`: Dedicated to large-scale code improvements and architectural changes.

---

## Building the App and Publishing It

### **Version Naming Conventions**

Version numbers follow the format: `XXX.YYY.ZZZ`

- **XXX** – **Major version**  
  Starts at `1`. Increment this number for significant releases, major new features, or breaking changes.

- **YYY** – **Feature version**  
  Starts at `0`. Increment for each new feature. Reset to `0` when the major version increases.

- **ZZZ** – **Patch version**  
  Starts at `0`. Increment for bug fixes or minor improvements. Reset to `0` when the feature version increases.

---

### Building for iOS
<details>
<summary>Show instructions</summary>

1. **Update Metadata:**
   - Update the version or buildNumber in `package.json` **(not required for development build)**.
   - Update the project ID in `app.json`. It must match the project ID of your Expo account. Check with:
     ```bash
     eas whoami
     ```
   - Example project ID: `3f9e7957-4b18-46e5-af0a-2222e0044fed`

2. **Development build**
   - Make sure you have an [expo.dev](https://expo.dev) account and are logged in:
     ```bash
     eas login
     ```
   - Ensure you are on the `dev-env` branch.
   - Run the following command:
     ```bash
     eas build --platform ios --profile development
     ```
   - When prompted, log in with the Apple Developer account linked to your professional email (e.g., name.surname@aispeakapp.com). If you don't have one, create it and ask @rwintgen for an invite to join the Apple Developer program.
   - Link an Apple device if required.
   - Wait for the build to finish. Go to your expo.dev dashboard, click on the build, and follow the instructions to install the app on your device.

3. **Production build and distribution:**
   - Run the following command:
     ```bash
     eas build --platform ios
     ```
   - Download the `.ipa` file.
   - Use the **Transporter** app (available on macOS) to upload the `.ipa` file to the App Store.

</details>

---

### Building for Android
<details>
<summary>Show instructions</summary>

1. **Update Metadata:**
   - Increment the `versionCode` in `app.json`.
   - Update the project ID in `app.json`. It must match the project ID of your Expo account. Check with:
     ```bash
     eas whoami
     ```
   - Example project ID: `3f9e7957-4b18-46e5-af0a-2222e0044fed`

2. **Production build and distribution:**
   - Run the following command:
     ```bash
     eas build --platform android
     ```
   - When prompted for Android Keystore, fill in the following information:
      - Keystore path: `@rwintgen__aispeak.jks`
      - Keystore Password: `bd3148f82ec8e9fbb7702f9163a3d13c`
      - Key alias: `51eafa836aca53967dc01ae2760fb4f9`
      - Key password: `84c343ff18e6fa772edaf5151e80381b`
   - Download the `.aab` or `.apk` file.
   - Go to the **Google Play Console** and upload the file via drag-and-drop.

</details>
