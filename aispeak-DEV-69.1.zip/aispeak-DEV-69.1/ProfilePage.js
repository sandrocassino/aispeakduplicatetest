// ProfilePage.js

import "react-native-url-polyfill/auto";
import { View, Image, Text, TouchableOpacity, TextInput } from "react-native";
import styles from "./Styles";
import "react-native-gesture-handler";
import { yellow, dark, black, lightGray } from "./constants";
import { useEffect } from "react";

const ProfilePage = ({
  setPage,
  pickImage,
  profilePicture,
  email,
  setEmail,
  isEmailEditable,
  setIsEmailEditable,
  name,
  setName,
  isNameEditable,
  setIsNameEditable,
  isLoggedIn,
}) => {


  return (
    <View style={{ ...styles.container, backgroundColor: yellow }}>
      <View style={{ alignItems: "center", marginTop: 70 }}>
        <TouchableOpacity onPress={pickImage}>
          {profilePicture ? (
            <Image
              source={{ uri: profilePicture }}
              style={{ width: 100, height: 100, borderRadius: 50 }}
            />
          ) : (
            <View
              style={{
                width: 100,
                height: 100,
                borderRadius: 50,
                backgroundColor: yellow,
                justifyContent: "center",
                alignItems: "center",
                borderWidth: 1, // Added border width
                borderColor: dark, // Added border color
              }}
            >
              <Text style={{ color: dark }}>Añadir{"\n"}imagen</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <Text style={{ fontSize: 24, fontWeight: "bold", marginTop: 100 }}>
        Configuraciones de la cuenta
      </Text>
      <Text style={{ fontSize: 18, marginTop: 20 }}>
        Correo electrónico: {isLoggedIn ? email : ''}
      </Text>
      <TextInput
        style={{
          height: 40,
          borderColor: "gray",
          borderWidth: 2,
          marginTop: 10,
          color: isEmailEditable ? black : lightGray,
        }}
        onChangeText={setEmail}
        value={isLoggedIn ? email : ''}
        editable={isEmailEditable}
      />
      <View style={{ flexDirection: "row", marginTop: 5 }}>
        <TouchableOpacity onPress={() => setIsEmailEditable(true)}>
          <Text style={{ color: dark }}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setIsEmailEditable(false)}
          style={{ marginLeft: 10 }}
        >
          <Text style={{ color: dark }}>Guardar</Text>
        </TouchableOpacity>
      </View>
      <Text style={{ fontSize: 18, marginTop: 20 }}>Mi nombre: {isLoggedIn ? name : ''}</Text>
      <TextInput
        style={{
          height: 40,
          borderColor: "gray",
          borderWidth: 2,
          marginTop: 10,
          color: isNameEditable ? black : lightGray,
        }}
        onChangeText={setName}
        value={isLoggedIn ? name : ''}
        editable={isNameEditable}
      />
      <View style={{ flexDirection: "row", marginTop: 5 }}>
        <TouchableOpacity onPress={() => setIsNameEditable(true)}>
          <Text style={{ color: dark }}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setIsNameEditable(false)}
          style={{ marginLeft: 10 }}
        >
          <Text style={{ color: dark }}>Guardar</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        onPress={() => setPage(9)}
        style={{
          borderColor: dark,
          borderWidth: 1.8,
          paddingVertical: 4,
          paddingHorizontal: 10,
          borderRadius: 5,
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          marginTop: 30,
          alignSelf: "center",
          zIndex: 3,
          height: 45,
          width: 90,
        }}
      >
        <Text
          style={{
            fontSize: 16,
            fontWeight: "bold",
            color: dark,
            marginBottom: -6,
            textAlign: "center",
          }}
        >
          Volver
        </Text>

        <Image
          source={require("./assets/icons/transparent-arrow-right-black-bg.png")}
          style={{
            width: 20,
            height: 21,
            transform: [{ scaleX: -1 }],
            marginTop: 2,
          }}
        />
      </TouchableOpacity>
    </View>
  );
};

export default ProfilePage;
