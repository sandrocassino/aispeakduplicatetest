import React from "react";
import { View, Text, Image, TouchableOpacity } from "react-native";
import styles from "../Styles";
import { light, dark } from "../constants";

const ProfilePromptScreen = ({ setPage }) => {
  return (
    <View style={styles.container}>
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        {/* Image stays in place */}
        <Image
          style={{
            width: 300,
            height: 300,
            marginBottom: 30, // Spacing between image and first text
          }}
          source={require("../assets/images/levels-menu.png")}
        />

        {/* Apply negative margin to move texts and buttons up */}
        <View style={{ marginTop: -80, alignItems: "center" }}>
          {/* First text under the image */}
          <Text
            style={{
              color: light,
              fontSize: 30,
              fontWeight: "bold",
              textAlign: "center",
              marginBottom: 15,
            }}
          >
            Creemos un perfil para mantener tu progreso!
          </Text>

          {/* Second text under the first text */}
          <Text
            style={{
              color: light,
              fontSize: 18,
              textAlign: "center",
              marginBottom: 40,
            }}
          >
            Tarda menos de 2 minutos.
          </Text>

          {/* First Touchable button */}
          <TouchableOpacity
            onPress={() => setPage(122)}
            style={{
              backgroundColor: light,
              borderRadius: 10,
              borderWidth: 1,
              borderColor: light,
              paddingVertical: 20,
              paddingHorizontal: 49,
              marginBottom: 0, // No space between buttons
              alignItems: "center",
            }}
          >
            <Text style={{ color: dark, fontSize: 22 }}>Crear un perfil</Text>
          </TouchableOpacity>

          {/* Second Touchable button */}
          <TouchableOpacity
            onPress={() => setPage(7)}
            style={{
              borderRadius: 10,
              borderWidth: 2,
              borderColor: light,
              paddingVertical: 10,
              paddingHorizontal: 20,
              marginTop: 10, // No space between buttons
              alignItems: "center",
              width: "60%", // Ensure same width as above button
            }}
          >
            <Text style={{ color: dark, fontSize: 18 }}>Más tarde</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default ProfilePromptScreen;
