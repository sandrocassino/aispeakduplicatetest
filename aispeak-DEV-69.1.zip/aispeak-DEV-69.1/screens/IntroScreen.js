import React from "react";
import { View, TouchableOpacity, Image, Text } from "react-native";
import Styles from "../Styles";
import { SourceSans } from "../constants.js";

export default function IntroScreen({
  showContent2,
  showImage,
  showText,
  showText2,
  showFinger,
  isContentReady,
  screenHeight,
  styles,
  setClickCount,
  setPage,
  setShowText,
  setShowImage,
  setShowText2,
  setIsContentReady,
  fontSizeMedium2,
}) {
  return (
    <View style={Styles.container}>
      {showContent2 && (
        <View
          style={{
            position: "absolute",
            bottom: screenHeight <= 667 ? 350 : 400,
            right: 225,
          }}
        >
          <TouchableOpacity
            onPress={() => {
              setClickCount((prevClickCount) => {
                if (prevClickCount > 0) {
                  setPage(5);
                } else {
                  setShowText(false);
                  setShowImage(false); // hide the coudwhite image
                  setTimeout(() => {
                    setShowText2(true); // show the second text after 1 second
                    setShowImage(true); // re-display the coudwhite image after 1 second
                    setIsContentReady(true); // set content ready to true
                  }, 500);
                }
                return prevClickCount + 1;
              });
            }}
            disabled={!isContentReady} // disable TouchableOpacity until content is ready
          >
            <View style={{ zIndex: 2 }}>
              <Image
                source={require("../assets/images/capy.png")}
                style={[
                  styles.image610,
                  {
                    position: "absolute",
                    top: screenHeight <= 667 ? -30 : -130,
                    left: 0,
                    resizeMode: "contain",
                  },
                ]}
              />
              {showFinger && (
                <Image
                  source={require("../assets/images/finger-tapping.gif")}
                  style={[
                    styles.image66,
                    {
                      position: "absolute",
                      top: screenHeight <= 667 ? 100 : 0,
                      left: 110,
                      resizeMode: "contain",
                      zIndex: 10,
                    },
                  ]}
                />
              )}
            </View>
          </TouchableOpacity>

          {showImage && (
            <Image
              source={require("../assets/icons/white-square-bubble-no-bg.png")}
              style={[
                styles.image4,
                {
                  position: "absolute",
                  top: screenHeight <= 667 ? -100 : -200,
                  left: -130,
                  resizeMode: "contain",
                },
              ]}
            />
          )}

          {showText && (
            <View
              style={{
                position: "absolute",
                top: screenHeight <= 667 ? -70 : -170,
                left: -103,
              }}
            >
              <Text
                style={{
                  fontFamily: SourceSans,
                  fontWeight: "bold",
                  alignSelf: "center",
                  marginBottom: 15,
                  fontSize: fontSizeMedium2,
                }}
              >
                Hola, soy {"\n"}Aispeak! Seré tu{"\n"}compañero {"\n"}de
                idiomas.
              </Text>
            </View>
          )}

          {showText2 && (
            <View
              style={{
                position: "absolute",
                top: screenHeight <= 667 ? -70 : -170,
                left: -103,
              }}
            >
              <Text
                style={{
                  fontFamily: SourceSans,
                  fontWeight: "bold",
                  alignSelf: "center",
                  marginBottom: 15,
                  fontSize: fontSizeMedium2,
                }}
              >
                Responda{"\n"}estas preguntas{"\n"}antes de{"\n"}comenzar.
              </Text>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
