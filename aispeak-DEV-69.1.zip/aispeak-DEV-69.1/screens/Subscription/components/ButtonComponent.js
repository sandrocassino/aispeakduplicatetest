import {
  View,
  StyleSheet,
  Text,
  useWindowDimensions,
  Alert,
} from "react-native";
import { Button } from "react-native-paper";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { blue, darkblue, sourceSans } from "../../../constants.js";

export default function ButtonComponent({
  selectedPlan,
  selectedBillingCycle,
  setIsSubscribing,
  inAppBuySubscription,
  setIsTimeoutActive,
  setChatCount,
  setTrialChatCount,
  setRemainingTime,
  saveToSupabase,
  setCurrentPlan,
  setCurrentBillingCycle,
  setPage,
  isTrialActive,
  alreadySelectedPlan,
  currentPlan,
  currentBillingCycle,
  isOnboarding = false,
  onNext = null,
}) {
  const { width } = useWindowDimensions();
  const borderRadiusFactor = 0.06;

  // Determine if the selection matches the current subscription
  const isSameSubscription =
    alreadySelectedPlan &&
    selectedPlan === currentPlan &&
    selectedBillingCycle === currentBillingCycle;

  // Button text logic
  let buttonText = "Suscríbete";
  if (alreadySelectedPlan) {
    buttonText = isSameSubscription
      ? "Conservar suscripción"
      : "Cambiar suscripción";
  } else if (isTrialActive) {
    buttonText = "Suscríbete: 7 días gratis >";
  }

  // Button press logic
  const handleSubscribe = async () => {
    if (!selectedBillingCycle) {
      Alert.alert("Por favor, selecciona un ciclo de facturación");
      return;
    }

    if (alreadySelectedPlan) {
      if (isSameSubscription) {
        // Just go home
        setPage(7);
        return;
      }
      // Else: proceed with subscription logic to change plan/billing
    }

    setIsSubscribing(true);
    const success = await inAppBuySubscription(selectedPlan);
    if (success) {
      setIsTimeoutActive(false);
      setChatCount(0);
      setTrialChatCount(0);
      await AsyncStorage.setItem("isTimeoutActive", JSON.stringify(false));
      await AsyncStorage.setItem("chatCount", JSON.stringify(0));
      await AsyncStorage.setItem("trialChatCount", JSON.stringify(0));
      saveToSupabase();
      setCurrentPlan(selectedPlan);
      setCurrentBillingCycle(selectedBillingCycle);

      if (isOnboarding && typeof onNext === "function") {
        onNext(); // Go to next onboarding page after purchase
      } else {
        setPage(7); // For plan switches, go to home
      }
    }
    setIsSubscribing(false);
  };

  return (
    <View style={styles.container}>
      <View
        style={[
          styles.buttonContainer,
          { borderRadius: width * borderRadiusFactor },
        ]}
      >
        <Button
          style={[
            styles.button,
            {
              borderRadius: width * borderRadiusFactor,
              elevation: 0,
              shadowColor: "transparent",
              shadowOffset: { width: 0, height: 0 },
              shadowOpacity: 0,
              shadowRadius: 0,
            },
          ]}
          mode="contained"
          onPress={handleSubscribe}
        >
          <Text style={[styles.buttonText, { fontSize: width * 0.04 }]}>
            {buttonText}
          </Text>
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    marginTop: 40,
    marginBottom: 30,
  },
  buttonContainer: {
    backgroundColor: darkblue,
    paddingBottom: 3,
    width: "95%",
  },
  button: {
    backgroundColor: blue,
    width: "100%",
    paddingVertical: 6,
  },
  buttonText: {
    textTransform: "capitalize",
    fontFamily: sourceSans,
  },
});
