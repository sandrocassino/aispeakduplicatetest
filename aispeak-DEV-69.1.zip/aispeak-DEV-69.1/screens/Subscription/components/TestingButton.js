import React from "react";
import { TouchableOpacity, Text, StyleSheet, View } from "react-native";
import { nunitoBold, red, light } from "../../../constants";

export default function TestingButton({
  testerUsed,
  setTesterUsed,
  setPage,
  handleTesterButtonPress,
  currentPlan,
}) {
  const handlePress = async () => {
    if (testerUsed) {
      setPage(7);
    } else {
      await handleTesterButtonPress();
      setTesterUsed(true);
      setPage(7);
    }
  };

  return (
    <View style={styles.testingButtonContainer}>
      <TouchableOpacity style={styles.testingButton} onPress={handlePress}>
        <Text style={styles.testingButtonText}>Testing</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  testingButtonContainer: {
    width: "100%",
    alignItems: "center",
    marginTop: 24,
    marginBottom: 16,
  },
  testingButton: {
    paddingVertical: 12,
    paddingHorizontal: 32,
    backgroundColor: red,
    borderRadius: 999,
  },
  testingButtonText: {
    fontFamily: nunitoBold,
    fontSize: 16,
    color: light,
  },
});