import { View, StyleSheet } from 'react-native';

import FeatureItem from './FeatureItem'

const doneIcon = require('../../../assets/icons/blue-checkmark-circle-no-bg.png')

export const featuresData = [
  { text: 'Chat sin límites', 
    icon: doneIcon 
  },
  {
    text: 'Temas de conversación infinitos',
    icon: doneIcon
  },
  {
    text: 'Mensajes de voz ilimitados',
    icon: doneIcon
  },
  {
    text: 'Correciones al instante',
    icon: doneIcon
  },
  {
    text: 'Práctica diaria desde nivel A1 hasta C2',
    icon: doneIcon
  },
];

export default function SubscriptionFeatures() {
  return (
    <View style={styles.container}>
      {featuresData.map((feature, index) => { // Map the featuresData array to get datas to render in FeatureItem
        return (
          <FeatureItem key={index} text={feature.text} icon={feature.icon} />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 24,
    paddingLeft: 8,
  }
});
