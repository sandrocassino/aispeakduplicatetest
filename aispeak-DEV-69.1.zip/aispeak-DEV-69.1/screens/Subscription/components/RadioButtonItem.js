import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  useWindowDimensions,
} from 'react-native';

import { blue, lightBlue, light, dark, nunitoBold, sourceSans } from '../../../constants';

//Reusable component for a single Radio Button
const RadioButtonItem = ({ isSelected, onPress, title, secondaryText }) => { // Props received from RadioButton
  
  const { width } = useWindowDimensions();
  const radioSize = width * 0.06; // Responsive Radio Circle button
  const borderWidth = width * 0.006;
  const borderRadiusFactor = 0.06


  return (
    <TouchableOpacity onPress={onPress}>
      <View style={[styles.container, {borderRadius: width * borderRadiusFactor}, isSelected && styles.selectedContainer]}>
        <View style={styles.wrapper}>
          {/* Outer circle of the radio button */}
          <View
            style={[
              {
                width: radioSize,
                height: radioSize,
                borderRadius: radioSize / 2,
                borderWidth: borderWidth,
              },
              isSelected && styles.selectedOuter,
              !isSelected && styles.unselectedOuter,
            ]}>
            {/* Inner filled circle when the radio button is selected */}
            {isSelected && (
              <View
                style={[
                  styles.selectedBg,
                  {
                    width: radioSize * 0.6,
                    height: radioSize * 0.6,
                    borderRadius: (radioSize * 0.6) / 2,
                    margin: radioSize * 0.1,
                  },
                ]}
              />
            )}
          </View>
          {/* Container for the title and secondary text */}
          <View style={styles.textContainer}>
            <Text style={[styles.radioText, { fontSize: width * 0.045 }]}>
              {title}
            </Text>
            {secondaryText && (
              <Text style={[styles.secondaryText, { fontSize: width * 0.038 }]}>
                {secondaryText}
              </Text>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 3,
    borderColor: light,
    backgroundColor: light,
    padding: 8,
    marginVertical: 5,
    width: '100%',
  },
  selectedContainer: {
    backgroundColor: lightBlue,
    borderColor: blue,
  },
  wrapper: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 8,
    marginVertical: 6,
    flex: 1,
  },
  selectedOuter: {
    borderColor: blue,
  },
  unselectedOuter: {
    borderColor: dark,
  },
  selectedBg: {
    backgroundColor: blue,
  },
  textContainer: {
    alignItems: 'start',
    marginLeft: 15,
    flex: 1,
  },
  radioText: {
    marginBottom: 10,
    fontFamily: nunitoBold,
  },
  secondaryText: {
    flexDirection: 'row',
    fontFamily: sourceSans,
  },
});

export default RadioButtonItem;
