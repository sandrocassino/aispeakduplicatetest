import React, { Component } from "react";
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Platform,
  Animated,
  KeyboardAvoidingView,
} from "react-native";
import {
  light,
  dark,
  darkGray,
  gray,
  lightGray,
  lightBlue,
  blue,
  red,
} from "../../../constants";

class DiscountCodePopup extends Component {
  animatedOpacity = new Animated.Value(0);

  state = {
    promoCode: "",
    error: "",
    inputFocused: false,
  };

  componentDidUpdate(prevProps) {
    if (this.props.visible !== prevProps.visible) {
      Animated.timing(this.animatedOpacity, {
        toValue: this.props.visible ? 1 : 0,
        duration: 100,
        useNativeDriver: true,
      }).start();
    }
  }

  handleApply = async () => {
    this.setState({ error: "" });

    if (!this.state.promoCode.trim()) {
      this.setState({ error: "Por favor, ingrese un código." });
      return;
    }

    try {
      const response = await fetch(
        "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/HandleDiscountCodes",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: this.state.promoCode.trim() }),
        }
      );

      const result = await response.json();

      if (result.valid) {
        alert("Código aplicado correctamente.");

        try {
          if (!this.props.testerUsed) {
            await this.props.handleTesterButtonPress();
            this.props.setTesterUsed(true);
          }
        } catch (testerError) {
          console.error("Error in handleTesterButtonPress:", testerError);
          this.setState({ error: "Hubo un problema al aplicar el código." });
          return;
        }

        if (
          this.props.isOnboarding &&
          typeof this.props.onNext === "function"
        ) {
          this.props.onNext();
        } else {
          this.props.setPage(7);
        }

        this.setState({ promoCode: "", error: "" });
      } else {
        this.setState({ error: result.message || "Código no válido." });
      }
    } catch (e) {
      console.error("Fetch error in handleApply:", e);
      this.setState({ error: "Error de red. Inténtalo de nuevo." });
    }
  };

  handleClose = () => {
    this.setState({ promoCode: "", error: "" });
    this.props.onClose();
  };

  render() {
    const { visible } = this.props;
    const { promoCode, error, inputFocused } = this.state;

    return (
      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={this.handleClose}
      >
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <Animated.View
            style={{
              flex: 1,
              opacity: this.animatedOpacity,
              backgroundColor: "rgba(0, 0, 0, 0.5)",
              justifyContent: "center",
              alignItems: "center",
              pointerEvents: visible ? "auto" : "none",
            }}
          >
            <View
              style={{
                overflow: "visible",
                backgroundColor: light,
                paddingVertical: 57,
                paddingHorizontal: 27,
                justifyContent: "center",
                alignItems: "center",
                borderRadius: 24,
                marginHorizontal: 16,
                width: "90%",
                maxWidth: 400,
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
              }}
            >
              <Text
                style={{
                  color: darkGray,
                  textAlign: "center",
                  fontSize: 16,
                  fontWeight: "700",
                  lineHeight: 24,
                  marginBottom: 12,
                }}
              >
                Ingrese su código promocional
              </Text>
              <TextInput
                value={promoCode}
                onChangeText={(text) => this.setState({ promoCode: text })}
                placeholder="Código promocional"
                style={{
                  flex: 1,
                  fontSize: 16,
                  fontWeight: "400",
                  fontStyle: "normal",
                  textAlignVertical: "center",
                  paddingVertical: 12,
                  paddingLeft: 16,
                  paddingRight: 8,
                  lineHeight: 20,
                  minHeight: 40,
                  borderWidth: 1,
                  borderColor: inputFocused ? blue : gray,
                  borderRadius: 50,
                  backgroundColor: inputFocused ? lightBlue : lightGray,
                  marginBottom: 8,
                  textAlign: "center",
                  width: 220,
                  transition: "background-color 0.2s, border-color 0.2s",
                }}
                autoCapitalize="characters"
                autoFocus
                placeholderTextColor={darkGray}
                onFocus={() => this.setState({ inputFocused: true })}
                onBlur={() => this.setState({ inputFocused: false })}
              />
              {error ? (
                <Text
                  style={{
                    color: "red",
                    marginBottom: 8,
                    fontSize: 14,
                    textAlign: "center",
                  }}
                >
                  {error}
                </Text>
              ) : null}
              <View
                style={{
                  flexDirection: "row",
                  marginTop: 8,
                  width: "100%",
                  justifyContent: "space-between",
                }}
              >
                <TouchableOpacity
                  onPress={this.handleApply}
                  style={{
                    backgroundColor: blue,
                    paddingVertical: 12,
                    paddingHorizontal: 24,
                    borderRadius: 24,
                    flex: 1,
                    marginRight: 4,
                    alignItems: "center",
                    ...Platform.select({
                      ios: {
                        shadowColor: dark,
                        shadowOffset: { width: 0, height: 3 },
                        shadowOpacity: 0.25,
                        shadowRadius: 10,
                      },
                      android: {
                        elevation: 5,
                      },
                    }),
                  }}
                >
                  <Text
                    style={{
                      color: light,
                      fontSize: 16,
                      textAlign: "center",
                      fontWeight: "700",
                      lineHeight: 20,
                    }}
                  >
                    Aplicar
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={this.handleClose}
                  style={{
                    backgroundColor: red,
                    paddingVertical: 12,
                    paddingHorizontal: 24,
                    borderRadius: 24,
                    flex: 1,
                    marginLeft: 4,
                    alignItems: "center",
                    ...Platform.select({
                      ios: {
                        shadowColor: dark,
                        shadowOffset: { width: 0, height: 3 },
                        shadowOpacity: 0.25,
                        shadowRadius: 10,
                      },
                      android: {
                        elevation: 5,
                      },
                    }),
                  }}
                >
                  <Text
                    style={{
                      color: light,
                      fontSize: 16,
                      textAlign: "center",
                      fontWeight: "700",
                      lineHeight: 20,
                    }}
                  >
                    Cancelar
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </Animated.View>
        </KeyboardAvoidingView>
      </Modal>
    );
  }
}

export default DiscountCodePopup;
