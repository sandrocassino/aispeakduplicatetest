import {
  Text,
  View,
  StyleSheet,
  Image,
  useWindowDimensions,
  TouchableOpacity,
} from "react-native";
import { blue, sourceSansBold } from "../../../constants.js";

const circleIcon = require("../../../assets/icons/blue-circle-no-bg.png");

export default function TermsAndPrivacyTexts({ setPage, originPageCode }) {
  const { width } = useWindowDimensions();
  const circleSize = width * 0.01;

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => setPage(4212, originPageCode)}>
        <Text style={[styles.text, { fontSize: width * 0.041 }]}>
          Términos y Condiciones
        </Text>
      </TouchableOpacity>
      <Image
        style={{ width: circleSize, height: circleSize }}
        source={circleIcon}
      />
      <TouchableOpacity onPress={() => setPage(4211, originPageCode)}>
        <Text style={[styles.text, { fontSize: width * 0.041 }]}>
          Política de Privacidad
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    gap: 15,
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    color: blue,
    fontFamily: sourceSansBold,
    textAlign: "center",
    textDecorationLine: "underline",
  },
});
