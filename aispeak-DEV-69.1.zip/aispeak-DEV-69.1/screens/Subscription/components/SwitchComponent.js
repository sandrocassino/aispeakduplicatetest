import { View, Text, StyleSheet, useWindowDimensions } from "react-native";
import { Switch } from "react-native-paper";
import {
  blue,
  light,
  darkGray,
  sourceSansBold,
  sourceSans,
} from "../../../constants.js";

export default function SwitchComponent({ isDisabled, isTrialActive, onToggleTrial }) {
  const { width } = useWindowDimensions();

  // Customize Switch dimensions and determine the scaling based on screenWidth
  const switchButton = {
    marginLeft: 8,
  };

  const getSwitchScale = (screenWidth) => {
    if (screenWidth < 600) {
      return { transform: [{ scaleX: 1 }, { scaleY: 1.2 }] };
    }
    return { transform: [{ scaleX: 1.4 }, { scaleY: 1.5 }] };
  };

  return (
    <View style={styles.container}>
      <Text
        style={[
          styles.switchText,
          { fontSize: width * 0.035, marginRight: width * 0.03 },
          isDisabled && styles.disabledSwitch,
        ]}
      >
        Activar{" "}
        <Text style={{ fontFamily: sourceSansBold }}>prueba gratuita</Text> por{" "}
        <Text style={{ fontFamily: sourceSansBold }}>7 días</Text>, luego
        €69,99/ año.
      </Text>
      <Switch
        disabled={isDisabled}
        trackColor={{ false: darkGray, true: blue }}
        thumbColor={light}
        activeThumbColor={light}
        ios_backgroundColor={darkGray}
        onValueChange={onToggleTrial}
        value={isTrialActive}
        style={[
          switchButton,
          getSwitchScale(width),
          isDisabled && styles.disabledSwitch,
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    paddingHorizontal: 15,
    paddingVertical: 2,
    alignItems: "center",
  },
  switchText: {
    flex: 1,
    fontFamily: sourceSans,
  },
  disabledSwitch: {
    opacity: 0.5,
  },
});