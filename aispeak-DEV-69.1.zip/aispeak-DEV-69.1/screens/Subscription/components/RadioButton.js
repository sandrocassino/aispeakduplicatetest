import { Text, View, StyleSheet, useWindowDimensions } from 'react-native';
import { light, blue, sourceSans, sourceSansBold, darkGray } from '../../../constants.js';
import RadioButtonItem from './RadioButtonItem';

export default function RadioButtonComponent({ selectedBillingCycle, setSelectedBillingCycle }) {
  const { width } = useWindowDimensions();

  return (
    <View style={styles.container}>
      {/* Radio button for the annual subscription option. */}
      <RadioButtonItem
        isSelected={selectedBillingCycle === "Anual"}
        onPress={() => setSelectedBillingCycle("Anual")}
        title="ANUAL"
        secondaryText={
          <>
            <Text style={styles.price}>€94,99/año</Text>
            <Text style={styles.pricePerMonth}> (€5,83/mes)</Text>
            <Text style={styles.sales}> ¡Ahorra €25!</Text>
          </>
        }
      />
      <View style={styles.betterOptContainer}>
        <Text style={[styles.betterOptText, { fontSize: width * 0.03 }]}>
          Mejor opción
        </Text>
      </View>
      {/* Radio button for the mensual subscription option. */}
      <RadioButtonItem
        isSelected={selectedBillingCycle === "Mensual"}
        onPress={() => setSelectedBillingCycle("Mensual")}
        title="MENSUAL"
        secondaryText={<Text style={styles.price}>€11,99/mes</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    position: 'relative',
  },
  betterOptContainer: {
    backgroundColor: blue,
    width: '25%',
    paddingVertical: 10,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    top: 4,
    right: 40,
    zIndex: 1,
  },
  betterOptText: {
    color: light,
    fontFamily: sourceSans,
    textAlign: 'center',
  },
  price: {
    fontFamily: sourceSansBold,
  },
  pricePerMonth: {
    color: darkGray,
  },
  sales: {
    color: blue,
    fontFamily: sourceSansBold,
  },
});