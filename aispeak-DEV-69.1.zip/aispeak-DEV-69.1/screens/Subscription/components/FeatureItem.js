import { View, Text, StyleSheet, Image, useWindowDimensions } from 'react-native';

import { sourceSans } from '../../../constants.js'

export default function FeatureItem({ text, icon }){ // Props from SubscriptionFeatures map of featuresData array

  const { width } = useWindowDimensions();
  const iconSize = width * 0.045 // Determine responsive Icon Size to add inline style

  return (
    <View style={styles.container}>
      <Image style={{width: iconSize, height: iconSize}} source={icon}></Image>
      <Text style={[styles.paragraph, {fontSize: width * 0.04}]}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'start',
    marginLeft: 10,
    flexDirection: 'row',
    marginBottom: 15
  },
  paragraph: {
    marginLeft: 10,
    fontFamily: sourceSans,
  },
});