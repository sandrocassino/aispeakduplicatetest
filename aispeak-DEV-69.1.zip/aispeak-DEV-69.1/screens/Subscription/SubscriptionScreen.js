import React, { useState } from "react";
import {
  Text,
  SafeAreaView,
  StyleSheet,
  Platform,
  ScrollView,
  useWindowDimensions,
  TouchableOpacity,
} from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { yellow, blue, nunitoBold } from "../../constants";
import SubscriptionFeatures from "./components/SubscriptionFeatures";
import RadioButton from "./components/RadioButton";
import SwitchComponent from "./components/SwitchComponent";
import ButtonComponent from "./components/ButtonComponent";
import TermsAndPrivacyTexts from "./components/TermsAndPrivacyTexts";
import TestingButton from "./components/TestingButton";
import DiscountCodePopup from "./components/DiscountCodePopup";

export default function SubscriptionScreen({
  planDetails,
  selectedPlan,
  setSelectedPlan1,
  selectedBillingCycle,
  setSelectedBillingCycle,
  currentPlan,
  currentBillingCycle,
  isSubscribing,
  alreadySelectedPlan,
  setAlreadySelectedPlan,
  setPage,
  textColor,
  fontSizeLarge,
  fontSizeSmall,
  fontSizeHuge,
  makeUserWant,
  popAnim,
  handleTesterButtonPress,
  testerUsed,
  setTesterUsed,
  isTrialActive,
  setIsTrialActive,
  setCurrentPlan,
  setCurrentBillingCycle,
  setIsTimeoutActive,
  setChatCount,
  setTrialChatCount,
  setRemainingTime,
  saveToSupabase,
  inAppBuySubscription,
  setIsSubscribing,
  originPage,
}) {
  const { width } = useWindowDimensions();

  // Discount code popup state
  const [promoModalVisible, setPromoModalVisible] = useState(false);
  const [promoSuccess, setPromoSuccess] = useState("");

  // Handler for when a promo code is successfully applied
  const handlePromoApplied = (message) => {
    setPromoSuccess(message);
    setPromoModalVisible(false);
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.contentContainer}
        >
          <Text style={[styles.h1, { fontSize: width * 0.055 }]}>
            No esperes más y llevemos tu nivel de Inglés al más allá!
          </Text>
          <SubscriptionFeatures />
          <Text style={[styles.paragraph, { fontSize: width * 0.05 }]}>
            Elige un plan
          </Text>
          <RadioButton
            selectedBillingCycle={selectedBillingCycle}
            setSelectedBillingCycle={setSelectedBillingCycle}
          />
          <SwitchComponent
            isDisabled={alreadySelectedPlan}
            isTrialActive={isTrialActive}
            onToggleTrial={(value) => {
              setIsTrialActive(value);
              if (value) {
                alert(
                  "Activa prueba gratis\n\nPuedes cancelar la prueba gratuita antes de que terminen los 7 días. Si no la cancelas, tu suscripción se renovará automáticamente por €69,99/ año."
                );
              }
            }}
          />
          <TouchableOpacity onPress={() => setPromoModalVisible(true)}>
            <Text style={styles.promoText}>¿Tiene un código promocional?</Text>
          </TouchableOpacity>
          {promoSuccess ? (
            <Text style={styles.promoSuccess}>{promoSuccess}</Text>
          ) : null}
          <ButtonComponent
            selectedPlan={selectedPlan}
            selectedBillingCycle={selectedBillingCycle}
            setIsSubscribing={setIsSubscribing}
            inAppBuySubscription={inAppBuySubscription}
            setIsTimeoutActive={setIsTimeoutActive}
            setChatCount={setChatCount}
            setTrialChatCount={setTrialChatCount}
            setRemainingTime={setRemainingTime}
            saveToSupabase={saveToSupabase}
            setCurrentPlan={setCurrentPlan}
            setCurrentBillingCycle={setCurrentBillingCycle}
            setPage={setPage}
            isTrialActive={isTrialActive}
            alreadySelectedPlan={alreadySelectedPlan}
            currentPlan={currentPlan}
            currentBillingCycle={currentBillingCycle}
          />
          <TermsAndPrivacyTexts setPage={setPage} originPageCode={4000} />
          {/* <TestingButton
            testerUsed={testerUsed}
            setTesterUsed={setTesterUsed}
            setPage={setPage}
            handleTesterButtonPress={handleTesterButtonPress}
            currentPlan={currentPlan}
          /> */}
        </ScrollView>
        <DiscountCodePopup
          visible={promoModalVisible}
          onClose={() => setPromoModalVisible(false)}
          onPromoApplied={handlePromoApplied}
          handleTesterButtonPress={handleTesterButtonPress}
          setTesterUsed={setTesterUsed}
          setPage={setPage}
          testerUsed={testerUsed}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: yellow,
    paddingVertical: Platform.OS === "android" ? 25 : 0,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    flexGrow: 1,
    justifyContent: "flex-start",
    padding: 4,
  },
  h1: {
    margin: 15,
    fontSize: 22,
    textAlign: "flexStart",
    fontFamily: nunitoBold,
  },
  paragraph: {
    marginTop: 24,
    marginLeft: 15,
    fontSize: 20,
    fontFamily: nunitoBold,
  },
  promoText: {
    color: blue,
    margin: 16,
    fontSize: 16,
    textAlign: "left",
    fontFamily: nunitoBold,
  },
  promoSuccess: {
    color: "green",
    marginLeft: 16,
    marginBottom: 8,
    fontSize: 15,
    fontFamily: nunitoBold,
  },
});
