import "react-native-url-polyfill/auto";
import { View, Image, Text, TouchableOpacity } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Switch } from "react-native";
import { Alert, Animated, Dimensions } from "react-native";
import { ActivityIndicator } from "react-native";
import "react-native-gesture-handler";
import { useState } from "react";
import { blue, dark, light, yellow, darkGray } from "../../constants";

function getRenewalPrice(plan, billingCycle) {
  if (plan === "Básico" && billingCycle === "Mensual") {
    return "€7,99 al mes";
  } else if (plan === "Básico" && billingCycle === "Anual") {
    return "€69,99 al año";
  } else if (plan === "Pro" && billingCycle === "Mensual") {
    return "€11,99 al mes";
  } else if (plan === "Pro" && billingCycle === "Anual") {
    return "€94,99 al año";
  }
  return "tu plan elegido";
}

export default function SubscriptionScreen({
  // Pass in all the props you need from App.js:
  planDetails,
  selectedPlan,
  setSelectedPlan1,
  selectedBillingCycle,
  setSelectedBillingCycle,
  currentPlan,
  currentBillingCycle,
  isSubscribing,
  alreadySelectedPlan,
  setAlreadySelectedPlan,
  setPage,
  textColor,
  fontSizeLarge,
  fontSizeSmall,
  fontSizeHuge,
  makeUserWant,
  popAnim,
  handleTesterButtonPress,
  testerUsed,
  isTrialActive,
  setIsTrialActive,
  setCurrentPlan,
  setCurrentBillingCycle,
  setIsTimeoutActive,
  setChatCount,
  setTrialChatCount,
  setRemainingTime,
  saveToSupabase,
  inAppBuySubscription,
  setIsSubscribing,
  originPage,
}) {
  const { width: screenWidth, height: screenHeight } = Dimensions.get("window");
  const ratio = screenHeight / screenWidth;
  const scaleFactor = ratio < 1.9 ? 0.9 : 1.0;

  const selectedPlanDetails = planDetails[selectedPlan];

  const smallBoxTexts = {
    Básico: {
      Mensual: "Solo 3 cafés",
      Anual: "Ahorra €26",
    },
    Pro: {
      Mensual: "Solo 5 cafés",
      Anual: "Ahorra €49",
    },
  };

  const isPlanChanged =
    selectedPlan !== currentPlan ||
    selectedBillingCycle !== currentBillingCycle;
  const buttonText = isPlanChanged
    ? "Cambiar mi plan actual  >"
    : "Conservar mi plan actual  >";

  const [isCancelling, setIsCancelling] = useState(false);

  // const handleGoBack = () => {
  //   // Default go back to HomeScreen
  //   if (!originPage) {
  //     setPage(7);

  //     return;
  //   }
  //   setPage(originPage); // Function to handle go back action to the previous page from where action started
  // };

  // const handleCancelSubscription = () => {
  //   setIsCancelling(true);
  //   Alert.alert(
  //     "Subscripción cancelada con éxito",
  //     "Tu subscripción ha sido cancelada"
  //   );
  //   setAlreadySelectedPlan(false); // Change to alreadySelectedPlan(false) to return to subscription page
  //   // setPage(7);
  // };

  if (!alreadySelectedPlan) {
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flex: 1.25 }}>
          {/* Activity Indicator Overlay */}
          {isSubscribing && (
            <View
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                zIndex: 1000,
              }}
            >
              <ActivityIndicator size="large" color={light} />
              <Text
                style={{
                  color: light,
                  marginTop: 10 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                Procesando tu suscripción...
              </Text>
            </View>
          )}

          {/* Top Section */}
          <View
            style={{
              flex: 1,
              backgroundColor: yellow,
              paddingTop: 55 * scaleFactor,
            }}
          >
            {/* Container for Logo and Basic Layout */}
            <View
              style={{
                position: "relative",
                alignItems: "center",
                transform: [{ scale: scaleFactor }],
              }}
            >
              {/* Logo */}
              <Image
                source={require("../../assets/images/old-logo-and-brand.png")}
                style={{
                  width: 200,
                  height: 56,
                  resizeMode: "contain",
                  transform: [{ scale: scaleFactor }],
                }}
              />
            </View>

            <View
              style={{
                flex: 1,
                alignItems: "center",
                paddingTop: 45 * scaleFactor,
                transform: [{ scale: scaleFactor }],
              }}
            >
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: "bold",
                  color: textColor,
                  marginTop: 20 * scaleFactor,
                  textAlign: "center",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                ¿Cuál prefieres?
              </Text>
            </View>

            {/* Optional animated image FIRST */}
            {makeUserWant && (
              <Animated.View
                style={{
                  opacity: popAnim,
                  transform: [{ scale: popAnim }],
                  position: "absolute",
                  marginTop: 20 * scaleFactor,
                  right: 0,
                }}
              >
                <Image
                  source={require("../../assets/images/old-capiandchat.png")}
                  style={{
                    width: 350 * scaleFactor,
                    height: 350 * scaleFactor,
                    transform: [{ scale: scaleFactor }],
                  }}
                />
              </Animated.View>
            )}

            {/* Cancel Button AFTER the image */}
            {/*Closing SubscriptionScreen after clicking 'Cancelar' button*/}
            <TouchableOpacity
              onPress={() => {
                Alert.alert(
                  "Cancelar tu plan de suscripción",
                  "Puedes cancelar la prueba gratuita antes de que terminen los 7 días.",
                  [{ text: "OK", onPress: () => console.log("OK Pressed") }]
                );
              }}
              // onPress={handleGoBack}
              style={{
                position: "absolute",
                right: 20 * scaleFactor,
                top: 75 * scaleFactor,
                flexDirection: "row",
                alignItems: "center",
                transform: [{ scale: scaleFactor }],
              }}
            >
              <Image
                source={require("../../assets/images/lightex.png")}
                style={{
                  width: 15,
                  height: 15,
                  resizeMode: "contain",
                  marginRight: 5 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              />
              <Text
                style={{
                  color: light,
                  fontSize: 16,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                Cancelar
              </Text>
            </TouchableOpacity>
            {!testerUsed && (
              <TouchableOpacity
                onPress={handleTesterButtonPress}
                style={{
                  position: "absolute",
                  left: 20 * scaleFactor,
                  top: 75 * scaleFactor,
                  flexDirection: "row",
                  alignItems: "center",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Text
                  style={{
                    color: light,
                    fontSize: 16,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Testing
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Bottom Section */}
          <View
            style={{
              flex: 1.75,
              backgroundColor: blue,
              padding: 20 * scaleFactor,
              justifyContent: "center",
              position: "relative",
            }}
          >
            {/* Plan Toggle */}
            <View
              style={{
                position: "absolute",
                top: -30 * scaleFactor,
                alignSelf: "center",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: light,
                borderRadius: 25 * scaleFactor,
                paddingVertical: 10 * scaleFactor,
                paddingHorizontal: 10 * scaleFactor,
                zIndex: 1,
                transform: [{ scale: scaleFactor }],
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setSelectedPlan1("Básico");
                  // **RESET free trial toggle**
                  setIsTrialActive(false);
                }}
                style={{
                  paddingVertical: 10 * scaleFactor,
                  paddingHorizontal: 25 * scaleFactor,
                  backgroundColor:
                    selectedPlan === "Básico" ? blue : light,
                  borderRadius: 20 * scaleFactor,
                  marginHorizontal: 5 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Text
                  style={{
                    color: selectedPlan === "Básico" ? light : dark,
                    fontWeight: "bold",
                    fontSize: fontSizeLarge,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Básico
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setSelectedPlan1("Pro");
                  // **RESET free trial toggle**
                  setIsTrialActive(false);
                }}
                style={{
                  paddingVertical: 10 * scaleFactor,
                  paddingHorizontal: 25 * scaleFactor,
                  backgroundColor: selectedPlan === "Pro" ? blue : light,
                  borderRadius: 20 * scaleFactor,
                  marginHorizontal: 5 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Text
                  style={{
                    color: selectedPlan === "Pro" ? light : dark,
                    fontWeight: "bold",
                    fontSize: fontSizeLarge,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Pro
                </Text>
              </TouchableOpacity>
            </View>

            {/* Features Section */}
            <View
              style={{
                marginBottom: 20 * scaleFactor,
                marginTop: 50 * scaleFactor,
                transform: [{ scale: scaleFactor }],
              }}
            >
              {selectedPlanDetails.features.map((feature, index) => (
                <Text
                  key={index}
                  style={{
                    fontSize: fontSizeLarge,
                    color: light,
                    marginBottom: 12 * scaleFactor,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  <Text
                    style={{
                      fontSize: fontSizeLarge,
                      color: yellow,
                      fontWeight: "bold",
                      transform: [{ scale: scaleFactor }],
                    }}
                  >
                    ✓
                  </Text>{" "}
                  {feature}
                </Text>
              ))}
            </View>

            {/* Billing Cycle Toggle */}
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                transform: [{ scale: scaleFactor }],
              }}
            >
              {/* Mensual and Anual Options */}
              {["Mensual", "Anual"].map((billingCycle) => {
                const isSelected = selectedBillingCycle === billingCycle;
                return (
                  <TouchableOpacity
                    key={billingCycle}
                    onPress={() => {
                      setSelectedBillingCycle(billingCycle);
                      // **RESET free trial toggle**
                      setIsTrialActive(false);
                    }}
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: light,
                      padding: 1 * scaleFactor,
                      borderRadius: 20 * scaleFactor,
                      marginHorizontal: 5 * scaleFactor,
                      alignItems: "center",
                      backgroundColor: isSelected ? light : "transparent",
                      height: 110 * scaleFactor,
                      marginTop: 5 * scaleFactor,
                    }}
                  >
                    {/* Small Box */}
                    <View
                      style={{
                        backgroundColor: isSelected ? yellow : light,
                        paddingVertical: 5 * scaleFactor,
                        paddingHorizontal: 8 * scaleFactor,
                        borderRadius: 5 * scaleFactor,
                        position: "absolute",
                        top: -10 * scaleFactor,
                        alignSelf: "center",
                        transform: [{ scale: scaleFactor }],
                      }}
                    >
                      <Text
                        style={{
                          color: dark,
                          fontSize: fontSizeSmall,
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        {smallBoxTexts[selectedPlan][billingCycle]}
                      </Text>
                    </View>

                    {/* Price */}
                    <Text
                      style={{
                        fontSize: fontSizeHuge,
                        fontWeight: "bold",
                        color: isSelected ? dark : light,
                        marginTop: 20 * scaleFactor,
                        padding: 5 * scaleFactor,
                        transform: [{ scale: scaleFactor }],
                      }}
                    >
                      {selectedPlanDetails[billingCycle].price}
                    </Text>
                    <Text
                      style={{
                        fontSize: fontSizeLarge,
                        color: isSelected ? dark : light,
                        padding: 5 * scaleFactor,
                        transform: [{ scale: scaleFactor }],
                      }}
                    >
                      {selectedPlanDetails[billingCycle].cycle}
                    </Text>
                    {/* Checkmark Icon */}
                    {isSelected && (
                      <View
                        style={{
                          position: "absolute",
                          top: -10 * scaleFactor,
                          right: -5 * scaleFactor,
                          backgroundColor: yellow,
                          width: 20 * scaleFactor,
                          height: 20 * scaleFactor,
                          borderRadius: 10 * scaleFactor,
                          padding: 5 * scaleFactor,
                          justifyContent: "center",
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        <Text
                          style={{
                            color: dark,
                            fontSize: 12,
                            fontWeight: "bold",
                            textAlign: "center",
                            transform: [{ scale: scaleFactor }],
                          }}
                        >
                          ✓
                        </Text>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Seleccionar Button */}
            <TouchableOpacity
              style={{
                backgroundColor:yellow,
                paddingVertical: 15 * scaleFactor,
                borderRadius: 40 * scaleFactor,
                marginTop: 20 * scaleFactor,
                alignItems: "center",
                alignSelf: "center",
                width: "100%",
                transform: [{ scale: scaleFactor }],
              }}
              onPress={async () => {
                if (selectedBillingCycle) {
                  setIsSubscribing(true);
                  const success = await inAppBuySubscription(selectedPlan);
                  // Only update state if purchase was successful
                  if (success) {
                    if (selectedPlan === "Pro") {
                      setIsTimeoutActive(false);
                      setChatCount(0);
                      setTrialChatCount(0);
                      AsyncStorage.setItem(
                        "isTimeoutActive",
                        JSON.stringify(false)
                      );
                      AsyncStorage.setItem("chatCount", JSON.stringify(0));
                      AsyncStorage.setItem("trialChatCount", JSON.stringify(0));
                    }
                  }
                  // If not successful, do nothing (alerts are handled in inAppBuySubscription)
                } else {
                  Alert.alert("Por favor, selecciona un ciclo de facturación");
                }
              }}
            >
              <Text
                style={{
                  color: dark,
                  fontSize: fontSizeLarge,
                  fontWeight: "bold",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                {isTrialActive ? "Suscríbete: 7 días gratis >" : "Suscríbete >"}
              </Text>
            </TouchableOpacity>

            {/* Free Trial Section */}
            <View
              style={{
                backgroundColor: light,
                paddingVertical: 10 * scaleFactor,
                borderRadius: 40 * scaleFactor,
                marginTop: 15 * scaleFactor,
                alignItems: "center",
                alignSelf: "center",
                width: "100%",
                flexDirection: "row",
                justifyContent: "space-between",
                paddingHorizontal: 10 * scaleFactor,
                transform: [{ scale: scaleFactor }],
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  color: dark,
                  fontWeight: "bold",
                  textAlign: "center",
                  marginLeft: 25 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                ¿No sabes? Activa prueba gratis
              </Text>
              <Switch
                value={isTrialActive}
                onValueChange={(value) => {
                  setIsTrialActive(value);
                  if (value) {
                    // Figure out the renewal price for the user’s current selection
                    const renewalPrice = getRenewalPrice(
                      selectedPlan,
                      selectedBillingCycle
                    );
                    Alert.alert(
                      "Activa prueba gratis",
                      `Puedes cancelar la prueba gratuita antes de que terminen los 7 días. 
                      Si no la cancelas, tu suscripción se renovará automáticamente por ${renewalPrice}.`,
                      [
                        {
                          text: "OK",
                          onPress: () => console.log("OK Pressed"),
                        },
                      ]
                    );
                  }
                }}
                thumbColor={isTrialActive ? light : light}
                trackColor={{ false: darkGray, true: blue }}
              />
            </View>
          </View>
        </View>
      </View>
    );
  } else {
    // PAGE 4000 LAYOUT (CHANGE SUBSCRIPTION)

    return (
      <View style={{ flex: 1 }}>
        <View style={{ flex: 1.25 }}>
          {/* Activity Indicator Overlay */}
          {isSubscribing && (
            <View
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                zIndex: 1000,
              }}
            >
              <ActivityIndicator size="large" color=light />
              <Text
                style={{
                  color: light,
                  marginTop: 10 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                Procesando tu suscripción...
              </Text>
            </View>
          )}

          {/* Top Section */}
          <View
            style={{
              flex: 1,
              backgroundColor: yellow,
              paddingTop: 55 * scaleFactor,
            }}
          >
            {/* Container for Logo and Cancel Button */}
            <View
              style={{
                position: "relative",
                alignItems: "center",
                transform: [{ scale: scaleFactor }],
              }}
            >
              {/* Logo */}
              <Image
                source={require("../../assets/images/old-logo-and-brand.png")}
                style={{
                  width: 200,
                  height: 56,
                  resizeMode: "contain",
                  transform: [{ scale: scaleFactor }],
                }}
              />

              {/* Cancel Button */}
              <TouchableOpacity
                onPress={() => {
                  Alert.alert(
                    "Cancelar tu plan de suscripción",
                    "Ve a la configuración de suscripciones de tu dispositivo para cancelar el plan de suscripción!",
                    [{ text: "OK", onPress: () => console.log("OK Pressed") }]
                  );
                }}
                style={{
                  position: "absolute",
                  right: 20 * scaleFactor,
                  top: 20 * scaleFactor,
                  flexDirection: "row",
                  alignItems: "center",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Image
                  source={require("../../assets/images/lightex.png")}
                  style={{
                    width: 15,
                    height: 15,
                    resizeMode: "contain",
                    marginRight: 5 * scaleFactor,
                    transform: [{ scale: scaleFactor }],
                  }}
                />
                <Text
                  style={{
                    color: light,
                    fontSize: 16,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Cancelar
                </Text>
              </TouchableOpacity>
            </View>

            <View
              style={{
                alignItems: "center",
                paddingTop: 45 * scaleFactor,
                transform: [{ scale: scaleFactor }],
              }}
            >
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: "bold",
                  color: dark,
                  marginTop: 10 * scaleFactor,
                  textAlign: "center",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                ¿Cambia tu {"\n"} plan actual?
              </Text>
            </View>
          </View>

          {/* Bottom Section */}
          <View
            style={{
              flex: 1.75,
              backgroundColor: blue,
              padding: 20 * scaleFactor,
              justifyContent: "center",
              position: "relative",
            }}
          >
            {/* Plan Toggle */}
            <View
              style={{
                position: "absolute",
                top: -30 * scaleFactor,
                alignSelf: "center",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: light,
                borderRadius: 25 * scaleFactor,
                paddingVertical: 10 * scaleFactor,
                paddingHorizontal: 10 * scaleFactor,
                zIndex: 1,
                transform: [{ scale: scaleFactor }],
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setSelectedPlan1("Básico");
                  // **RESET free trial toggle**
                  setIsTrialActive(false);
                }}
                style={{
                  paddingVertical: 10 * scaleFactor,
                  paddingHorizontal: 25 * scaleFactor,
                  backgroundColor:
                    selectedPlan === "Básico" ? blue : light,
                  borderRadius: 20 * scaleFactor,
                  marginHorizontal: 5 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Text
                  style={{
                    color: selectedPlan === "Básico" ? light : dark,
                    fontWeight: "bold",
                    fontSize: fontSizeLarge,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Básico
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setSelectedPlan1("Pro");
                  // **RESET free trial toggle**
                  setIsTrialActive(false);
                }}
                style={{
                  paddingVertical: 10 * scaleFactor,
                  paddingHorizontal: 25 * scaleFactor,
                  backgroundColor: selectedPlan === "Pro" ? blue : light,
                  borderRadius: 20 * scaleFactor,
                  marginHorizontal: 5 * scaleFactor,
                  transform: [{ scale: scaleFactor }],
                }}
              >
                <Text
                  style={{
                    color: selectedPlan === "Pro" ? light : dark,
                    fontWeight: "bold",
                    fontSize: fontSizeLarge,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  Pro
                </Text>
              </TouchableOpacity>
            </View>
            {/* Features Section */}
            <View
              style={{
                marginBottom: 20 * scaleFactor,
                marginTop: 50 * scaleFactor,
                transform: [{ scale: scaleFactor }],
              }}
            >
              {selectedPlanDetails.features.map((feature, index) => (
                <Text
                  key={index}
                  style={{
                    fontSize: fontSizeLarge,
                    color: light,
                    marginBottom: 8 * scaleFactor,
                    transform: [{ scale: scaleFactor }],
                  }}
                >
                  <Text
                    style={{
                      fontSize: fontSizeLarge,
                      color: yellow,
                      transform: [{ scale: scaleFactor }],
                    }}
                  >
                    ✓
                  </Text>{" "}
                  {feature}
                </Text>
              ))}
            </View>

            {/* Billing Cycle Options */}
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                transform: [{ scale: scaleFactor }],
              }}
            >
              {["Mensual", "Anual"].map((billingCycle) => {
                const isCurrentPlan =
                  selectedPlan === currentPlan &&
                  billingCycle === currentBillingCycle;
                const isSelected = selectedBillingCycle === billingCycle;

                return (
                  <TouchableOpacity
                    key={billingCycle}
                    onPress={() => {
                      setSelectedBillingCycle(billingCycle);
                      // **RESET free trial toggle**
                      setIsTrialActive(false);
                    }}
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      marginTop: 10 * scaleFactor,
                      marginBottom: 10 * scaleFactor,
                      borderColor: light,
                      paddingVertical: 8 * scaleFactor,
                      paddingHorizontal: 12 * scaleFactor,
                      borderRadius: 20 * scaleFactor,
                      marginHorizontal: 5 * scaleFactor,
                      alignItems: "center",
                      backgroundColor: isSelected ? light : "transparent",
                      position: "relative",
                      height: 125 * scaleFactor,
                      justifyContent: "center",
                      transform: [{ scale: scaleFactor }],
                    }}
                  >
                    {/* Small Box for 'Your Plan' */}
                    {isCurrentPlan && (
                      <View
                        style={{
                          backgroundColor: isSelected ? yellow : light,
                          paddingVertical: 3 * scaleFactor,
                          paddingHorizontal: 7 * scaleFactor,
                          borderRadius: 5 * scaleFactor,
                          position: "absolute",
                          top: -8 * scaleFactor,
                          alignSelf: "center",
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        <Text
                          style={{
                            color: dark,
                            fontSize: fontSizeSmall,
                            transform: [{ scale: scaleFactor }],
                          }}
                        >
                          Your Plan
                        </Text>
                      </View>
                    )}

                    <View
                      style={{
                        alignItems: "center",
                        transform: [{ scale: scaleFactor }],
                      }}
                    >
                      <Text
                        style={{
                          fontSize: fontSizeHuge,
                          fontWeight: "bold",
                          color: isSelected ? dark : light,
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        {selectedPlanDetails[billingCycle].price}
                      </Text>
                      <Text
                        style={{
                          fontSize: fontSizeLarge,
                          color: isSelected ? dark : light,
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        {selectedPlanDetails[billingCycle].cycle}
                      </Text>
                    </View>

                    {isSelected && (
                      <View
                        style={{
                          position: "absolute",
                          top: -10 * scaleFactor,
                          right: -5 * scaleFactor,
                          backgroundColor: yellow,
                          width: 20 * scaleFactor,
                          height: 20 * scaleFactor,
                          borderRadius: 10 * scaleFactor,
                          justifyContent: "center",
                          transform: [{ scale: scaleFactor }],
                        }}
                      >
                        <Text
                          style={{
                            color: dark,
                            fontSize: 12,
                            fontWeight: "bold",
                            textAlign: "center",
                            transform: [{ scale: scaleFactor }],
                          }}
                        >
                          ✓
                        </Text>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: yellow,
                paddingVertical: 12 * scaleFactor,
                borderRadius: 40 * scaleFactor,
                marginTop: 25 * scaleFactor,
                alignItems: "center",
                alignSelf: "center",
                width: "100%",
                transform: [{ scale: scaleFactor }],
              }}
              onPress={async () => {
                if (isPlanChanged) {
                  setIsSubscribing(true);
                  const success = await inAppBuySubscription(selectedPlan);
                  if (success) {
                    if (selectedPlan === "Pro") {
                      setIsTimeoutActive(false);
                      setChatCount(0);
                      setTrialChatCount(0);
                      AsyncStorage.setItem(
                        "isTimeoutActive",
                        JSON.stringify(false)
                      );
                      AsyncStorage.setItem("chatCount", JSON.stringify(0));
                      AsyncStorage.setItem("trialChatCount", JSON.stringify(0));
                    } else if (selectedPlan === "Básico") {
                      setChatCount(0);
                      setTrialChatCount(10);
                      setRemainingTime(43200000);
                      setIsTimeoutActive(false);
                      AsyncStorage.setItem(
                        "isTimeoutActive",
                        JSON.stringify(false)
                      );
                      AsyncStorage.setItem("chatCount", JSON.stringify(0));
                      AsyncStorage.setItem(
                        "trialChatCount",
                        JSON.stringify(10)
                      );
                    }
                    saveToSupabase();
                    setCurrentPlan(selectedPlan);
                    setCurrentBillingCycle(selectedBillingCycle);
                    setPage(9);
                  }
                  // If not successful, do nothing (alerts are handled in inAppBuySubscription)
                } else {
                  setPage(9);
                }
              }}
            >
              <Text
                style={{
                  color: dark,
                  fontSize: fontSizeLarge,
                  fontWeight: "bold",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                {buttonText}
              </Text>
            </TouchableOpacity>

            {/* 'Cancela tu subscripción' button */}
            {/* <TouchableOpacity
              style={{
                backgroundColor: "red",
                paddingVertical: 12 * scaleFactor,
                borderRadius: 40 * scaleFactor,
                marginTop: 18 * scaleFactor,
                alignItems: "center",
                alignSelf: "center",
                width: "100%",
                transform: [{ scale: scaleFactor }],
              }}
              onPress={handleCancelSubscription}
            >
              <Text
                style={{
                  color: dark,
                  fontSize: fontSizeLarge,
                  fontWeight: "bold",
                  textAlign: "center",
                  transform: [{ scale: scaleFactor }],
                }}
              >
                Cancela mi suscripción
              </Text>
            </TouchableOpacity> */}
          </View>
        </View>
      </View>
    );
  }
}
