import React from "react";
import { View, Text, SafeAreaView } from "react-native";
import { yellow, nunitoBold, textGray } from "../../../constants";

export default function MyProgressHeader() {
  return (
    <SafeAreaView>
      <View style={styles.header}>
        <Text style={styles.headerText}>My Progress</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = {
  header: {
    backgroundColor: yellow,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 18,
    marginHorizontal: 8,
    marginVertical: 8,
    borderRadius: 12,
    minHeight: 80,
  },
  headerText: {
    fontFamily: nunitoBold,
    fontWeight: "700",
    fontSize: 16,
    lineHeight: 20,
    letterSpacing: 0,
    color: textGray,
  },
};
