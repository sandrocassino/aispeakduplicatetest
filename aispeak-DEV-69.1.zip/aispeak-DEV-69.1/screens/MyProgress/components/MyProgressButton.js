import React, { useRef, useEffect } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, Animated } from "react-native";
import { blue, light, gray, nunitoBold } from "../../../constants";

const ICON_SIZE = 50;

export default function MyProgressButton({
  selectedOption,
  setSelectedOption,
  isActive,
  label,
  imagePath,
}) {
  const scaleAnim = useRef(new Animated.Value(isActive ? 2 : 1)).current;

  useEffect(() => {
    Animated.timing(scaleAnim, {
      toValue: isActive ? 2 : 1,
      duration: 100,
      useNativeDriver: true,
    }).start();
  }, [isActive]);

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={() => !isActive && setSelectedOption(label)}
      style={styles.container}
    >
      <Animated.View
        style={[
          styles.iconWrapper,
          {
            transform: [
              {
                translateY: Animated.multiply(
                  Animated.subtract(scaleAnim, 1),
                  -ICON_SIZE / 2
                ),
              },
              { scale: scaleAnim },
            ],
          },
        ]}
      >
        <Image
          source={imagePath}
          style={styles.iconImage}
          resizeMode="contain"
        />
      </Animated.View>
      <View
        style={[
          styles.button,
          { backgroundColor: isActive ? blue : light },
        ]}
      >
        <Text style={[styles.buttonText, { color: isActive ? light : gray }]}>
          {label}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
  },
  iconWrapper: {
    width: ICON_SIZE,
    height: ICON_SIZE,
    alignItems: "center",
    justifyContent: "center",
  },
  iconImage: {
    width: ICON_SIZE,
    height: ICON_SIZE,
  },
  button: {
    marginTop: 4,
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 16,
    minWidth: 180,
    alignItems: "center",
  },
  buttonText: {
    fontFamily: nunitoBold,
    fontSize: 16,
    lineHeight: 20,
    textAlign: "center",
  },
});