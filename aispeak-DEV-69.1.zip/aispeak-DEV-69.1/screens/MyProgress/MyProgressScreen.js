import React from "react";
import { View, StyleSheet, ScrollView, Image, Dimensions } from "react-native";
import MyProgresHeader from "./components/MyProgressHeader";
import MyProgressButton from "./components/MyProgressButton";
import NavigationSection from "../../NavigationBar/NavigationSection";
import { yellow } from "../../constants";

const bg = require("../../assets/images/my-progress-background.png");
const clouds = require("../../assets/images/my-progress-clouds.png");
const ocean = require("../../assets/images/my-progress-ocean.png");
const plant = require("../../assets/icons/my-progress-principiante.png");
const leaf = require("../../assets/icons/my-progress-intermedio.png");
const tree = require("../../assets/icons/my-progress-avanzado.png");

const { width: screenWidth } = Dimensions.get("window");
const IMAGE_ASPECT_RATIO = 1024 / 1820;
const imageHeight = screenWidth / IMAGE_ASPECT_RATIO;

export default function MyProgressScreen(props) {
  const { selectedOption, setSelectedOption } = props;

  return (
    <View style={styles.container}>
      <MyProgresHeader />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        bounces={true}
        alwaysBounceVertical={true}
        contentOffset={{ x: 0, y: 0 }}
      >
        <View style={{ height: imageHeight, marginTop: -imageHeight }}>
          <Image source={clouds} style={styles.bgImage} resizeMode="cover" />
        </View>
        {/* Anchor button to bg image */}
        <View
          style={{
            width: screenWidth,
            height: imageHeight,
            position: "relative",
          }}
        >
          <Image source={bg} style={styles.bgImage} resizeMode="cover" />
          <View style={styles.buttonPrincipiante}>
            <MyProgressButton
              selectedOption={selectedOption}
              setSelectedOption={setSelectedOption}
              isActive={selectedOption === "Principiante"}
              label="Principiante"
              imagePath={plant}
            />
          </View>
          <View style={styles.buttonIntermedio}>
            <MyProgressButton
              selectedOption={selectedOption}
              setSelectedOption={setSelectedOption}
              isActive={selectedOption === "Intermedio"}
              label="Intermedio"
              imagePath={leaf}
            />
          </View>
          <View style={styles.buttonAvanzado}>
            <MyProgressButton
              selectedOption={selectedOption}
              setSelectedOption={setSelectedOption}
              isActive={selectedOption === "Avanzado"}
              label="Avanzado"
              imagePath={tree}
            />
          </View>
        </View>
        <View style={{ height: imageHeight, marginBottom: -imageHeight }}>
          <Image source={ocean} style={styles.bgImage} resizeMode="cover" />
        </View>
      </ScrollView>
      <NavigationSection
        handlePressnow={props.handlePressnow}
        paperworkScale={props.paperworkScale}
        iconScale={props.iconScale}
        page={props.page}
        setPage={props.setPage}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: yellow,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    alignItems: "center",
  },
  bgImage: {
    width: screenWidth,
    height: imageHeight,
  },
  buttonPrincipiante: {
    position: "absolute",
    top: 456,
    left: 140,
    alignItems: "center",
    zIndex: 2,
  },
  buttonIntermedio: {
    position: "absolute",
    top: 188,
    left: 40,
    alignItems: "center",
    zIndex: 2,
  },
  buttonAvanzado: {
    position: "absolute",
    top: 64,
    left: 188,
    alignItems: "center",
    zIndex: 2,
  },
});
