// LevelScreen.js

import "react-native-url-polyfill/auto";
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableWithoutFeedback,
  Platform,
} from "react-native";
import { Modal } from "react-native";
import { Animated, Dimensions } from "react-native";
import "react-native-gesture-handler";
import { light, dark, yellow } from "../../constants";
import NavigationSection from "../../NavigationBar/NavigationSection";

export default function LevelScreen(props) {
  // Destructure all the props (states/functions) you need:
  const {
    modal2Visible,
    setNewModalVisible,
    closeModal2,
    newModalVisible,
    closeNewModal,
    closeNewModal2,
    showSparkle,
    hideContent,
    setChangeLevelNow,
    currentLevel,
    selectedOption,
    currentCountPrincipiante,
    currentCountIntermedio,
    currentCountAvanzado,
    scrollViewRef, // or if you are setting it locally, do so here
    screenHeight,
    paperworkScale,
    iconScale,
    documentScale,
    handlePressnow,
    styles,
    page,
    setPage
  } = props;

  // If you want to re-get screen dimensions here, you can:
  const { width: screenWidth, height: heightDevice } = Dimensions.get("window");
  const ratio = heightDevice / screenWidth;
  const scaleFactor = ratio < 1.9 ? 0.9 : 1.0;
  const scaleFactor2 = ratio < 1.9 ? 0.5 : 1.0;

  return (
    <View style={styles.container}>
      {/* ----------------------- MODAL #1 ----------------------- */}
      <Modal
        transparent={true}
        visible={modal2Visible}
        onRequestClose={closeModal2}
      >
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "rgba(0,0,0,0.5)",
          }}
        >
          <View
            style={{
              backgroundColor: light,
              padding: 20,
              borderRadius: 10,
              width: "90%",
              height: heightDevice <= 592 ? "70%" : "50%",
              justifyContent: "space-between",
              borderColor: yellow,
              borderWidth: 16,
            }}
          >
            {/* Title-like container */}
            <View
              style={{
                position: "absolute",
                top: "-5%",
                alignSelf: "center",
                backgroundColor: yellow,
                borderRadius: 8,
                padding: 12,
                borderColor: dark,
                borderWidth: 2.5,
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
                zIndex: 7,
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "bold",
                  textAlign: "center",
                  color: dark,
                }}
              >
                Rápida introducción❓
              </Text>
            </View>

            {/* Three overlapping background images + level images */}
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <View
                style={{
                  position: "absolute",
                  top: "2%",
                  left: "34%",
                  width: 140 * scaleFactor,
                  height: 140 * scaleFactor,
                }}
              >
                <Image
                  source={require("../../assets/images/explanations-principiante.png")}
                  style={{
                    width: "110%",
                    height: "110%",
                    resizeMode: "contain",
                  }}
                />
              </View>
              <View
                style={{
                  position: "absolute",
                  top: "27%",
                  left: "34%",
                  width: 140 * scaleFactor,
                  height: 140 * scaleFactor,
                }}
              >
                <Image
                  source={require("../../assets/images/explanations-intermedio.png")}
                  style={{
                    width: "110%",
                    height: "110%",
                    resizeMode: "contain",
                  }}
                />
              </View>
              <View
                style={{
                  position: "absolute",
                  top: "52%",
                  left: "34%",
                  width: 140 * scaleFactor,
                  height: 140 * scaleFactor,
                }}
              >
                <Image
                  source={require("../../assets/images/explanations-avanzado.png")}
                  style={{
                    width: "110%",
                    height: "110%",
                    resizeMode: "contain",
                  }}
                />
              </View>

              {/* Level images */}
              <Image
                source={require("../../assets/images/level-intermedio-color.png")}
                style={{
                  position: "absolute",
                  top: "31.5%",
                  left: "12%",
                  width: 100 * scaleFactor,
                  height: 100 * scaleFactor,
                  ...Platform.select({
                    ios: {
                      shadowColor: dark,
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.25,
                      shadowRadius: 4,
                    },
                    android: {
                      elevation: 5,
                    },
                  }),
                }}
              />
              <Image
                source={require("../../assets/images/level-avanzado-color.png")}
                style={{
                  position: "absolute",
                  top: "56.5%",
                  left: "12%",
                  width: 100 * scaleFactor,
                  height: 100 * scaleFactor,
                  ...Platform.select({
                    ios: {
                      shadowColor: dark,
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.25,
                      shadowRadius: 4,
                    },
                    android: {
                      elevation: 5,
                    },
                  }),
                }}
              />
              <Image
                source={require("../../assets/images/level-principiante-color.png")}
                style={{
                  position: "absolute",
                  top: "6.5%",
                  left: "12%",
                  width: 100 * scaleFactor,
                  height: 100 * scaleFactor,
                  ...Platform.select({
                    ios: {
                      shadowColor: dark,
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.25,
                      shadowRadius: 4,
                    },
                    android: {
                      elevation: 5,
                    },
                  }),
                }}
              />
            </View>
            <TouchableOpacity
              onPress={closeModal2}
              style={{
                position: "absolute",
                bottom: "5%",
                alignSelf: "center",
                backgroundColor: yellow,
                borderRadius: 20,
                padding: 10 * scaleFactor2,
                width: 110 * scaleFactor,
                borderColor: dark,
                borderWidth: 2,
              }}
            >
              <Text
                style={{
                  color: dark,
                  textAlign: "center",
                  fontWeight: "bold",
                }}
              >
                OK
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ----------------------- MODAL #2 ----------------------- */}
      <Modal
        transparent={true}
        visible={newModalVisible}
        onRequestClose={closeNewModal}
      >
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "rgba(0,0,0,0.5)",
          }}
        >
          <View
            style={{
              backgroundColor: light,
              padding: 20,
              borderRadius: 10,
              width: "70%",
              height: heightDevice <= 592 ? "44%" : "24%",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              onPress={closeNewModal2}
              style={{ position: "absolute", top: 10, right: 10 }}
            >
              <Text style={{ fontSize: 18, fontWeight: "bold" }}>×</Text>
            </TouchableOpacity>
            {showSparkle ? (
              <Image
                source={require("../../assets/images/sparkling-stars.gif")}
                style={{ width: 100, height: 100 }}
              />
            ) : (
              !hideContent && (
                <>
                  <Text
                    style={{
                      fontSize: 20,
                      fontWeight: "bold",
                      marginBottom: 20,
                    }}
                  >
                    ¿Estás seguro de que quieres cambiar el nivel?
                  </Text>
                  <TouchableOpacity
                    onPress={closeNewModal}
                    style={{
                      backgroundColor: "lightblue",
                      borderColor: dark,
                      borderWidth: 2,
                      borderRadius: 20,
                      paddingVertical: 10,
                      paddingHorizontal: 20,
                    }}
                  >
                    <Text style={{ color: dark, fontWeight: "bold" }}>
                      Cambiar ↻
                    </Text>
                  </TouchableOpacity>
                </>
              )
            )}
          </View>
        </View>
      </Modal>

      {/* ScrollView that shows Principiante / Intermedio / Avanzado */}
      <ScrollView
        style={{
          marginTop: screenHeight * 0.2,
          marginBottom: screenHeight * 0.2,
        }}
        ref={(ref) => {
          // If you want to store the ref in a parent, pass a callback or store it in props
          if (scrollViewRef) scrollViewRef.current = ref;
        }}
        onContentSizeChange={() => {
          // If using a real scrollViewRef in the parent, do:
          if (currentLevel >= 1) {
            // e.g. ref.scrollTo({ y: (currentLevel - 1) * 100, animated: true })
          }
          if (selectedOption === "Intermedio") {
            // e.g. ref.scrollTo({ y: 100, animated: true });
          }
          if (selectedOption === "Avanzado") {
            // e.g. ref.scrollToEnd({ animated: true });
          }
        }}
      >
        {["Principiante", "Intermedio", "Avanzado"].map((label, index) => (
          <View key={index} style={{ marginTop: 5, marginRight: 15 }}>
            {/* The big circle image depends on selectedOption */}
            <Image
              source={
                selectedOption === "Principiante"
                  ? index === 0
                    ? require("../../assets/images/level-principiante-color.png")
                    : index === 1
                    ? require("../../assets/images/level-intermedio-grayscale.png")
                    : require("../../assets/images/level-avanzado-grayscale.png")
                  : selectedOption === "Intermedio"
                  ? index === 0
                    ? require("../../assets/images/level-principiante-grayscale.png")
                    : index === 1
                    ? require("../../assets/images/level-intermedio-color.png")
                    : require("../../assets/images/level-avanzado-grayscale.png")
                  : selectedOption === "Avanzado"
                  ? index === 0
                    ? require("../../assets/images/level-principiante-grayscale.png")
                    : index === 1
                    ? require("../../assets/images/level-intermedio-grayscale.png")
                    : require("../../assets/images/level-avanzado-color.png")
                  : null
              }
              style={{
                width: index === 1 ? 210 : 200,
                height: index === 1 ? 210 : 200,
                alignSelf: "center",
                marginBottom: -15,
              }}
            />

            {/* The count label (e.g. “35/60” or “∞”) */}
            <View
              style={{
                position: "relative",
                top: "-14%",
                left: "39%",
                backgroundColor:yellow,
                paddingVertical: 5,
                paddingHorizontal: 10,
                borderRadius: 50,
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
                alignSelf: "flex-start",
                zIndex: 2,
              }}
            >
              <Text style={{ fontSize: 22, color: light, fontWeight: "bold" }}>
                {index === 0 ? (
                  currentCountPrincipiante >= 60 ? (
                    `${currentCountPrincipiante}/∞`
                  ) : (
                    `${currentCountPrincipiante}/60`
                  )
                ) : index === 1 ? (
                  currentCountIntermedio >= 60 ? (
                    `${currentCountIntermedio}/∞`
                  ) : (
                    `${currentCountIntermedio}/60`
                  )
                ) : (
                  <>
                    {currentCountAvanzado}/
                    <Text style={{ fontSize: 22 }}>∞</Text>
                  </>
                )}
              </Text>
            </View>

            {/* Lock icon if you aren't at that level */}
            {!(selectedOption === "Principiante" && index === 0) &&
              !(selectedOption === "Intermedio" && index === 1) &&
              !(selectedOption === "Avanzado" && index === 2) && (
                <Image
                  source={require("../../assets/images/locked-level.png")}
                  style={{
                    position: "absolute",
                    top: "53%",
                    alignSelf: "center",
                    width: 30,
                    height: 30,
                    zIndex: 3,
                  }}
                />
              )}

            {/* “Cambiar” button if it's not the current selection */}
            {selectedOption !== "Principiante" && index === 0 && (
              <TouchableOpacity
                style={{
                  position: "absolute",
                  top: "50%",
                  right: 10,
                  width: 70,
                  height: 30,
                  borderWidth: 2,
                  borderColor: "grey",
                  borderRadius: 25,
                  justifyContent: "center",
                  alignItems: "center",
                  zIndex: 3,
                }}
                onPress={() => {
                  setChangeLevelNow("Principiante");
                  // Show confirm modal
                  props.setNewModalVisible(true);
                }}
              >
                <Text
                  style={{ color: "grey", fontWeight: "bold", fontSize: 9 }}
                >
                  Cambiar
                </Text>
              </TouchableOpacity>
            )}

            {selectedOption !== "Intermedio" && index === 1 && (
              <TouchableOpacity
                style={{
                  position: "absolute",
                  top: "50%",
                  right: 10,
                  width: 70,
                  height: 30,
                  borderWidth: 2,
                  borderColor: "grey",
                  borderRadius: 25,
                  justifyContent: "center",
                  alignItems: "center",
                  zIndex: 3,
                }}
                onPress={() => {
                  setChangeLevelNow("Intermedio");
                  props.setNewModalVisible(true);
                }}
              >
                <Text
                  style={{ color: "grey", fontWeight: "bold", fontSize: 9 }}
                >
                  Cambiar
                </Text>
              </TouchableOpacity>
            )}

            {selectedOption !== "Avanzado" && index === 2 && (
              <TouchableOpacity
                style={{
                  position: "absolute",
                  top: "50%",
                  right: 10,
                  width: 70,
                  height: 30,
                  borderWidth: 2,
                  borderColor: "grey",
                  borderRadius: 25,
                  justifyContent: "center",
                  alignItems: "center",
                  zIndex: 3,
                }}
                onPress={() => {
                  setChangeLevelNow("Avanzado");
                  props.setNewModalVisible(true);
                }}
              >
                <Text
                  style={{ color: "grey", fontWeight: "bold", fontSize: 9 }}
                >
                  Cambiar
                </Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
        <View style={{ height: 50 }} />
      </ScrollView>

      {/* Mountain and aispeak images */}
      <Image
        source={require("../../assets/images/floating-island.png")}
        style={{
          position: "absolute",
          top: 38,
          alignSelf: "center",
          width: 200,
          height: 200,
          resizeMode: "contain",
          zIndex: 10,
        }}
      />
      <Image
        source={require("../../assets/images/capy.png")}
        style={{
          position: "absolute",
          top: 96,
          alignSelf: "center",
          width: 60,
          height: 60,
          resizeMode: "contain",
          zIndex: 20,
        }}
      />

      <NavigationSection handlePressnow={handlePressnow} paperworkScale={paperworkScale} iconScale={iconScale} page={page} setPage={setPage}/>
    </View>
  );
}
