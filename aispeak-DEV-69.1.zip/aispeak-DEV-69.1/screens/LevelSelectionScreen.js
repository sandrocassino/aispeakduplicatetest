import { useEffect } from "react";
import { View, TouchableOpacity, Image, Text } from "react-native";
import Styles from "../Styles";
import { light, lightBlue, gray, blue } from "../constants.js";

export default function LevelSelectionScreen({
  selectedOption,
  setSelectedOption,
  setPage,
  styles,
  screenHeight,
}) {
  useEffect(() => {
    console.log("LevelSelectionScreen mounted (entered)");
    return () => {
      console.log("LevelSelectionScreen unmounted (left)");
    };
  }, []);

  return (
    <View style={styles.container}>
      {/* Blank page */}
      <View style={[styles.blankPage, { marginTop: "10%" }]}>
        <View
          style={[
            styles.lightBox,
            {
              height:
                screenHeight >= 896
                  ? "50%"
                  : screenHeight >= 820
                    ? "50%"
                    : screenHeight >= 817
                      ? "50%"
                      : "50%",
              justifyContent: "space-between",
              alignItems: "center",
              paddingVertical: "4%",
            },
          ]}
        >
          <Text style={{ fontSize: 24, fontWeight: "bold", marginTop: 10 }}>
            ¿Qué nivel de inglés{"\n"}tienes?
          </Text>

          {/* Options */}
          <View style={{ width: "100%", alignItems: "center" }}>
            <TouchableOpacity
              style={[
                {
                  width: "90%",
                  padding: "5%",
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: gray,
                  marginVertical: "2%",
                  alignItems: "center",
                },
                selectedOption === "Principiante" && {
                  backgroundColor: lightBlue,
                },
              ]}
              onPress={() => setSelectedOption("Principiante")}
            >
              <Text style={{ fontSize: 20 }}>Principiante</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                {
                  width: "90%",
                  padding: "5%",
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: gray,
                  marginVertical: "2%",
                  alignItems: "center",
                },
                selectedOption === "Intermedio" && {
                  backgroundColor: lightBlue,
                },
              ]}
              onPress={() => setSelectedOption("Intermedio")}
            >
              <Text style={{ fontSize: 20 }}>Intermedio</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                {
                  width: "90%",
                  padding: "5%",
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: gray,
                  marginVertical: "2%",
                  alignItems: "center",
                },
                selectedOption === "Avanzado" && {
                  backgroundColor: lightBlue,
                },
              ]}
              onPress={() => setSelectedOption("Avanzado")}
            >
              <Text style={{ fontSize: 20 }}>Avanzado</Text>
            </TouchableOpacity>
          </View>

          {/* Next Button */}
          <TouchableOpacity
            style={{
              width: 160,
              padding: "3%",
              borderRadius: 10,
              backgroundColor: blue,
              alignItems: "center",
            }}
            onPress={() => {
              if (selectedOption) {
                setPage(5.2);
              }
            }}
          >
            <Text style={{ color: light, fontSize: 18, fontWeight: "bold" }}>
              Siguiente
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
