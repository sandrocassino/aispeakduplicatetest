import React from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Animated,
} from "react-native";
import Styles from "../Styles";
import { light, gray, dark, yellow, darkGray } from "../constants";

const LevelOverviewScreen = () => {
  const [currentCount, setCurrentCount] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(1);

  const [isGifClicked1, setIsGifClicked1] = useState(false);
  const [isGifClicked2, setIsGifClicked2] = useState(false);
  const [isGifClicked3, setIsGifClicked3] = useState(false);
  const [isGifClicked4, setIsGifClicked4] = useState(false);
  const [isGifClicked5, setIsGifClicked5] = useState(false);
  const [isGifClicked6, setIsGifClicked6] = useState(false);
  const [isGifClicked7, setIsGifClicked7] = useState(false);
  const [isGifClicked8, setIsGifClicked8] = useState(false);
  const [isGifClicked9, setIsGifClicked9] = useState(false);
  const [showImageOnPage7, setShowImageOnPage7] = useState(false);

  const [showButton, setShowButton] = useState(false);

  const startAnimation1 = () => {
    Animated.timing(scaleValue1, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked1(true);
      setPage(10);
    });
  };

  const startAnimation2 = () => {
    Animated.timing(scaleValue2, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked2(true);
      setPage(10);
    });
  };
  const startAnimation3 = () => {
    Animated.timing(scaleValue3, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked3(true);
      setPage(10);
    });
  };
  const startAnimation4 = () => {
    Animated.timing(scaleValue4, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked4(true);
      setPage(10);
    });
  };
  const startAnimation5 = () => {
    Animated.timing(scaleValue5, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked5(true);
      setPage(12);
    });
  };
  const startAnimation6 = () => {
    Animated.timing(scaleValue6, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked6(true);
      setPage(13);
    });
  };
  const startAnimation7 = () => {
    Animated.timing(scaleValue7, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked7(true);
      setPage(14);
    });
  };
  const startAnimation8 = () => {
    Animated.timing(scaleValue8, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked8(true);
      setPage(15);
    });
  };
  const startAnimation9 = () => {
    Animated.timing(scaleValue9, {
      toValue: 3,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      setIsGifClicked9(true);
      setPage(16);
    });
  };

  return (
    <View style={styles.container}>
      <ScrollView>
        {[...Array(10)].map((_, i) => (
          <View
            key={i}
            style={{
              marginBottom: 10,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
            }}
          >
            <View
              style={{
                marginLeft: "20%", // Move the light background more to the right
                backgroundColor: i + 1 <= currentLevel ? light : gray,
                height: 25,
                width: 65, // Changed width to match Page 7
                borderRadius: 5,
              }}
            />
            <Text
              style={{
                position: "absolute",
                top: "10%",
                left: "20%", // Adjusted position to overlay the light background
                fontSize: 13,
                fontWeight: "900",
                color: i + 1 <= currentLevel ? dark : darkGray,
              }}
            >
              LEVEL {i + 1}
            </Text>
            <View
              style={{
                position: "relative",
                top: "5%", // Move down
                left: "20%", // Move to the left
                backgroundColor:yellow,
                paddingVertical: 5,
                paddingHorizontal: 10,
                borderRadius: 50,
                ...Platform.select({
                  ios: {
                    shadowColor: dark,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25,
                    shadowRadius: 4,
                  },
                  android: {
                    elevation: 5,
                  },
                }),
              }}
            >
              <Text
                style={{
                  fontSize: 22,
                  color: light,
                  fontWeight: "bold",
                }}
              >
                {i + 1 < currentLevel
                  ? "50"
                  : i + 1 === currentLevel
                  ? currentCount
                  : "0"}
                /50
              </Text>
            </View>
            {i + 1 < currentLevel && (
              <TouchableOpacity
                onPress={() => {
                  if (i === 1 && !isGifClicked1) {
                    startAnimation1();
                  } else if (i === 2 && !isGifClicked2) {
                    startAnimation2();
                  } else if (i === 3 && !isGifClicked3) {
                    startAnimation3();
                  } else if (i === 4 && !isGifClicked4) {
                    startAnimation4();
                  } else if (i === 5 && !isGifClicked5) {
                    startAnimation5();
                  } else if (i === 6 && !isGifClicked6) {
                    startAnimation6();
                  } else if (i === 7 && !isGifClicked7) {
                    startAnimation7();
                  } else if (i === 8 && !isGifClicked8) {
                    startAnimation8();
                  } else if (i === 9 && !isGifClicked9) {
                    startAnimation9();
                  }
                  setPage(10);
                }}
                style={{ marginLeft: 0, zIndex: 10, position: "relative" }}
              >
                <Animated.Image
                  source={require("../assets/images/girl-typing-on-computer-with-cat.gif")}
                  style={{
                    width: 80,
                    height: 80,
                    transform: [{ scale: scaleValue }],
                  }}
                />
              </TouchableOpacity>
            )}
            {i + 1 > currentLevel && (
              <Image
                source={require("../assets/images/locked-level.png")}
                style={{
                  position: "absolute",
                  top: "5%",
                  alignSelf: "center",
                  width: 30,
                  height: 30,
                }}
              />
            )}
          </View>
        ))}
      </ScrollView>
      <View style={{ position: "absolute", bottom: 10, right: 250 }}>
        <TouchableWithoutFeedback
          onPress={() => {
            for (let i = 0; i < 10; i++) {
              setTimeout(() => {
                setPage(8);
              }, i * 1);
            }
          }}
          style={{
            position: "absolute",
            top: -85,
            left: -170,
            width: "400%",
            height: "400%",
          }}
        >
          <Image
            source={require("../assets/images/levels-menu.png")}
            style={[Styles.image11, { resizeMode: "contain" }]}
          />
        </TouchableWithoutFeedback>
      </View>
      <View style={{ position: "absolute", bottom: 20, right: 135 }}>
        <TouchableWithoutFeedback
          onPress={() => {
            for (let i = 0; i < 10; i++) {
              setTimeout(() => {
                setPage(7);
              }, i * 1);
            }
          }}
          style={{
            position: "absolute",
            top: -130,
            left: -110,
            width: "400%",
            height: "400%",
          }}
        >
          <Image
            source={require("../assets/images/home-menu.png")}
            style={[Styles.image8, { resizeMode: "contain" }]}
          />
        </TouchableWithoutFeedback>
      </View>
      <Image
        source={require("../assets/images/old-logo-and-brand.png")}
        style={{
          position: "absolute",
          top: 15,
          alignSelf: "center",
          width: 100,
          height: 100,
          resizeMode: "contain",
        }}
      />

      <Image
        source={require("../assets/images/floating-island.png")}
        style={{
          position: "absolute",
          top: 70,
          left: 105,
          alignSelf: "center",
          width: 200,
          height: 200,
          resizeMode: "contain",
        }}
      />
      <Image
        source={require("../assets/images/capy.png")}
        style={{
          position: "absolute",
          top: 96,
          left: 90,
          alignSelf: "center",
          width: 60,
          height: 60,
          resizeMode: "contain",
        }}
      />
      <View style={{ position: "absolute", bottom: 35, right: 40 }}>
        <TouchableWithoutFeedback
          onPress={() => {
            for (let i = 0; i < 10; i++) {
              setTimeout(() => {
                setPage(9);
              }, i * 1);
            }
          }}
          style={{
            position: "absolute",
            top: -85,
            left: -90,
            width: "400%",
            height: "400%",
          }}
        >
          <Image
            source={require("../assets/images/settings-menu.png")}
            style={[styles.image10, { resizeMode: "contain" }]}
          />
        </TouchableWithoutFeedback>
      </View>
    </View>
  );
};

export default LevelOverviewScreen;
