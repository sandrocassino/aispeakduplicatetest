import React from "react";
import { BlurView } from "expo-blur";
import "react-native-url-polyfill/auto";
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  PanResponder,
  Platform,
  KeyboardAvoidingView,
  Modal,
  Animated,
  Dimensions,
  Easing,
  SafeAreaView,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import styles from "../../Styles.js";
import { IMessage } from "react-native-gifted-chat";
import { GiftedChat } from "react-native-gifted-chat";
import { ActivityIndicator } from "react-native";
import { Bubble } from "react-native-gifted-chat";
import "react-native-gesture-handler";
import { Audio } from "expo-av";
import SoundIcon from "../../SoundIcon.js";
import TranslationPopup from "./components/TranslationPopup.js";
import AccordionCorrection from "./components/Accordion.js";
import CelebrationPopup from "./components/CelebrationPopup.js";
import {
  isFirstsentence2,
  isFirstChat,
  setisFirstChat,
  setisFirstsentence2,
} from "../../App.js";
import ChatHeader from "./components/ChatHeader.js";
import ChatBody from "./components/ChatBody.js";
import ChatInputToolbar from "./components/ChatInputToolbar.js";
import ChatIntroScreen from "./components/ChatIntroScreen";
import { light, yellow, dark } from "constants.js";
import supabase from "../../supabaseClient.js";
const screenHeight = Dimensions.get("window").height;

// Helper function to format milliseconds into MM:SS format
const formatTime = (millis) => {
  const validMillis =
    typeof millis === "number" && !isNaN(millis) && millis > 0 ? millis : 0;
  const totalSeconds = Math.floor(validMillis / 1000);
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  return `${minutes}:${seconds}`;
};

class ChatScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fakeChatbotMessage: "Where do you live?",
      recording: null,
      userName: props.userName,
      isMicEnabled: false,
      isMicEnabled2: false,
      isRecording: false,
      isLoading: false,
      stopLoading: false,
      shouldUpdateImage: false,
      apiResponse: null,
      selectedOption: "Principiante",
      messages: [],
      avatar1: require("../../assets/images/capy-in-white-circle-yellow-bg.png"),
      newMessage: "",
      loading: false,
      showPopupnewer2: false,
      wiggleNeedsToStop: false,
      thirdchat: false,
      hasGreeted: false,
      resetChat: false,
      avatarImagePath: null,
      isDialogVisible: false,
      translatedText: "",
      translationProgress: 0,
      sound: null,
      isInputFocused: false,
      showSoundIcon: false,
      showSoundIcon2: false,
      rotation: new Animated.Value(0),
      correctAnswers: 0,
      showCelebration: false,
      accordionOpen: false,
      currentPlayingSound: null,
      currentlyPlayingAudioId: null,
      playbackPositionMillis: 0,
      playbackDurationMillis: 0,
      lastRecordedAudioUri: null,
      lastRecordedAudioDuration: 0,
      isPaused: false,
    };

    this.startWiggle = this.startWiggle.bind(this);
    this.onOpenDialog = this.onOpenDialog.bind(this);
    this.translateText = this.translateText.bind(this);
    this.onSend = this.onSend.bind(this);
    this.startRecording = this.startRecording.bind(this);
    this.stopRecording = this.stopRecording.bind(this);
    this.handleMessageChange = this.handleMessageChange.bind(this);
    this.handleIsInputFocused = this.handleIsInputFocused.bind(this);
    this.handleCorrectAnswer = this.handleCorrectAnswer.bind(this);
    this.closeCelebration = this.closeCelebration.bind(this);

    // --- Audio slider handlers ---
    this.playRecordedAudio = this.playRecordedAudio.bind(this);
    this.pauseRecordedAudio = this.pauseRecordedAudio.bind(this);
    this.seekAudio = this.seekAudio.bind(this);
    this.resetPlaybackState = this.resetPlaybackState.bind(this);

    this.recording = new Audio.Recording();
    this.recordingOptions = {
      android: {
        extension: ".m4a",
        outputFormat: Audio.AndroidOutputFormat.MPEG_4,
        audioEncoder: Audio.AndroidAudioEncoder.AAC,
        sampleRate: 44100,
        numberOfChannels: 1,
      },
      ios: {
        extension: ".m4a",
        audioQuality: Audio.IOSAudioQuality.HIGH,
        outputFormat: Audio.IOSOutputFormat.MPEG4AAC,
        sampleRate: 44100,
        numberOfChannels: 2,
      },
      web: {
        mimeType: "audio/mp4",
        bitsPerSecond: 128000,
      },
    };

    this.panResponder = PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        this.setState({ translationProgress: 0 });
      },
      onPanResponderMove: (event, gestureState) => {
        const progress = Math.min(Math.max(gestureState.dy / 200, 0), 1);
        this.setState({ translationProgress: progress });
      },
      onPanResponderRelease: () => {
        this.translateText(this.state.newMessage);
      },
    });
  }

  // --- Audio slider methods ---
  playRecordedAudio = async (uri, messageId) => {
    console.log("playRecordedAudio called", { uri, messageId });
    console.log("currentPlayingSound:", this.state.currentPlayingSound);
    console.log("currentlyPlayingAudioId:", this.state.currentlyPlayingAudioId);

    if (
      this.state.currentPlayingSound &&
      this.state.currentlyPlayingAudioId === messageId
    ) {
      try {
        console.log("Attempting to resume audio for messageId:", messageId);
        await this.state.currentPlayingSound.playAsync();
        console.log("playAsync() called for messageId:", messageId);
        this.setState((prevState) => ({
          messages: prevState.messages.map((msg) =>
            msg._id === messageId ? { ...msg, isPlaying: true } : msg
          ),
          isPaused: false,
        }));
        return;
      } catch (e) {
        console.error("Error resuming audio:", e);
      }
    }

    // If another audio is playing, unload it first
    if (this.state.currentPlayingSound) {
      console.log("Unloading previous sound");
      await this.state.currentPlayingSound.unloadAsync();
      this.setState((prevState) => ({
        messages: prevState.messages.map((msg) =>
          msg._id === prevState.currentlyPlayingAudioId
            ? { ...msg, isPlaying: false }
            : msg
        ),
        currentPlayingSound: null,
        currentlyPlayingAudioId: null,
        playbackPositionMillis: 0,
        playbackDurationMillis: 0,
      }));
    }

    this.setState((prevState) => ({
      messages: prevState.messages.map((msg) =>
        msg._id === messageId ? msg : { ...msg, _playbackTick: 0 }
      ),
      playbackPositionMillis: 0,
    }));

    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
      });
      console.log("Creating new sound for uri:", uri);
      const { sound, status } = await Audio.Sound.createAsync(
        { uri },
        { progressUpdateIntervalMillis: 500 }
      );

      this.setState((prevState) => ({
        currentPlayingSound: sound,
        currentlyPlayingAudioId: messageId,
        playbackDurationMillis: status.durationMillis || 0,
        playbackPositionMillis: 0,
        messages: prevState.messages.map((msg) => ({
          ...msg,
          isPlaying: msg._id === messageId,
        })),
      }));

      sound.setOnPlaybackStatusUpdate(async (playbackStatus) => {
        console.log("Playback status update:", playbackStatus);
        if (!playbackStatus.isLoaded) {
          if (playbackStatus.error)
            console.error(`Playback Error: ${playbackStatus.error}`);
          this.resetPlaybackState();
        } else {
          this.setState((prevState) => ({
            playbackPositionMillis: playbackStatus.positionMillis,
            messages: prevState.messages.map((msg) =>
              msg._id === prevState.currentlyPlayingAudioId
                ? { ...msg, _playbackTick: playbackStatus.positionMillis }
                : msg
            ),
          }));
          if (playbackStatus.didJustFinish && !playbackStatus.isLooping) {
            this.resetPlaybackState();
          }
        }
      });
      await sound.playAsync();
      console.log("Started playing audio for messageId:", messageId);
    } catch (error) {
      console.error("Error playing recorded audio:", error);
      this.resetPlaybackState();
    }
  };

  pauseRecordedAudio = async () => {
    console.log("pauseRecordedAudio called");
    if (this.state.currentPlayingSound) {
      try {
        await this.state.currentPlayingSound.pauseAsync();
        this.setState((prevState) => ({
          messages: prevState.messages.map((msg) =>
            msg._id === prevState.currentlyPlayingAudioId
              ? { ...msg, isPlaying: false }
              : msg
          ),
          isPaused: true,
        }));
        console.log(
          "Paused audio for messageId:",
          this.state.currentlyPlayingAudioId
        );
      } catch (error) {
        console.error("Error pausing audio:", error);
        this.resetPlaybackState();
      }
    }
  };

  seekAudio = async (value, messageId) => {
    if (
      this.state.currentPlayingSound &&
      this.state.currentlyPlayingAudioId === messageId
    ) {
      try {
        await this.state.currentPlayingSound.setPositionAsync(value);
        this.setState({ playbackPositionMillis: value });
      } catch (error) {
        console.error("Error seeking audio:", error);
      }
    }
  };

  resetPlaybackState = () => {
    if (this.state.currentPlayingSound) {
      this.state.currentPlayingSound
        .unloadAsync()
        .catch((e) => console.error("Error unloading sound in reset:", e));
    }
    this.setState((prevState) => ({
      currentPlayingSound: null,
      currentlyPlayingAudioId: null,
      playbackPositionMillis: 0,
      playbackDurationMillis: 0,
      messages: prevState.messages.map((msg) => ({ ...msg, isPlaying: false })),
    }));
  };

  onOpenDialog(isVisible) {
    this.setState({ isDialogVisible: isVisible });
  }

  handleMessageChange = (text) => {
    this.setState({ newMessage: text });
  };

  handleQuestionMarkClick2 = () => {
    this.setState({ showPopupnewer2: true });
  };

  handleClosePopup2 = () => {
    this.setState({ showPopupnewer2: false });
  };

  handleOnLongPress = () => {
    if (this.props.isTimeoutActive && this.props.thirdchat) {
      this.handleQuestionMarkClick2();
    } else {
      this.setState({ isLoading: false, stopLoading: false });
      this.startRecording();
      this.props.setMicEnabled2(true);
    }
  };

  handleIsInputFocused = (focus) => {
    this.setState({ isInputFocused: focus });
  };

  // Correct answers count to set celebration popup
  handleCorrectAnswer = () => {
    console.log("✅ Answer was correct!");

    this.setState(
      (prevState) => {
        const newCount = prevState.correctAnswers + 1;

        const shouldCelebrate = newCount % 5 === 0;

        return {
          correctAnswers: newCount,
          showCelebration: shouldCelebrate ? false : prevState.showCelebration,
        };
      },
      () => {
        if (this.state.correctAnswers % 5 === 0) {
          console.log("🎉 Triggering celebration modal");
          setTimeout(() => {
            this.setState({ showCelebration: true });
          }, 10);
        }
      }
    );
  };

  closeCelebration = () => {
    this.setState({ showCelebration: false });
  };

  playSound = async (text, onSoundFinish) => {
    const removeEmojisAndSmileys = (string) => {
      const emojiAndSmileyRegEx =
        /(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|[\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|[\ud83c[\ude32-\ude3a]|[\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff]|:\))/g;
      return string.replace(emojiAndSmileyRegEx, "");
    };

    try {
      const textWithoutEmojis = removeEmojisAndSmileys(text);
      const response = await fetch(
        "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/TextToSpeechMiddleware",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: textWithoutEmojis }),
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Backend error:", errorText);
        throw new Error("Failed to get audio from backend");
      }

      const data = await response.json();
      if (!data.audioUrl) {
        throw new Error("No audioUrl in backend response");
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        staysActiveInBackground: false,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: false,
        playsInSilentLockedModeIOS: true,
      });

      const { sound } = await Audio.Sound.createAsync({ uri: data.audioUrl });
      sound.setOnPlaybackStatusUpdate(async (playbackStatus) => {
        if (playbackStatus.error) {
          console.error(
            "An error occurred while playing the sound:",
            playbackStatus.error
          );
        } else if (playbackStatus.didJustFinish) {
          if (onSoundFinish) {
            onSoundFinish();
          }
          await sound.unloadAsync();
        }
      });

      this.setState({ sound });
      await sound.playAsync();
    } catch (error) {
      console.error("Error playing sound from backend:", error);
    }
  };

  startWiggle() {
    Animated.loop(
      Animated.sequence([
        Animated.timing(this.state.rotation, {
          toValue: 1,
          duration: 100,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.timing(this.state.rotation, {
          toValue: -1,
          duration: 200,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.timing(this.state.rotation, {
          toValue: 0,
          duration: 100,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }

  closeModal = () => {
    this.props.setModalVisible(false);
  };

  async translateText(text, to = "es") {
    try {
      const response = await fetch(
        "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/TranslateTextMiddleware",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ text, to }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }

      const responseData = await response.json();
      const translatedText = responseData.translatedText || "";

      this.setState({ translatedText });
    } catch (error) {
      console.error("Error translating text:", error);
    }
  }

  async generateMessagesWithAvatar2() {
    this.loadMessages();
    if (isFirstChat) {
      const sentencePairs = [
        [
          `Hi, I'm Capy! 🐾 your new English buddy`,
          "I’m from the wetlands of South America 🌿! It’s peaceful and full of friends. 🧡 Where do you live?",
        ],
        [
          `Hi, I'm Capy! 🐾 your new English buddy`,
          "I’m from the wetlands of South America 🌿! It’s peaceful and full of friends. 🧡 Where do you live?",
        ],
      ];

      let sentence1, sentence2;
      if (!isFirstsentence2) {
        [sentence1, sentence2] = sentencePairs[0];
      } else {
        const randomIndex =
          Math.floor(Math.random() * (sentencePairs.length - 1)) + 1;
        [sentence1, sentence2] = sentencePairs[randomIndex];
      }

      this.setState({ fakeChatbotMessage: `${sentence1} ${sentence2}` });

      setTimeout(() => {
        this.setState(
          (previousState) => ({
            messages: GiftedChat.append(previousState.messages, [
              {
                _id: Math.round(Math.random() * 1000000),
                text: isFirstsentence2 ? `${sentence1}` : `${sentence1}`,
                createdAt: new Date(),
                user: {
                  _id: 2,
                  name: "Aispeak",
                  avatar:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarImages[this.props.avatarKey]
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarImages[this.props.avatarKey2]
                      : this.props.avatarImages[this.props.avatarKey3],
                  avatarKey:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarKey
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarKey2
                      : this.props.avatarKey3,
                },
                chatKey: this.props.chatKey,
              },
            ]),
          }),
          () => this.saveMessages()
        );
        setisFirstsentence2(true);
      }, 1000);

      setTimeout(() => {
        this.setState(
          (previousState) => ({
            messages: GiftedChat.append(previousState.messages, [
              {
                _id: Math.round(Math.random() * 1000000),
                text: `${sentence2}`,
                createdAt: new Date(),
                user: {
                  _id: 2,
                  name: "Aispeak",
                  avatar:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarImages[this.props.avatarKey]
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarImages[this.props.avatarKey2]
                      : this.props.avatarImages[this.props.avatarKey3],
                  avatarKey:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarKey
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarKey2
                      : this.props.avatarKey3,
                },
                chatKey: this.props.chatKey,
                showSoundIcon2: true,
              },
            ]),
          }),
          () => this.saveMessages()
        );
      }, 2000);
      setisFirstChat(false);

      this.props.setChatHistory((prevChatHistory) => {
        const newMessage = `Your last message to the user ${
          prevChatHistory.length + 1
        }: ${sentence1} ${sentence2}`;
        this.props.addMessageToChatHistory(newMessage);
        return [...prevChatHistory, newMessage];
      });
    }
  }

  async componentDidMount() {
    this.cleanupAudioRecording();
    this.generateMessagesWithAvatar2();
    this.setState({
      avatarImagePath: require("../../assets/images/capy-in-white-circle-yellow-bg.png"),
    });
  }

  componentWillUnmount() {
    this.cleanupAudioRecording();

    if (this.state.sound) {
      this.state.sound
        .unloadAsync()
        .catch((e) => console.error("Error unloading TTS sound:", e));
    }
    if (this.state.currentPlayingSound) {
      this.state.currentPlayingSound
        .unloadAsync()
        .catch((e) => console.error("Error unloading recorded audio:", e));
    }
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    if (this.checkTimeoutInterval) {
      clearInterval(this.checkTimeoutInterval);
    }
  }

  cleanupAudioRecording = async () => {
    try {
      if (this.state.recording) {
        await this.state.recording.stopAndUnloadAsync();
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: false,
      });

      this.setState({
        recording: null,
        isRecording: false,
        isLoading: false,
        stopLoading: false,
        apiResponse: null,
      });
    } catch (error) {
      console.error("Error cleaning up recording:", error);
    }
  };

  handleButtonClick = () => {
    console.log("isTimeoutActive mate:", this.props.isTimeoutActive);
    console.log("thirdchat before setState:", this.props.thirdchat);

    if (this.props.isTimeoutActive) {
      console.log("setState is about to be called with thirdchat: true");
      this.setState({ thirdchat: true });
      console.log("thirdchat has been set to true.");
    } else {
      console.log("isTimeoutActive is false, thirdchat is not updated.");
    }

    this.props.setPage(7);
  };

  handlePressnew = async () => {
    const text = this.currentMessage.text;
    this.playSound(text);
  };


  async saveMessages() {
    try {
      if (this.state.messages && this.state.messages.length > 0) {
        const latestMessage = this.state.messages[0];
        console.log("Latest message text being saved:", latestMessage.text);
      }
      console.log("Saving messages...");
      await AsyncStorage.setItem(
        `chat${this.props.chatKey}`,
        JSON.stringify(this.state.messages)
      );
    } catch (error) {
      console.error("Error saving messages:", error);
    }
  }

  //FUNCTION TO SAVE THE MESSSAGES TO THE DATABASE
  async saveMessagestoDB(messageObject){
      const { text, user, chatKey, isGrammarChecker } = messageObject;

    const { data, error, status } = await supabase
        .from('chat_messages')
        .insert({
          user_id: user._id,
          event_timestamp: new Date().toISOString(),
          sender: user?.name === "User" ? "user" : "chatbot",
          message_text: text,
          conversation_id: chatKey,
          isGrammarChecker: isGrammarChecker?? false,

        })
        .select();
      console.log(`Insert result (${user.name}):`, { data, error, status });

  }
//LOGIC FOR CALLING THE FACT EXTRACTION MIDDLEWARE.
//THE INSERTS INTO THE DATABASE (IF ANY FACTS ARE FOUND) HAPPEN INSIDE THE MIDDLEWARE
  async call_user_fact_extraction(userMessageText, user_id){
  try {
    // 1. Get user facts from Supabase
    const { data, error } = await supabase
      .from('user_facts')
      .select('fact')
      .eq('user_id', user_id)
      .order('inserted_at', { ascending: false });

    if (error) {
      console.error("Supabase error:", error);
      return;
    }

    // 2. Format the facts
    const formattedFacts = data?.map(f => f.facts).join("\n") || "";

    // 3. Send the formatted data to the middleware
    const response = await fetch(
      "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/fact_extraction",
      {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9qY3N2aGZrdmFqcnBqd2R2YmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc3NDIxNDcsImV4cCI6MjAyMzMxODE0N30.MrjI-nWf70wZJSmvRMEK9qjEz_Iv_9qGhLp82SzvRSE`
 },
        body: JSON.stringify({
          userId: user_id,
          userMessage: userMessageText,
          userfacts: formattedFacts,
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Chatbot API error:", errorText);
      throw new Error("Failed to fetch data from FactExtractionMiddleware");
    }

    const result = await response.json();
    if (result[0]?.containsFact) {
  console.log("✅ Fact detected:", result[0].userFact);
} else {
  console.log("❌ No fact found in user message.");
}
    return result;

  } catch (error) {
    console.error("Error with AI call:", error);
  }
};

//FUNCTION TO CREATE THE CHAT OVERVIEW
//THE RESULTS GET LOGGED. THE INSERTS ARE HANDLED INSIDE THE MIDDLEWARE
async call_chat_overview_creation(user_id){
  const TOKEN_LIMIT = 400;

  function estimateTokenCount(text) {
    return Math.ceil(text.length / 4); // approx. OpenAI token cost
  }

  try {
    // 1. Retrieve chat history from Supabase
    const { data, error } = await supabase
      .from('chat_messages')
      .select('id, sender, message_text')
      .eq('user_id', user_id)
      .eq('isGrammarChecker', false)
      .order('inserted_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error("Supabase error:", error);
      return;
    }

    if (!data || data.length === 0) {
      console.log("No messages found.");
      return;
    }

    // 2. Trim to token limit
    const messages = [];
    let totalTokens = 0;

    for (const row of data) {
      const tokenCount = estimateTokenCount(row.message_text);
      if (totalTokens + tokenCount > TOKEN_LIMIT) break;

      messages.push(row);
      totalTokens += tokenCount;
    }

    const chatHistory = messages.reverse(); // Keep original order

    // 3. Send to middleware
    const response = await fetch(
      "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/create_chat_overview",
      {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9qY3N2aGZrdmFqcnBqd2R2YmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc3NDIxNDcsImV4cCI6MjAyMzMxODE0N30.MrjI-nWf70wZJSmvRMEK9qjEz_Iv_9qGhLp82SzvRSE`

        },
        body: JSON.stringify({
          userId: user_id,
          chatHistory, // raw chat history
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Chat Overview API error:", errorText);
      throw new Error("Failed to fetch data from ChatOverviewMiddleware");
    }

    const result = await response.json();
    console.log("📝 Chat Overview Middleware Response:", result);
    return result;

  } catch (err) {
    console.error("Chat overview creation error:", err);
  }
};




  async loadMessages() {
    if (this.props.shouldLoadMessages) {
      try {
        console.log("Loading messages...");
        const messages = await AsyncStorage.getItem(
          `chat${this.props.chatKey}`
        );
        if (messages) {
          let parsedMessages = JSON.parse(messages).map((message) => ({
            ...message,
            user: {
              ...message.user,
              avatar: this.props.avatarImages[message.user.avatarKey],
            },
            durationMillis: message.durationMillis || 0,
            audio: message.audio || null,
            isPlaying: false,
          }));

          parsedMessages = parsedMessages.filter(
            (message) => message.chatKey === this.props.chatKey
          );

          this.setState({ messages: parsedMessages });
        }
      } catch (error) {
        console.error("Error loading messages:", error);
      }
    } else {
      this.props.setShouldLoadMessages(true);
    }
  }

  startRecording = async () => {
    if (this.state.isRecording) {
      console.error("Recording is already in progress.");
      return;
    }

    this.setState({ isRecording: true });

    try {
      console.log("Requesting permissions..");

      const { status } = await Audio.requestPermissionsAsync();

      if (status !== "granted") {
        throw new Error("PERMISSION_DENIED");
      }

      const { canAskAgain } = await Audio.getPermissionsAsync();
      if (!canAskAgain && status !== "granted") {
        throw new Error("PERMISSION_PERMANENTLY_DENIED");
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      console.log("Starting recording..");
      const recording = new Audio.Recording();
      await recording.prepareToRecordAsync(this.recordingOptions); // Use your custom options!
      await recording.startAsync();
      this.setState({ recording });
      console.log("Recording started");
    } catch (err) {
      this.handleRecordingError(err);
    }
  };

  stopRecording = async () => {
    if (!this.state.recording) {
      console.warn("No recording to stop.");
      this.setState({ isRecording: false, isLoading: false });
      return;
    }
    this.setState({ isRecording: false, isLoading: true });
    const recordingInstance = this.state.recording;
    this.setState({ recording: undefined });

    try {
      await recordingInstance.stopAndUnloadAsync();
      const uri = recordingInstance.getURI();
      if (!uri) throw new Error("Recording URI is null");

      let durationMillis = 0;
      try {
        const { sound: tempSound, status: tempStatus } =
          await Audio.Sound.createAsync({ uri: uri }, { shouldPlay: false });
        if (tempStatus.isLoaded) {
          durationMillis = tempStatus.durationMillis;
          await tempSound.unloadAsync();
        }
      } catch (e) {
        console.error("Error getting duration for recorded audio:", e);
      }

      this.setState({
        lastRecordedAudioUri: uri,
        lastRecordedAudioDuration: durationMillis,
      });
      this.processRecording(uri);
    } catch (error) {
      this.handleRecordingError(error);
      this.setState({
        isLoading: false,
        lastRecordedAudioUri: null,
        lastRecordedAudioDuration: 0,
      });
    }
  };

  cancelRecording = async () => {
    if (!this.state.isRecording || !this.state.recording) {
      console.warn("No active recording to cancel");
      return;
    }

    this.setState({ isRecording: false });
    console.log("Canceling recording..");

    const { recording } = this.state;
    this.setState({ recording: undefined });

    try {
      await recording.stopAndUnloadAsync();
      console.log("Recording canceled");
    } catch (error) {
      console.error("Error canceling recording:", error);
    }
  };

  handleMicPress = () => {
    console.log("Single tap detected - start recording");
    if (this.props.isTimeoutActive && this.state.thirdchat) {
      this.handleQuestionMarkClick2();
    } else {
      this.setState({ isLoading: false, stopLoading: false });
      this.startRecording();
      this.props.setMicEnabled2(true);
    }
  };

  processRecording = async (uri) => {
    try {
      const formData = new FormData();
      formData.append("file", {
        uri: uri,
        name: "audio.m4a",
        type: "audio/m4a",
      });

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      const voiceToTextResponse = await fetch(
        "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/NewVoiceToTextMiddleware",
        {
          method: "POST",
          body: formData,
          signal: controller.signal,
        }
      );

      clearTimeout(timeoutId);

      if (!voiceToTextResponse.ok) {
        const errorText = await voiceToTextResponse.text();
        console.error("Voice to text API error:", errorText);
        Alert.alert(
          "Error",
          "No se pudo procesar el audio. Inténtalo de nuevo."
        );
        return;
      }

      const whisperData = await voiceToTextResponse.json();
      const transcribedText = whisperData.text || whisperData.translation || "";

      if (transcribedText.trim().length === 0) {
        Alert.alert(
          "Error",
          "No se detectó texto en la grabación. Inténtalo de nuevo."
        );
        return;
      }

      this.setState({
        apiResponse: transcribedText,
        isLoading: false,
      });

      this.onSend([{ text: transcribedText }]);
    } catch (error) {
      this.setState({ isLoading: false });

      if (error.name === "AbortError") {
        Alert.alert(
          "Timeout",
          "La solicitud tardó demasiado. Verifica tu conexión e inténtalo de nuevo."
        );
      } else {
        console.error("Processing error:", error);
        Alert.alert(
          "Error de red",
          "Verifica tu conexión a internet e inténtalo de nuevo."
        );
      }
    }
  };

  handleRecordingError = (error) => {
    console.error("Recording error:", error);

    this.setState({
      isRecording: false,
      recording: undefined,
      isLoading: false,
    });

    let userMessage = "Ha ocurrido un error con la grabación";
    let actionRequired = false;

    switch (error.message) {
      case "PERMISSION_DENIED":
        userMessage =
          "Necesitamos permiso para usar el micrófono. Por favor, permite el acceso en la configuración.";
        actionRequired = true;
        break;

      case "PERMISSION_PERMANENTLY_DENIED":
        userMessage =
          "El acceso al micrófono está deshabilitado. Ve a Configuración > Aispeak > Micrófono para habilitarlo.";
        actionRequired = true;
        break;

      case "RECORDING_FAILED":
        userMessage =
          "No se pudo iniciar la grabación. Verifica que el micrófono esté disponible.";
        break;

      case "MICROPHONE_UNAVAILABLE":
        userMessage =
          "El micrófono no está disponible. Verifica que no esté siendo usado por otra aplicación.";
        break;

      case "NETWORK_ERROR":
        userMessage =
          "Error de conexión. Verifica tu conexión a internet e inténtalo de nuevo.";
        break;

      case "TRANSCRIPTION_FAILED":
        userMessage = "No se pudo procesar el audio. Inténtalo de nuevo.";
        break;

      default:
        if (error.message?.includes("interrupted")) {
          userMessage = "La grabación fue interrumpida. Inténtalo de nuevo.";
        }
        break;
    }

    Alert.alert(
      "Error de Grabación",
      userMessage,
      actionRequired
        ? [
            { text: "Cancelar", style: "cancel" },
            {
              text: "Abrir Configuración",
              onPress: () => Linking.openSettings(),
            },
          ]
        : [{ text: "OK" }]
    );
  };

  async onSend(messages = []) {
    await new Promise((resolve) => {
      this.setState({ stopLoading: true }, () => {
        this.forceUpdate();
        resolve();
      });
    });

    let userMessageText = messages[0].text;

    const userMessageObject = {
      _id: Math.round(Math.random() * 1000000),
      text: userMessageText,
      createdAt: new Date(),
      user: { _id: 1, name: "User" },
      chatKey: this.props.chatKey,
    };
    //CALLING THE FUNCTIONS TO INSERT MESSAGES, EXTRACT FACTS AND CREATE CHAT OVERVIEWS
    await this.saveMessagestoDB(userMessageObject);
    await this.call_user_fact_extraction(userMessageObject.text, userMessageObject.user._id)

    //STILL LEFT TO FIGURE OUT A WAY TO ONLY CALL THIS FUNCTION EVERY 20 MESSAGES OR SO
    //SO FAR ITS GETTING CALLED WITH EVERY MESSAGE FOR TESTING PURPOSES
    await this.call_chat_overview_creation(userMessageObject.user._id)



    // If it's an audio message, attach URI and duration from state
    if (this.state.lastRecordedAudioUri) {
      userMessageObject.audio = this.state.lastRecordedAudioUri;
      userMessageObject.durationMillis = this.state.lastRecordedAudioDuration;
    }

    this.setState(
      (previousState) => ({
        messages: GiftedChat.append(previousState.messages, [
          userMessageObject,
        ]),
        newMessage: "",
        loading: true,
        lastRecordedAudioUri: null,
        lastRecordedAudioDuration: 0,
      }),
      async () => {
        // Step 2: Add the typing indicator after the user message
        this.setState((previousState) => ({
          messages: GiftedChat.append(previousState.messages, [
            {
              _id: "typing-indicator",
              image: require("../../assets/images/typing-dots.gif"),
              isTypingIndicator: true,
              createdAt: new Date(),
              user: {
                _id: 2,
                name: "Aispeak",
                avatar:
                  this.props.selectedOption === "Principiante"
                    ? this.props.avatarImages[this.props.avatarKey]
                    : this.props.selectedOption === "Intermedio"
                    ? this.props.avatarImages[this.props.avatarKey2]
                    : this.props.avatarImages[this.props.avatarKey3],
                avatarKey:
                  this.props.selectedOption === "Principiante"
                    ? this.props.avatarKey
                    : this.props.selectedOption === "Intermedio"
                    ? this.props.avatarKey2
                    : this.props.avatarKey3,
              },
              chatKey: this.props.chatKey,
              isTypingIndicator: true,
            },
          ]),
        }));
        // await this.saveMessages();

        const chatHistoryForAI = this.state.messages.map((msg) => ({
          text: msg.text,
          user: msg.user,
          createdAt: msg.createdAt,
          isGrammarChecker: msg.isGrammarChecker,
          showSoundIcon: msg.showSoundIcon,
        }));
        try {
          const response = await fetch(
            "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/NewChatBotMiddleware",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                userMessage: userMessageText,
                chatHistory: chatHistoryForAI,
                selectedOption: this.props.selectedOption,
                userName: this.state.userName,
                fakeChatbotMessage: this.state.fakeChatbotMessage,
              }),
            }
          );
          if (!response.ok) {
            const errorText = await response.text();
            console.error("Chatbot API error:", errorText);
            throw new Error("Failed to fetch data from ChatBotMiddleware");
          }
          const data = await response.json();
          const botMessages = Array.isArray(data) ? data : [data];

          botMessages.forEach((msg) => {
            // Use user object for grammar checker, bot object otherwise
            const isGrammarChecker = msg.isGrammarChecker;
            const messageUser = isGrammarChecker
              ? { _id: 1 }
              : {
                  _id: 2,
                  name: "Aispeak",
                  avatar:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarImages[this.props.avatarKey]
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarImages[this.props.avatarKey2]
                      : this.props.avatarImages[this.props.avatarKey3],
                  avatarKey:
                    this.props.selectedOption === "Principiante"
                      ? this.props.avatarKey
                      : this.props.selectedOption === "Intermedio"
                      ? this.props.avatarKey2
                      : this.props.avatarKey3,
                };

            const messageObject = {
              _id: Math.round(Math.random() * 1000000),
              text: msg.text,
              createdAt: new Date(),
              user: messageUser,
              chatKey: this.props.chatKey,
              showSoundIcon: msg.showSoundIcon,
              isGrammarChecker: msg.isGrammarChecker,
            };

            this.saveMessagestoDB(messageObject);


            this.setState(
              (prevState_) => ({
                messages: GiftedChat.append(
                  prevState_.messages.filter(
                    (msg) => msg._id !== "typing-indicator"
                  ),
                  [messageObject]
                ),
              }),
              () => {
                this.setState({ loading: false, isLoading: false }, () =>
                  this.saveMessages()
                );
              }
            );
          });

          if (botMessages[0] && botMessages[0].userMessageCorrect) {
            this.handleCorrectAnswer();
          }

          if (botMessages[0] && botMessages[0].userMessageCorrect) {
            this.setState(
              (prevState) => {
                const messages = [...prevState.messages];
                let latestUserMsgIdx = -1;
                for (let i = 0; i < messages.length; i++) {
                  if (messages[i].user && messages[i].user._id === 1) {
                    latestUserMsgIdx = i;
                    break;
                  }
                }
                // Remove tick from all, set only on latest
                for (let i = 0; i < messages.length; i++) {
                  if (i === latestUserMsgIdx) {
                    messages[i].showGreenTick = true;
                  } else if (messages[i].showGreenTick) {
                    delete messages[i].showGreenTick;
                  }
                }
                return { messages };
              },
              () => {
                setTimeout(() => {
                  this.setState(
                    (prevState) => ({
                      messages: prevState.messages.map((msg) => {
                        if (msg.showGreenTick) {
                          const { showGreenTick, ...rest } = msg;
                          return rest;
                        }
                        return msg;
                      }),
                    }),
                    () => {
                      this.saveMessages();
                    }
                  );
                }, 2400);
              }
            );
          }
        } catch (error) {
          console.error("Error with AI call:", error);
          this.setState({ loading: false, isLoading: false });
        }
      }
    );
  }

  render() {
    // console.log("showCelebration:", this.state.showCelebration);

    const { modalVisible } = this.props;

    return (
      <SafeAreaView
        style={{ flex: 1, backgroundColor: yellow, position: "relative" }}
      >
        <ChatIntroScreen visible={modalVisible} onClose={this.closeModal} />
        <View style={{ height: 80 }}>
          <ChatHeader style={{ zIndex: 0 }} setPage={this.props.setPage} />
        </View>

        <ChatBody
          messages={this.state.messages}
          loading={this.state.loading}
          isDialogVisible={this.state.isDialogVisible}
          onOpenDialog={this.onOpenDialog}
          translatedText={this.state.translatedText}
          avatarImagePath={this.state.avatarImagePath}
          showPopupnewer2={this.state.showPopupnewer2}
          handleClosePopup2={this.handleClosePopup2}
          playSound={this.playSound}
          translateText={this.translateText.bind(this)}
          onSend={(messages) => this.onSend(messages)}
          user={{ _id: 1 }}
          onIsInputFocused={this.handleIsInputFocused}
          isRecording={this.state.isRecording}
          newMessage={this.state.newMessage}
          isInputFocused={this.state.isInputFocused}
          onIsLoading={this.state.isLoading}
          onStopLoading={this.state.stopLoading}
          thirdchat={this.state.thirdchat}
          isTimeoutActive={this.state.isTimeoutActive}
          handleStartRecording={this.startRecording}
          handleStopRecording={this.stopRecording}
          handleCancelRecording={this.cancelRecording}
          handleOnSend={this.onSend}
          onHandleMessageChange={this.handleMessageChange}
          setMicEnabled2={this.props.setMicEnabled2}
          onHandleQuestionMarkClick2={this.handleQuestionMarkClick2}
          onHandleOnLongPress={this.handleOnLongPress}
          correctAnswers={this.state.correctAnswers}
          showCelebration={this.state.showCelebration}
          handleCorrectAnswer={this.handleCorrectAnswer}
          closeCelebration={this.closeCelebration}
          playRecordedAudio={this.playRecordedAudio}
          pauseRecordedAudio={this.pauseRecordedAudio}
          seekAudio={this.seekAudio}
          currentlyPlayingAudioId={this.state.currentlyPlayingAudioId}
          playbackPositionMillis={this.state.playbackPositionMillis}
          formatTime={formatTime}
        />
        <TranslationPopup
          visible={this.state.isDialogVisible}
          title={this.state.translatedText}
          avatarImage={this.state.avatarImagePath}
          buttonLabel="Volver"
          onDialogClose={() =>
            this.setState({ isDialogVisible: false, translatedText: null })
          }
        />
        {this.state.showCelebration && (
          <CelebrationPopup
            visible={this.state.showCelebration}
            onClose={this.closeCelebration}
          />
        )}
      </SafeAreaView>
    );
  }
}
export default ChatScreen;
