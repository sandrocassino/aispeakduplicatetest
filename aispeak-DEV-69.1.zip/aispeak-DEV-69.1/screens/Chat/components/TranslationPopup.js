import { Component } from "react";
import "react-native-url-polyfill/auto";
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  Platform,
} from "react-native";
import { Animated } from "react-native";
import "react-native-gesture-handler";
import { light, dark, darkGray, lightGray, blue } from "../../../constants";

class TranslationPopup extends Component {
  animatedOpacity = new Animated.Value(0);

  componentDidUpdate(prevProps) {
    if (this.props.visible !== prevProps.visible) {
      Animated.timing(this.animatedOpacity, {
        toValue: this.props.visible ? 1 : 0,
        duration: 100,
        useNativeDriver: true,
      }).start();
    }
  }

  render() {
    const { visible, isLoading } =
      this.props;

    return (
      <Animated.View
        style={{
          position: "absolute",
          zIndex: 9999,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          justifyContent: "center",
          alignItems: "center",
          top: 0, 
          bottom: 0, 
          left: 0, 
          right: 0,
          opacity: this.animatedOpacity,
          pointerEvents: visible ? "auto" : "none",
        }}
      >
        <View
          style={{
            overflow: "visible",
            backgroundColor: light,
            paddingVertical: 57,
            paddingHorizontal: 27,
            height: 'auto',
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 24,
            marginHorizontal: 16,
            width: "90%",
            maxWidth: 400,
            ...Platform.select({
              ios: {
                shadowColor: dark,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
              },
              android: {
                elevation: 5,
              },
            }),
          }}
        >
          <Text
            style={{
              color: darkGray,
              textAlign: "center",
              fontSize: 16,
              fontStyle: "normal",
              fontWeight: 700,
              lineHeight: 24,
            }}
          >
            translation:
          </Text>

          {!this.props.title && !isLoading ? 
          (
             <Image
              source={require("../../../assets/images/loading-circle.gif")}
              style={{
                width: 100,
                height: 100,
              }}
            />
          ) : (
            <View
              style={{
                overflow: "visible",
                flexDirection: "row",
                marginTop: 20,
                marginBottom: 20,
                marginLeft: 20,
                marginRight: 20,
              }}
            >
              <ScrollView
                style={{
                  maxHeight: 'auto',
                  flex: 1,
                }}
              >
                <View
                  style={{
                    overflow: "visible",
                    alignSelf: "stretch",
                    backgroundColor: light,
                  }}
                >
                  <Text
                    style={{
                      color: dark,
                      fontSize: 16,
                      textAlign: "center",
                      fontWeight: 700,
                      fontStyle: "normal",
                      lineHeight: 24,
                    }}
                  >
                    {this.props.title}
                  </Text>
                </View>
              </ScrollView>
            </View>
          ) }
        

          <TouchableOpacity
            onPress={this.props.onDialogClose}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: 302,
              maxWidth: 358,
              minWidth: 200,
              paddingVertical: 12,
              paddingHorizontal: 16,
              gap: 4,
              marginTop: 38,
              borderRadius: 24,
              backgroundColor: blue,
              ...Platform.select({
                ios: {
                  shadowColor: dark,
                  shadowOffset: { width: 0, height: 3 },
                  shadowOpacity: 0.25,
                  shadowRadius: 10,
                },
                android: {
                  elevation: 5,
                },
              }),
            }}
          >
            <Text
              style={{
                color: lightGray,
                fontSize: 16,
                textAlign: "center",
                fontStyle: "normal",
                fontWeight: 700,
                lineHeight: 20,
              }}
            >
              {this.props.buttonLabel}
            </Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    );
  }
}

export default TranslationPopup;
