import {
  Platform,
  View,
  Dimensions,
  Animated,
  TouchableOpacity,
  Image,
} from "react-native";
import { useState, useEffect } from "react";
import ToolbarSendButton from "./ToolbarSendButton";
import ToolbarMicButton from "./ToolbarMicButton";
import ToolbarTextInput from "./ToolbarTextInput";
import { blue, lightBlue, lightGray } from "../../../constants.js";

export default function ChatInputToolbar({
  isRecording,
  newMessage,
  onIsInputFocused,
  handleStopRecording,
  handleCancelRecording,
  onHandleMessageChange,
  handleOnSend,
  isInputFocused,
  onHandleOnLongPress,
  onHandleQuestionMarkClick2,
  keyboardVisible,
  thirdchat,
  isTimeoutActive,
}) {
  const hasText = newMessage && newMessage.length > 0;
  const screenWidth = Dimensions.get("window").width;

  // Base styles that are reused
  const baseStyle = {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 30,
    marginBottom: 30,
    marginHorizontal: 16,
  };

  const inputStyle = {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    width: screenWidth * 0.9,
    borderRadius: 48,
    paddingTop: 8,
    paddingRight: 8,
    paddingBottom: 8,
    paddingLeft: 16,
    backgroundColor: isInputFocused ? lightBlue : lightGray,
    borderTopColor: isInputFocused ? blue : lightGray,
  };

  // Recording state toolbar
  if (isRecording) {
    return (
      <View style={baseStyle}>
        <View style={inputStyle}>
          {/* Trash Button */}
          <TouchableOpacity
            onPress={() => {
              if (isTimeoutActive) {
                onHandleQuestionMarkClick2();
              } else {
                handleCancelRecording();
              }
            }}
            style={{
              backgroundColor: blue,
              padding: 8,
              borderRadius: 100,
            }}
          >
            <TrashIcon />
          </TouchableOpacity>

          {/* Audio Wave Visualization */}
          <View
            style={{
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <AnimatedAudioWave />
          </View>

          {/* Send/Stop Recording Button */}
          {/* <ToolbarSendButton
            isInputFocused={isInputFocused}
            newMessage={newMessage}
            isTimeoutActive={isTimeoutActive}
            handleOnSend={handleStopRecording} // Using handleStopRecording instead of handleOnSend
            onHandleQuestionMarkClick2={onHandleQuestionMarkClick2}
            thirdchat={thirdchat}
          /> */}
          {/* Send Button */}
          <TouchableOpacity
            onPress={() => {
              if (isTimeoutActive) {
                onHandleQuestionMarkClick2();
              } else {
                handleStopRecording();
              }
            }}
            style={{
              backgroundColor: blue,
              padding: 8,
              borderRadius: 100,
            }}
          >
            <Image
              source={require("assets/icons/white-arrow-up-no-bg.png")}
              style={{ width: 24, height: 24 }}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // Default state (not recording) - Original toolbar
  return (
    <View style={baseStyle}>
      <View style={inputStyle}>
        <ToolbarTextInput
          isRecording={isRecording}
          newMessage={newMessage}
          onHandleMessageChange={onHandleMessageChange}
          onIsInputFocused={onIsInputFocused}
        />

        {hasText ? (
          <ToolbarSendButton
            newMessage={newMessage}
            isTimeoutActive={isTimeoutActive}
            handleOnSend={handleOnSend}
            onHandleQuestionMarkClick2={onHandleQuestionMarkClick2}
            thirdchat={thirdchat}
          />
        ) : (
          <ToolbarMicButton
            onHandleOnLongPress={onHandleOnLongPress}
            handleStopRecording={handleStopRecording}
          />
        )}
      </View>
    </View>
  );
}

// Animated audio wave component
const AnimatedAudioWave = () => {
  const animatedValues = useState(() =>
    Array.from({ length: 20 }, () => new Animated.Value(0.4))
  )[0];

  useEffect(() => {
    const animations = {
      quiet: [0.6, 0.4, 0.8],
      normal: [1, 0.4, 0.6],
      loud: [1, 0.4, 1.2],
    };

    const barPatterns = [
      "quiet",
      "normal",
      "loud",
      "quiet",
      "normal",
      "loud",
      "quiet",
      "loud",
      "normal",
      "quiet",
      "normal",
      "loud",
      "quiet",
      "normal",
      "loud",
      "quiet",
      "normal",
      "quiet",
      "loud",
      "normal",
    ];

    const createAnimation = (animatedValue, pattern) => {
      const keyframes = animations[pattern];

      return Animated.loop(
        Animated.sequence([
          Animated.timing(animatedValue, {
            toValue: keyframes[0],
            duration: 300,
            useNativeDriver: false,
          }),
          Animated.timing(animatedValue, {
            toValue: keyframes[1],
            duration: 300,
            useNativeDriver: false,
          }),
          Animated.timing(animatedValue, {
            toValue: keyframes[2],
            duration: 300,
            useNativeDriver: false,
          }),
          Animated.timing(animatedValue, {
            toValue: 0.4,
            duration: 300,
            useNativeDriver: false,
          }),
        ])
      );
    };

    const runningAnimations = animatedValues.map((animatedValue, index) => {
      const pattern = barPatterns[index];
      return createAnimation(animatedValue, pattern);
    });

    runningAnimations.forEach((animation) => animation.start());

    return () => {
      runningAnimations.forEach((animation) => animation.stop());
    };
  }, []);

  return (
    <View style={styles.waveContainer}>
      {animatedValues.map((animatedValue, index) => (
        <Animated.View
          key={index}
          style={[
            styles.waveBar,
            {
              transform: [{ scaleY: animatedValue }],
            },
          ]}
        />
      ))}
    </View>
  );
};

// Styles for the wave animation
const styles = {
  waveContainer: {
    width: "100%",
    height: 24,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  waveBar: {
    width: 3,
    height: 24,
    backgroundColor: blue,
    marginHorizontal: 2,
    borderRadius: 2,
    transformOrigin: "center",
  },
};

const TrashIcon = () => (
  <Image
    source={require("assets/icons/trash.png")}
    style={{
      width: 24,
      height: 24,
      resizeMode: "contain",
    }}
  />
);
