import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import {
  green,
  sourceSans,
  darkGray,
  sourceSansBold,
  dark,
} from "../../../constants.js";

export default function GrammarAccordion({ correction = "" }) {
  const [open, setOpen] = useState(false);

  // delete "Tu texto no es correcto ingles."
  const filteredCorrection = correction
    .split("Tu texto no es correcto ingles.")
    .join("")
    .trim();

  const correctionWords = filteredCorrection
    ? filteredCorrection.split(" ")
    : [];
  //function to change string between " " in green
  const parseCorrection = (words) => {
    const segments = [];
    let inQuotes = false;
    let buffer = [];

    for (let i = 0; i < words.length; i++) {
      let word = words[i];

      if (!inQuotes) {
        if (word.startsWith('"')) {
          inQuotes = true;
          word = word.slice(1);
          if (word.endsWith('"')) {
            word = word.slice(0, -1);
            segments.push({ text: word, highlighted: true });
            inQuotes = false;
          } else {
            buffer.push(word);
          }
        } else {
          segments.push({ text: word, highlighted: false });
        }
      } else {
        if (word.endsWith('"')) {
          buffer.push(word.slice(0, -1));
          segments.push({ text: buffer.join(" "), highlighted: true });
          buffer = [];
          inQuotes = false;
        } else {
          buffer.push(word);
        }
      }
    }

    if (buffer.length > 0) {
      segments.push({ text: buffer.join(" "), highlighted: true });
    }

    return segments;
  };

  const segments = parseCorrection(correctionWords);
  const previewWords = correctionWords.slice(0, 4);
  const preview =
    previewWords.join(" ") + (correctionWords.length > 4 ? " ..." : ""); // accordion stop at 4

  const renderCorrectionText = () => (
    <Text style={styles.correctionText}>
      {segments.map(({ text, highlighted }, i) => (
        <Text
          key={i}
          style={highlighted ? styles.highlight : styles.normalText}
        >
          {text + " "}
        </Text>
      ))}
    </Text>
  );

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => setOpen(!open)} style={styles.header}>
        {open ? (
          renderCorrectionText()
        ) : (
          <Text style={styles.correctionText}>{preview}</Text>
        )}
        <View style={[styles.arrow, open ? styles.up : styles.down]} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    fontFamily: sourceSans,
    marginTop: -8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: darkGray,
    borderStyle: "dashed",
    borderRadius: 20,
    height: "auto",
    minWidth: 300,
    Width: 324,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  correctionText: {
    fontSize: 16,
    color: dark,
    flexWrap: "wrap",
    flex: 1,
  },
  highlight: {
    color: green,
    fontFamily: sourceSansBold,
    fontWeight: "bold",
  },
  normalText: {
    color: dark,
  },
  arrow: {
    width: 12,
    height: 12,
    borderLeftWidth: 2,
    borderBottomWidth: 2,
    borderColor: dark,
  },
  down: {
    transform: [{ rotate: "-47deg" }],
  },
  up: {
    transform: [{ rotate: "135deg" }],
  },
});
