import React, { useEffect, useRef, useState } from "react";
import { Bubble } from "react-native-gifted-chat";
import {
  View,
  TouchableOpacity,
  Image,
  Keyboard,
  Pressable,
  StyleSheet,
  Platform,
  Animated,
  Text,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import SoundIcon from "../../../SoundIcon.js";
import AudioMessageBubble from "./AudioMessageBubble";
import {
  light,
  blue,
  lightBlue,
  veryLightBlue,
  dark,
  darkGray,
  SourceSans,
} from "../../../constants.js";

const ChatBubble = (props) => {
  const {
    currentMessage,
    customMessage,
    nextMessage,
    playSound,
    handlePress,
    translateText,
    previousMessage,
    playRecordedAudio,
    pauseRecordedAudio,
    seekAudio,
    currentlyPlayingAudioId,
    playbackPositionMillis,
    formatTime,
    isPaused,
  } = props;

  const messageToTranslate = currentMessage ? currentMessage.text : "";

  const isSameUser = (m1, m2) => m1 && m2 && m1.user?._id === m2.user?._id;

  const isOnlyMessage =
    !isSameUser(currentMessage, previousMessage) &&
    !isSameUser(currentMessage, nextMessage);

  const isFirstMessage =
    !isSameUser(currentMessage, previousMessage) &&
    isSameUser(currentMessage, nextMessage);

  const isSecondMessage =
    isSameUser(currentMessage, previousMessage) &&
    !isSameUser(currentMessage, nextMessage);

  let customStyle = {};

  // Prioritize mutually exclusive conditions
  if (isOnlyMessage) {
    customStyle = {
      borderTopLeftRadius: 0,
      borderTopRightRadius: 24,
      borderBottomRightRadius: 24,
      borderBottomLeftRadius: 24,
    };
  } else if (isFirstMessage) {
    customStyle = {
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      borderBottomRightRadius: 24,
      borderBottomLeftRadius: 0,
    };
  } else if (isSecondMessage) {
    customStyle = {
      borderTopLeftRadius: 0,
      borderTopRightRadius: 24,
      borderBottomRightRadius: 24,
      borderBottomLeftRadius: 24,
    };
  }

  // Fade out animation for green tick
  const [showTick, setShowTick] = useState(customMessage.showGreenTick);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (customMessage.showGreenTick) {
      setShowTick(true);
      fadeAnim.setValue(1);
      // Start fade out after 2 seconds
      const timer = setTimeout(() => {
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 400,
          useNativeDriver: true,
        }).start(() => setShowTick(false));
      }, 2000);
      return () => clearTimeout(timer);
    } else {
      setShowTick(false);
      fadeAnim.setValue(1);
    }
  }, [customMessage.showGreenTick]);

  // Only render the tick if both are true to avoid blinking
  const shouldShowTick = customMessage.showGreenTick && showTick;

  // --- TYPING INDICATOR BUBBLE (GIF) ---
  if (currentMessage.isTypingIndicator && currentMessage.image) {
    return (
      <View style={styles.leftRow}>
        <View style={[styles.typingBubble, { backgroundColor: veryLightBlue }]}>
          <Image
            source={currentMessage.image}
            style={{ width: 48, height: 24 }}
            resizeMode="contain"
          />
        </View>
      </View>
    );
  }

  // --- AUDIO MESSAGE BUBBLE (now delegated to AudioMessageBubble.js) ---
  if (currentMessage.user._id === 1 && currentMessage.audio) {
    return (
      <View style={styles.rightRowFullWidth}>
        <Pressable style={{ flex: 1 }} />
        <AudioMessageBubble
          currentMessage={currentMessage}
          customMessage={customMessage}
          playRecordedAudio={playRecordedAudio}
          pauseRecordedAudio={pauseRecordedAudio}
          currentlyPlayingAudioId={currentlyPlayingAudioId}
          playbackPositionMillis={playbackPositionMillis}
          formatTime={formatTime}
          isPaused={isPaused}
        />
      </View>
    );
  }

  // Chatbot bubble (left)
  if (customMessage.user._id !== 1) {
    return (
      <View style={styles.leftRow}>
        <Bubble
          {...props}
          renderTime={() => null}
          wrapperStyle={{
            left: {
              ...customStyle,
              backgroundColor: veryLightBlue,
              alignItems: "flex-start",
              justifyContent: "flex-start",
              borderColor: customMessage.isGrammarChecker
                ? "transparent"
                : "transparent",
              borderWidth: customMessage.isGrammarChecker ? 0 : 0,
              maxWidth: "90%",
              minWidth: "80%",
              width: Platform.OS === "android" ? "auto" : "85%",
              marginBottom: 4,
            },
          }}
          textStyle={{
            left: {
              paddingHorizontal: 12,
              paddingTop: 12,
              paddingBottom:
                currentMessage?.showSoundIcon || currentMessage?.showSoundIcon2
                  ? 24
                  : 12,
              fontSize: 16,
              fontWeight: "400",
              lineHeight: 24,
              fontFamily: SourceSans,
              textAlign: "left",
            },
          }}
        />
        <View style={styles.leftIcons}>
          {(customMessage.showSoundIcon || customMessage.showSoundIcon2) && (
            <TouchableOpacity
              onPress={() => {
                Keyboard.dismiss();
                handlePress && handlePress();
                if (translateText && messageToTranslate) {
                  translateText(messageToTranslate);
                }
              }}
              style={styles.translateButton(customMessage.showSoundIcon2)}
            >
              <Image
                source={require("../../../assets/icons/translate.png")}
                style={styles.translateIcon}
              />
            </TouchableOpacity>
          )}

          {(props.currentMessage.showSoundIcon ||
            props.currentMessage.showSoundIcon2) && (
            <SoundIcon
              currentMessage={props.currentMessage}
              playSound={playSound}
            />
          )}
        </View>
        <Pressable
          onPress={() => {
            Keyboard.dismiss();
          }}
          style={styles.pressableOverlay}
        />
      </View>
    );
  } else {
    // User's text bubble (right) - make left area a touchable Pressable
    return (
      <View style={styles.rightRowFullWidth}>
        <Pressable style={{ flex: 1 }} />
        <View style={styles.rightBubbleWrapper}>
          <Bubble
            {...props}
            renderTime={() => null}
            wrapperStyle={{
              right: {
                backgroundColor: blue,
                marginVertical: 12,
                borderRadius: 24,
                borderBottomRightRadius: 0,
              },
            }}
            textStyle={{
              right: {
                color: light,
                paddingVertical: 12,
                paddingHorizontal: 12,
                fontSize: 16,
                fontWeight: "400",
                lineHeight: 24,
                fontFamily: SourceSans,
                textAlign: "left",
              },
            }}
          />
          {shouldShowTick && (
            <Animated.View style={[styles.greenTick, { opacity: fadeAnim }]}>
              <Image
                source={require("../../../assets/icons/green-checkmark-circle-no-bg.png")}
                style={styles.greenTickImage}
              />
            </Animated.View>
          )}
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  leftRow: {
    flexDirection: "row",
    flex: 1,
    maxWidth: "90%",
    marginBottom: 2,
  },
  typingBubble: {
    borderRadius: 24,
    borderTopLeftRadius: 0,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginVertical: 4,
    alignSelf: "flex-start",
    justifyContent: "center",
    alignItems: "center",
  },
  leftIcons: {
    position: "absolute",
    bottom: 27,
    zIndex: 1000,
    elevation: 1000,
  },
  translateButton: (showSoundIcon2) => ({
    width: 40,
    height: 40,
    backgroundColor: lightBlue,
    borderRadius: 50,
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    left: showSoundIcon2 ? 204 : 202,
    zIndex: 21,
  }),
  translateIcon: {
    width: 24,
    height: 24,
    color: blue,
  },
  pressableOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1,
    backgroundColor: "transparent",
  },
  rightRowFullWidth: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "flex-end",
    maxWidth: "100%",
    marginBottom: 2,
  },
  rightBubbleWrapper: {
    position: "relative",
  },
  greenTick: {
    opacity: 1,
    position: "absolute",
    left: 24,
    top: "50%",
    marginTop: -11,
    zIndex: 10,
  },
  greenTickImage: {
    width: 22,
    height: 22,
  },
});

export default ChatBubble;
