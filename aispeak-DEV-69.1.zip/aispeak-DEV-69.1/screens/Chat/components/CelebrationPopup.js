import React from "react";
import { Dimensions } from "react-native";
import ConfettiCannon from "react-native-confetti-cannon";

export default function CelebrationConfetti({ visible }) {
  const [showConfetti, setShowConfetti] = React.useState(false);
  const [confettiKey, setConfettiKey] = React.useState(0);

  React.useEffect(() => {
    if (visible) {
      setConfettiKey(prev => prev + 1);
      setShowConfetti(true);
      const timeout = setTimeout(() => setShowConfetti(false), 6000);
      return () => clearTimeout(timeout);
    }
  }, [visible]);

  if (!showConfetti) return null;

  const { width, height } = Dimensions.get("window");

  return (
    <ConfettiCannon
      key={`right-${confettiKey}`}
      count={80}
      origin={{ x: width / 2, y: 0 }}
      fallSpeed={3200}
      explosionSpeed={800}
      fadeOut
      colors={['#017CFE', '#F8F9FA']}
      style={{ position: 'absolute', pointerEvents: 'none', zIndex: 9999, left: 0, right: 0, top: 0, bottom: 0 }}
    />
  );
}

// Previous version of CelebrationPopup
// Using the Overlay of Capy on a white background with confetti

// import React from "react";
// import { Pressable, Image, Text, StyleSheet } from "react-native";
// import { light, brown } from "../../../constants";
// import ConfettiCannon from "react-native-confetti-cannon";

// export default function CelebrationPopup({ visible, onClose }) {
//   const [showConfetti, setShowConfetti] = React.useState(false);
//   const [confettiKey, setConfettiKey] = React.useState(0);

//   React.useEffect(() => {
//     if (visible) {
//       setConfettiKey(prev => prev + 1);
//       setShowConfetti(true);
//       const timeout = setTimeout(() => setShowConfetti(false), 8000);
//       return () => clearTimeout(timeout);
//     }
//   }, [visible]);

//   if (!visible) return null;

//   return (
//     <Pressable
//       onPress={onClose}
//       style={styles.overlay}
//     >
//       <Pressable
//         onPress={(e) => e.stopPropagation()}
//         style={styles.popup}
//       >
//         <Image
//           source={require("../../../assets/images/capy.png")}
//           style={styles.capyImage}
//         />
//         <Text style={styles.titleText}>
//           You're doing great!
//         </Text>
//         {showConfetti && (
//           <ConfettiCannon
//             key={`right-${confettiKey}`}
//             count={120}
//             origin={{ x: 0, y: 300 }}
//             fallSpeed={4000}
//             explosionSpeed={500}
//             fadeOut
//             colors={['#017CFE', '#FFC84A']}
//           />
//         )}
//       </Pressable>
//     </Pressable>
//   );
// }

// const styles = StyleSheet.create({
//   overlay: {
//     position: "absolute",
//     top: 0,
//     bottom: 0,
//     left: 0,
//     right: 0,
//     backgroundColor: "rgba(0,0,0,0.3)",
//     justifyContent: "center",
//     alignItems: "center",
//     zIndex: 9999,
//   },
//   popup: {
//     backgroundColor: light,
//     width: "100%",
//     height: '60%',
//     alignItems: "center",
//     justifyContent: 'center',
//   },
//   capyImage: {
//     width: 230,
//     height: 210,
//   },
//   titleText: {
//     fontSize: 20,
//     fontWeight: "700",
//     color: brown,
//     marginTop: 20,
//     textAlign: "center",
//   },
// });