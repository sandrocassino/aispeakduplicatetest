import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Image,
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { light, blue, lightBlue, SourceSans } from "../../../constants.js";

// Waveform with progress coloring
const StaticWaveform = ({
  barCount = 20,
  barColor = light,
  progressColor = dark,
  seed,
  progress = 0,
}) => {
  const bars = React.useMemo(() => {
    let x = typeof seed === "number" ? seed : 12345;
    function seededRandom() {
      x = Math.sin(x) * 10000;
      return x - Math.floor(x);
    }
    return Array.from({ length: barCount }, () => seededRandom() * 0.7 + 0.3);
  }, [barCount, seed]);

  const progressBars = Math.round(progress * barCount);

  return (
    <View style={styles.waveformRow}>
      {bars.map((scale, idx) => (
        <View
          key={idx}
          style={{
            width: 3,
            height: 24 * scale,
            backgroundColor: idx < progressBars ? progressColor : barColor,
            marginHorizontal: 2,
            borderRadius: 2,
          }}
        />
      ))}
    </View>
  );
};

const AudioMessageBubble = ({
  currentMessage,
  customMessage = currentMessage,
  playRecordedAudio,
  pauseRecordedAudio,
  currentlyPlayingAudioId,
  playbackPositionMillis,
  formatTime,
  isPaused,
}) => {
  const isThisMessage = currentlyPlayingAudioId === currentMessage._id;
  const isPlaying = !!currentMessage.isPlaying && isThisMessage;
  const totalDuration = currentMessage.durationMillis || 0;
  const currentPosition = playbackPositionMillis;
  const remaining = Math.max(totalDuration - currentPosition, 0);

  // Calculate progress ratio (0 to 1)
  const progress =
    totalDuration > 0
      ? Math.min(Math.max(currentPosition / totalDuration, 0), 1)
      : 0;

  // Green checkmark animation logic
  const [showTick, setShowTick] = useState(customMessage.showGreenTick);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  // Transcript toggle state and fade animation
  const [showTranscript, setShowTranscript] = useState(false);
  const [showTranscribing, setShowTranscribing] = useState(false);
  const transcribingFade = useRef(new Animated.Value(1)).current;
  const transcriptFade = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (customMessage.showGreenTick) {
      setShowTick(true);
      fadeAnim.setValue(1);
      const timer = setTimeout(() => {
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 400,
          useNativeDriver: true,
        }).start(() => setShowTick(false));
      }, 2000);
      return () => clearTimeout(timer);
    } else {
      setShowTick(false);
      fadeAnim.setValue(1);
    }
  }, [customMessage.showGreenTick]);

  const shouldShowTick = customMessage.showGreenTick && showTick;

  // Handle transcript reveal with "transcribiendo" step and fade animations
  useEffect(() => {
    if (showTranscribing) {
      transcribingFade.setValue(0);
      Animated.timing(transcribingFade, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();

      const timer = setTimeout(() => {
        Animated.timing(transcribingFade, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }).start(() => {
          setShowTranscribing(false);
          setShowTranscript(true);
        });
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [showTranscribing]);

  useEffect(() => {
    if (showTranscript) {
      transcriptFade.setValue(0);
      Animated.timing(transcriptFade, {
        toValue: 1,
        duration: 20,
        useNativeDriver: true,
      }).start();
    } else {
      transcriptFade.setValue(1);
    }
  }, [showTranscript]);

  return (
    <View style={styles.userAudioContainer}>
      {/* Green tick absolutely positioned just outside the bubble on the left */}
      {shouldShowTick && (
        <Animated.View
          style={{
            opacity: fadeAnim,
            position: "absolute",
            left: -30,
            top: 16,
            zIndex: 10,
          }}
        >
          <Image
            source={require("../../../assets/icons/green-checkmark-circle-no-bg.png")}
            style={{
              width: 22,
              height: 22,
            }}
          />
        </Animated.View>
      )}
      <View style={styles.audioControlsContainer}>
        <TouchableOpacity
          style={styles.playButton}
          onPress={() => {
            if (isPlaying) {
              pauseRecordedAudio && pauseRecordedAudio();
            } else {
              playRecordedAudio &&
                playRecordedAudio(currentMessage.audio, currentMessage._id);
            }
          }}
        >
          <Ionicons
            name={isPlaying ? "pause-circle" : "play-circle"}
            size={36}
            color={light}
          />
        </TouchableOpacity>
        <View style={styles.waveAndTimeRow}>
          <View style={styles.waveformContainer}>
            <StaticWaveform
              barCount={20}
              barColor={light}
              progressColor={lightBlue}
              seed={currentMessage._id}
              progress={progress}
            />
          </View>
          <Text style={styles.timeTextRight}>
            {formatTime ? formatTime(remaining) : ""}
          </Text>
        </View>
      </View>
      {currentMessage.text && currentMessage.text.trim() !== "" && (
        <>
          {!showTranscript && !showTranscribing && (
            <TouchableOpacity onPress={() => setShowTranscribing(true)}>
              <Text style={styles.transcriptionText}>Ver transcripción</Text>
            </TouchableOpacity>
          )}
          {showTranscribing && (
            <Animated.Text
              style={[styles.transcriptionText, { opacity: transcribingFade }]}
            >
              transcribiendo...
            </Animated.Text>
          )}
          {showTranscript && (
            <Animated.Text
              style={[styles.transcriptionText, { opacity: transcriptFade }]}
            >
              {currentMessage.text}
            </Animated.Text>
          )}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  userAudioContainer: {
    backgroundColor: blue,
    borderRadius: 24,
    borderBottomRightRadius: 0,
    marginVertical: 12,
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 12,
    alignSelf: "flex-end",
    minWidth: 220,
    maxWidth: "75%",
    position: "relative",
  },
  audioControlsContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  playButton: {
    marginRight: 10,
  },
  waveAndTimeRow: {
    flexDirection: "row",
    alignItems: "center",
    minWidth: 0,
  },
  waveformContainer: {
    width: 140,
    marginRight: 8,
    overflow: "hidden",
  },
  waveformRow: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    height: 24,
    paddingHorizontal: 0,
  },
  timeTextRight: {
    color: light,
    fontSize: 13,
    minWidth: 38,
    textAlign: "right",
    fontVariant: ["tabular-nums"],
    flexShrink: 0,
    flexGrow: 0,
  },
  transcriptionText: {
    color: light,
    marginTop: 8,
    fontSize: 16,
    lineHeight: 20,
    textAlign: "left",
    fontFamily: SourceSans,
  },
});

export default AudioMessageBubble;