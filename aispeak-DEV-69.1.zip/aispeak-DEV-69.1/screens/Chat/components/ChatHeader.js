import React from "react";
import { Platform, View, Image, Text, TouchableOpacity, StyleSheet } from "react-native";
import { yellow, blue, textGray, nunitoBold } from "../../../constants.js";

class Chatheader extends React.Component {
  render() {
    return (
      <View style={styles.headerContainer}>
        {/* Left: Back button */}
        <TouchableOpacity onPress={() => this.props.setPage(7)} style={styles.sideButton}>
          <View style={styles.circleButton}>
            <Image source={require("/assets/icons/arrow-left.png")} style={{ width: 24, height: 24 }} />
          </View>
        </TouchableOpacity>
        {/* Center: Avatars and title */}
        <View style={styles.centerContent}>
          <View style={styles.avatarsRow}>
            <Image
              source={require("/assets/images/capy-avatar-chat-header.png")}
              style={{ width: 36, height: 36, marginRight: -6 }}
            />
            <Image
              source={require("/assets/images/user-avatar-example-chat-header.png")}
              style={{ width: 36, height: 36, marginLeft: -6 }}
            />
          </View>
          <Text style={styles.headerTitle}>Let's be chat Buddies</Text>
        </View>
        {/* Right: (hidden) menu button for symmetry */}
        <View style={styles.sideButton} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  headerContainer: {
    flex: Platform.OS === "android" ? 0.65 : 0.25,
    backgroundColor: yellow,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 8,
    marginVertical: 8,
    padding: 8,
    height: 80,
    position: "relative",
  },
  sideButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 2,
  },
  circleButton: {
    width: 40,
    height: 40,
    backgroundColor: blue,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    padding: 8,
  },
  centerContent: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 8,
    bottom: 8,
    alignItems: "center",
    justifyContent: "center",
    height: 64,
    width: "100%",
    marginLeft: "auto",
    marginRight: "auto",
    zIndex: 1,
  },
  avatarsRow: {
    flexDirection: "row",
    marginBottom: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: Platform.OS === "ios" ? 14 : 16,
    lineHeight: 20,
    fontFamily: nunitoBold,
    color: textGray,
    textAlign: "center",
  },
});

export default Chatheader;