import { TouchableOpacity, Image, View } from "react-native";
import * as Haptics from "expo-haptics";
import { blue } from "../../../constants";

export default function ToolbarMicButton({
  onIsLoading,
  onStopLoading,
  onHandleOnLongPress,
  handleStopRecording,
}) {
  return (
    <View>
      <TouchableOpacity
        onPress={() => {
          console.log("Starting recording");
          onHandleOnLongPress();
        }}
        style={{
          backgroundColor: blue,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding: 8,
          borderRadius: 100,
        }}
      >
        <Image
          key={`${onIsLoading}-${onStopLoading}`}
          source={
            onIsLoading && !onStopLoading
              ? require("/assets/images/3-blue-dots.gif")
              : require("/assets/icons/white-mic-no-bg.png")
          }
          style={{
            width: 24,
            height: 24,
            zIndex: 10,
            resizeMode: "contain",
            zIndex: 10,
          }}
        />
      </TouchableOpacity>
    </View>
  );
}
