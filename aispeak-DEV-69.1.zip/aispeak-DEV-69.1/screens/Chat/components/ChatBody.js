import React from "react";
import {
  View,
  Text,
  ActivityIndicator,
  TouchableOpacity,
  Image,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
} from "react-native";
import { GiftedChat } from "react-native-gifted-chat";
import { BlurView } from "expo-blur";
import styles from "../../../Styles";
import ChatBubble from "./ChatBubble";
import GrammarAccordion from "./Accordion";
import ChatInputToolbar from "./ChatInputToolbar";
import { light, dark, darkBlue } from "../../../constants";

const screenHeight = require("react-native").Dimensions.get("window").height;

class ChatBody extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      messages: [],
      keyboardVisible: false,
      keyboardHeight: 0, //Set keyboard height for dynamic use
    };
  }

  // onPress function to set 'isDialogVisible' state to true
  handlePress = () => {
    this.props.onOpenDialog(true);
  };

  //Mounting and unmounting keyboard logic
  componentDidMount() {
    this.keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        this.setState({ keyboardVisible: false });
      }
    );

    this.keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        this.setState({ keyboardVisible: true });
      }
    );
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
    Keyboard.dismiss(); //To dismiss keyboard when implicitly closed
  }

  _keyboardDidShow = (event) => {
    this.setState({ keyboardHeight: event.endCoordinates.height });
  };

  _keyboardDidHide = () => {
    this.setState({ keyboardHeight: 0 });
  };

  render() {
    const {
      messages,
      loading,
      showPopupnewer2,
      handleClosePopup2,
      onSend,
      renderBubble,
      user,
      correctAnswers,
      showCelebration,
      closeCelebration,
      handleCorrectAnswer,
      showSoundIcon,
      showSoundIcon2,
      keyboardVisible,
      onIsInputFocused,
      // --- Audio playback props (added for audio slider support) ---
      playRecordedAudio,
      pauseRecordedAudio,
      seekAudio,
      currentlyPlayingAudioId,
      playbackPositionMillis,
      formatTime,
      isPaused, // <-- Make sure this is received from props
    } = this.props;

    const renderBubbleFn =
      renderBubble ||
      ((props) => {
        const { playSound, translateText } = this.props;

        const customMessage = props.currentMessage;

        if (customMessage.isGrammarChecker) {
          // change accordion from bubble when grammar issue
          return <GrammarAccordion correction={customMessage.text} />;
        }

        return (
          <ChatBubble
            {...props}
            customMessage={customMessage}
            playSound={playSound}
            handlePress={this.handlePress}
            translateText={translateText}
            showSoundIcon={showSoundIcon}
            showSoundIcon2={showSoundIcon2}
            playRecordedAudio={playRecordedAudio}
            pauseRecordedAudio={pauseRecordedAudio}
            seekAudio={seekAudio}
            currentlyPlayingAudioId={currentlyPlayingAudioId}
            playbackPositionMillis={playbackPositionMillis}
            formatTime={formatTime}
            isPaused={isPaused}
          />
        );
      });

    return (
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 50} // To avoid tap the ChatToolbar when user opens keyboard
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
          <View style={{ flex: 1 }}>
            <GiftedChat
              messages={messages}
              onSend={onSend}
              user={user || { _id: 1 }}
              renderInputToolbar={(props) => (
                <ChatInputToolbar
                  {...props}
                  keyboardVisible={this.state.keyboardVisible}
                  isInputFocused={this.props.isInputFocused}
                  onIsInputFocused={this.props.onIsInputFocused}
                  {...this.props}
                />
              )}
              renderBubble={renderBubbleFn}
              renderAvatarOnTop={true}
              bottomOffset={Platform.OS === "ios" ? 300 : 0}
              scrollToBottom={true}
              keyboardShouldPersistTaps="handled"
              extraData={{
                playbackPositionMillis: this.props.playbackPositionMillis,
                currentlyPlayingAudioId: this.props.currentlyPlayingAudioId,
                tick: Date.now(),
              }}
            />
            {showPopupnewer2 && (
              <BlurView
                style={styles.blurView}
                blurType="light"
                blurAmount={10}
              >
                <View
                  style={{
                    position: "absolute",
                    top: 310,
                    zIndex: 2000,
                    left: 50,
                    right: 50,
                    justifyContent: "center",
                    alignItems: "center",
                    borderColor: darkBlue,
                    borderWidth: 1,
                    backgroundColor: light,
                    padding: 25,
                    borderRadius: 10,
                    ...Platform.select({
                      ios: {
                        shadowColor: dark,
                        shadowOffset: { width: 0, height: 4 },
                        shadowOpacity: 0.25,
                        shadowRadius: 4,
                      },
                      android: {
                        elevation: 5,
                      },
                    }),
                  }}
                >
                  <Text
                    style={{ fontSize: 18, color: dark, textAlign: "center" }}
                  >
                    ¡Tienes que esperar un poco más hasta que puedas chatear de
                    nuevo! Has alcanzado el límite de 3 chats para hoy.
                    {"\n\n"}
                    ¡Cuando hayan pasado las 12 horas completas, podrás volver a
                    chatear con Aispeak!
                  </Text>
                  <Image
                    source={require("../../../assets/images/timeout-clock.png")}
                    style={{
                      position: "absolute",
                      top: -35,
                      left: 20,
                      width: 60,
                      height: 60,
                      resizeMode: "contain",
                    }}
                  />
                  <TouchableOpacity
                    onPress={handleClosePopup2}
                    style={{
                      position: "absolute",
                      top: 10,
                      right: 10,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 20,
                        color: darkBlue,
                        fontWeight: "bold",
                      }}
                    >
                      X
                    </Text>
                  </TouchableOpacity>
                </View>
              </BlurView>
            )}
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    );
  }
}

export default ChatBody;
