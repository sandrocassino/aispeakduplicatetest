import React from "react";
import { View, Image, Text, TouchableOpacity, Modal, Dimensions } from "react-native";
import { light, yellow, dark } from "constants.js";

const screenHeight = Dimensions.get("window").height;

const ChatIntroScreen = ({ visible, onClose }) => (
  <Modal
    transparent={true}
    visible={visible}
    onRequestClose={onClose}
    statusBarTranslucent={true}
  >
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0,0,0,0.5)",
      }}
    >
      <View
        style={{
          backgroundColor: light,
          padding: 20,
          borderRadius: 10,
          width: "90%",
          height: screenHeight <= 667 ? "80%" : "60%",
          justifyContent: "space-between",
          borderColor: yellow,
          borderWidth: 16,
        }}
      >
        <View style={{ alignItems: "center" }}>
          <Image
            source={require("../../../assets/icons/black-circle-no-bg.png")}
            style={{
              width: 20,
              height: 20,
              position: "absolute",
              top: 165,
              left: 10,
            }}
          />
          <Image
            source={require("../../../assets/icons/black-circle-no-bg.png")}
            style={{
              width: 20,
              height: 20,
              position: "absolute",
              top: 250,
              left: 10,
            }}
          />
          <Image
            source={require("../../../assets/icons/black-circle-no-bg.png")}
            style={{
              width: 20,
              height: 20,
              position: "absolute",
              top: 80,
              left: 10,
            }}
          />
          <Image
            source={require("../../../assets/images/old-translate.png")}
            style={{
              width: 40,
              height: 40,
              position: "absolute",
              top: 75,
              left: 40,
            }}
          />
          <Image
            source={require("../../../assets/images/old-speaker.png")}
            style={{
              width: 40,
              height: 40,
              position: "absolute",
              top: 160,
              left: 40,
            }}
          />
          <Text
            style={{
              fontSize: 14,
              position: "absolute",
              top: 80,
              left: 90,
            }}
          >
            Haga clic en este icono{"\n"}para traducir los mensajes{"\n"}
            de Aispeak al español.
          </Text>
          <Text
            style={{
              fontSize: 14,
              position: "absolute",
              top: 165,
              left: 90,
            }}
          >
            Haga clic en este icono{"\n"}para traducir los mensajes{"\n"}
            de Aispeak al español.
          </Text>
          <Text
            style={{
              fontSize: 14,
              position: "absolute",
              top: 250,
              left: 50,
            }}
          >
            Intenta responder en ingles,{"\n"}pero si no sabes cómo
            decirlo{"\n"}siempre puedes responder{"\n"}en español! Aispeak
            siempre{"\n"}corrige tu gramática{"\n"}inglesa.
          </Text>
          <Text
            style={{
              fontSize: 22,
              fontWeight: "bold",
              textAlign: "center",
            }}
          >
            Introducción rápida
          </Text>
        </View>
        <TouchableOpacity
          onPress={onClose}
          style={{
            backgroundColor: yellow,
            borderRadius: 20,
            padding: 10,
            marginRight: 20,
          }}
        >
          <Text
            style={{
              color: dark,
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            Comenzar!
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  </Modal>
);

export default ChatIntroScreen;