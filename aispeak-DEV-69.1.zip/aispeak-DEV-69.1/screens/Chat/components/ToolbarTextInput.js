import { TextInput, View, Platform } from "react-native";
import { gray, red } from "../../../constants";

export default function ToolbarTextInput({
  isRecording,
  newMessage,
  onHandleMessageChange,
  onIsInputFocused,
}) {
  return (
    <View
      style={{
        display: "flex",
        justifyContent: "center",
        flex: 1,
        minHeight: 40,
      }}
    >
      <TextInput
        style={{
          flex: 1,
          fontSize: 16,
          fontWeight: "400",
          fontStyle: "normal",
          textAlignVertical: "center",
          paddingVertical: 12,
          paddingLeft: 16,
          paddingRight: 8,
          lineHeight: 20,
          // Ensure minimum height
          minHeight: 40,
        }}
        multiline={true}
        placeholder={isRecording ? "Grabando..." : "Add a message"}
        placeholderTextColor={isRecording ? red : gray}
        value={newMessage}
        onChangeText={onHandleMessageChange}
        onFocus={() => onIsInputFocused(true)}
        onBlur={() => onIsInputFocused(false)}
      />
    </View>
  );
}
