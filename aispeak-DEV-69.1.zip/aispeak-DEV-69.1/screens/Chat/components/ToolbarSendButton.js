import { View, TouchableOpacity, Image, Text } from "react-native";
import { blue } from "../../../constants.js";

const ToolbarSendButton = ({
  isInputFocused,
  newMessage,
  isTimeoutActive,
  handleOnSend,
  onHandleQuestionMarkClick2,
  thirdchat,
}) => {
  return (
    <View>
      <TouchableOpacity
        style={{
          backgroundColor: blue,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding: 8,
          borderRadius: 100,
        }}
        onPress={() => {
          // Prevent sending if the message is blank
          if (newMessage.trim() === "") {
            console.warn("Empty message cannot be sent.");
            return;
          }

          if (isTimeoutActive && thirdchat) {
            onHandleQuestionMarkClick2();
          } else {
            handleOnSend([{ text: newMessage }]);
          }
        }}
      >
        <Image
          source={require("assets/icons/white-arrow-up-no-bg.png")}
          style={{ width: 24, height: 24 }}
        />
      </TouchableOpacity>
    </View>
  );
};

export default ToolbarSendButton;
