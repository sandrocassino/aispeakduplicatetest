import React from "react";
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Linking,
} from "react-native";
import { nunito, nunitoBold, light, blue } from "../../../constants";

export default function OnboardingMenu({
  onNext,
  ctaText = "Activate free trial >",
  showMainButton = true,
  showSecondaryButton = false,
  secondaryButtonText = "Saltar por ahora >",
  onPrimaryAction,
  onSecondaryAction
}) {
  const handleTermsPress = () => {
    Linking.openURL("https://www.aispeakapp.com/legal/terminos-condiciones");
  };

  const handlePrivacyPress = () => {
    Linking.openURL("https://www.aispeakapp.com/legal/politica-privacidad");
  };

  const handleClick = () => {
  if (typeof onPrimaryAction === 'function') {
    onPrimaryAction();
  } else if (typeof onNext === 'function') {
    onNext();
  } else {
    console.warn('No action defined for this button');
  }

  };

  const noButtons = !showMainButton && !showSecondaryButton;

  return (
    <View style={styles.bottomContainer}>
      {showMainButton && (
      <TouchableOpacity style={styles.ctaButton} onPress={handleClick}>
        <Text style={styles.ctaText}>{ctaText}</Text>
      </TouchableOpacity>
      )}
      {showSecondaryButton ? (
        <TouchableOpacity style={styles.secondaryButton}           
        onPress={typeof onSecondaryAction === 'function' ? onSecondaryAction : onNext}
        >
          <Text style={styles.skipText}>{secondaryButtonText}</Text>
        </TouchableOpacity>
      ) : (
        !noButtons && <View style={{ marginBottom: 52 }} />
      )}
      {noButtons && <View style={{ marginBottom: 12 }} />}
      <View style={styles.legalRow}>
        <Text style={styles.legalText} onPress={handleTermsPress}>
          Términos y Condiciones
        </Text>
        <Text style={styles.legalDot}>•</Text>
        <Text style={styles.legalText} onPress={handlePrivacyPress}>
          Política de Privacidad
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bottomContainer: {
    paddingHorizontal: 24,
    backgroundColor: "transparent",
  },
  ctaButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: "center",
    height: 48,
    marginBottom: 20,
  },
  ctaText: {
    color: light,
    fontSize: 16,
    lineHeight: 20,
    fontFamily: nunitoBold,
  },
  secondaryButton: {
    alignItems: "center",
    marginBottom: 28,
  },
  skipText: {
    color: light,
    fontSize: 16,
    lineHeight: 24,
    fontFamily: nunitoBold,
  },
  legalRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  legalText: {
    color: light,
    fontSize: 16,
    fontFamily: nunito,
  },
  legalDot: {
    color: light,
    fontSize: 16,
    marginHorizontal: 8,
  },
});
