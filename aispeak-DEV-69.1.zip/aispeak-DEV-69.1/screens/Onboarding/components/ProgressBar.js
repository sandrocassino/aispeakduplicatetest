import React from "react";
import { View, StyleSheet } from "react-native";
import { light, blue } from "../../../constants";

export default function ProgressBar({ progress }) {
  // progress: number between 0 and 1
  return (
    <View style={styles.background}>
      <View style={[styles.fill, { width: `${progress * 100}%` }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    height: 6,
    backgroundColor: light,
    marginHorizontal: 24,
    borderRadius: 3,
    marginBottom: 16,
    marginTop: 8,
    overflow: "hidden",
  },
  fill: {
    height: "100%",
    backgroundColor: blue,
    borderRadius: 3,
  },
});