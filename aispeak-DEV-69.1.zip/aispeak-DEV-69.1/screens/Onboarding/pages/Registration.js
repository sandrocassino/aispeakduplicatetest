import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
} from "react-native";
import ProgressBar from "../components/ProgressBar";
import OnboardingMenu from "../components/OnboardingMenu";
import {
  nunitoBlack,
  nunito,
  brown,
  yellow,
  light,
  blue,
  lightBlue,
  darkGray,
  dark,
  textGray,
  inputRed,
} from "../../../constants";
import { useInputStyles } from "../../../hooks/useInputStyles";
import TermsAndConditions from "../../../components/TermsAndCondition";

const capybaraAvatar = require("../../../assets/images/capy.png");

export default function Registration({
  onNext,
  email,
  setEmail,
  password,
  setPassword,
  progress = 3 / 6,
  emailError,
  setEmailError,
  validateEmail,
  passwordError,
  setPasswordError,
  onPrimaryAction,
  setPage,
  setPreviousPage,
  currentPage,
  setLoginFlowSource,
  setIsLoggedIn,
}) {
  const [activeField, setActiveField] = useState(null);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [termsError, setTermsError] = useState("");

  const { getInputStyle, getIconColor } = useInputStyles({
    activeField,
    emailError,
    passwordError,
    styles,
  });

  //Clear text input fields when mount Registration page
  useEffect(() => {
    setEmail("");
    setPassword("");
  }, []);

  const passwordInputRef = useRef();

  const handleSubmit = () => {
    passwordInputRef.current?.blur();

    //Reset email and password input errors
    setEmailError("");
    setPasswordError("");

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError("Por favor, introduce un correo electrónico válido.");
      return;
    } else if (!emailRegex.test(email)) {
      setEmailError("Introduce un correo electrónico válido.");
      return;
    }

    // Validate password
    if (!password) {
      setPasswordError("Por favor, introduce una contraseña válida.");
      return;
    } else if (password.length < 6) {
      setPasswordError("La contraseña debe tener al menos 6 caracteres.");
      return;
    }

    // Check Terms and conditions checkbox
    if (!acceptTerms) {
      setTermsError("Debes aceptar los Términos y Condiciones para continuar");
      return;
    }

    setIsLoggedIn(false);

    // If validation passes, call the prop callback to proceed
    if (typeof onPrimaryAction === "function") {
      onPrimaryAction();
    } else if (typeof onNext === "function") {
      onNext();
    } else {
      console.warn("No action defined for this button");
    }
  };

  const goToLoginPage = () => {
    setLoginFlowSource("onboarding");
    setEmailError("");
    setPasswordError("");
    setEmail("");
    setPage(124);
    setPreviousPage({
      page: currentPage - 1,
      onboardingStep: currentPage,
      source: "onboarding",
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Progress bar */}
        <ProgressBar progress={progress} />

        {/* Capybara illustration */}
        <View style={styles.avatarContainer}>
          <Image source={capybaraAvatar} style={styles.avatar} />
        </View>

        {/* Main content */}
        <View style={styles.content}>
          <Text style={styles.title}>Vamos a crear tu perfil</Text>
          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : undefined}
            style={{ width: "100%" }}
          >
            <View style={styles.inputGroup}>
              <View
                style={[
                  styles.inputWrapperYellow,
                  activeField === "email" && styles.inputWrapperActive,
                  getInputStyle("email"),
                ]}
              >
                <Image
                  source={require("../../../assets/icons/mail.png")}
                  style={[
                    styles.inputIcon,
                    { tintColor: getIconColor("email") },
                  ]}
                />
                <TextInput
                  style={[
                    styles.input,
                    emailError && styles.inputError,
                    activeField === "email" && { color: textGray },
                  ]}
                  placeholder="Correo electrónico"
                  placeholderTextColor={
                    emailError && activeField !== "email" ? inputRed : textGray
                  }
                  value={email}
                  onChangeText={validateEmail}
                  onFocus={() => {
                    setActiveField("email");
                    setEmailError("");
                  }}
                  onBlur={() => {
                    setActiveField(null);
                    validateEmail(email, true);
                  }}
                  autoCapitalize="none"
                  keyboardType="email-address"
                />
              </View>
              {emailError ? (
                <Text style={styles.errorTextUnderField}>{emailError}</Text>
              ) : null}

              <View
                style={[
                  styles.inputWrapperYellow,
                  getInputStyle("password"),
                  activeField === "password" && styles.inputWrapperActive,
                ]}
              >
                <Image
                  source={require("../../../assets/icons/lock-closed.png")}
                  style={styles.inputIcon}
                />
                <TextInput
                  ref={passwordInputRef}
                  style={[
                    styles.input,
                    passwordError && styles.newLoginInputError,
                    activeField === "password" && { color: textGray },
                  ]}
                  placeholder="Contraseña"
                  placeholderTextColor={
                    passwordError && activeField !== "password"
                      ? inputRed
                      : textGray
                  }
                  value={password}
                  onChangeText={(text) => {
                    setPassword(text);
                    setPasswordError("");
                  }}
                  onFocus={() => {
                    setActiveField("password");
                    setPasswordError("");
                  }}
                  onBlur={() => setActiveField(null)}
                  secureTextEntry={!passwordVisible}
                />
                <TouchableOpacity
                  onPress={() => setPasswordVisible((v) => !v)}
                  style={styles.eyeIcon}
                >
                  <Image
                    source={require("../../../assets/icons/gray-eye-no-bg.png")}
                    style={{ width: 22, height: 22 }}
                  />
                </TouchableOpacity>
              </View>
              {passwordError ? (
                <Text style={styles.errorTextUnderField}>{passwordError}</Text>
              ) : null}
            </View>
          </KeyboardAvoidingView>
          <TermsAndConditions
            acceptTerms={acceptTerms}
            setAcceptTerms={setAcceptTerms}
            termsError={termsError}
          />
        </View>
        {/* Bottom actions */}
        <OnboardingMenu
          onNext={onNext}
          ctaText="Crear perfil >"
          showSecondaryButton={true}
          secondaryButtonText="¿Ya tienes cuenta?"
          onPrimaryAction={handleSubmit}
          onSecondaryAction={goToLoginPage}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: yellow,
  },
  container: {
    flex: 1,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
  },
  avatarContainer: {
    alignItems: "center",
    marginTop: 24,
    marginBottom: 16,
    width: "100%",
  },
  avatar: {
    width: 144,
    height: 144,
    borderRadius: 100,
    backgroundColor: light,
    marginBottom: 8,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    zIndex: 2,
    width: "100%",
  },
  title: {
    fontSize: 32,
    color: brown,
    marginBottom: 36,
    marginTop: 8,
    fontFamily: nunitoBlack,
    textAlign: "left",
    alignSelf: "flex-start",
  },
  inputGroup: {
    width: "100%",
    marginBottom: 16,
  },
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: "transparent",
    marginBottom: 16,
    paddingHorizontal: 16,
    height: 48,
  },
  inputWrapperActive: {
    borderColor: blue,
    backgroundColor: lightBlue,
  },
  inputIcon: {
    width: 22,
    height: 22,
    marginRight: 8,
    tintColor: darkGray,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: dark,
    fontFamily: nunito,
  },
  eyeIcon: {
    padding: 4,
  },
  inputError: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 16,
    color: inputRed,
  },
  errorTextUnderField: {
    color: inputRed,
    fontSize: 16,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: -10,
  },
  checkboxBox: {
    width: 20,
    height: 20,
    backgroundColor: "white",
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
});
