import React, { useState } from "react";
import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  useWindowDimensions,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import ProgressBar from "../components/ProgressBar";
import OnboardingMenu from "../components/OnboardingMenu";
import {
  yellow,
  light,
  brown,
  blue,
  nunitoBlack,
  nunitoBold,
  sourceSans,
} from "../../../constants";
import RadioButton from "../../Subscription/components/RadioButton";
import SwitchComponent from "../../Subscription/components/SwitchComponent";
import DiscountCodePopup from "../../Subscription/components/DiscountCodePopup";
import ButtonComponent from "../../Subscription/components/ButtonComponent";

const capybaraAvatar = require("../../../assets/images/capy.png");

export default function Subscription({
  onNext,
  selectedPlan,
  selectedBillingCycle,
  setSelectedBillingCycle,
  currentPlan,
  currentBillingCycle,
  alreadySelectedPlan,
  setPage,
  handleTesterButtonPress,
  testerUsed,
  setTesterUsed,
  isTrialActive,
  setIsTrialActive,
  setCurrentPlan,
  setCurrentBillingCycle,
  setIsTimeoutActive,
  setChatCount,
  setTrialChatCount,
  setRemainingTime,
  saveToSupabase,
  inAppBuySubscription,
  setIsSubscribing,
}) {
  const { width } = useWindowDimensions();

  // Discount code popup state
  const [promoModalVisible, setPromoModalVisible] = useState(false);
  const [promoSuccess, setPromoSuccess] = useState("");

  // Handler for when a promo code is successfully applied
  const handlePromoApplied = (message) => {
    setPromoSuccess(message);
    setPromoModalVisible(false);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Progress bar */}
        <ProgressBar progress={4 / 6} />

        {/* Capybara illustration */}
        <View style={styles.avatarContainer}>
          <Image source={capybaraAvatar} style={styles.avatar} />
        </View>

        {/* Main content */}
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.contentContainer}
        >
          <View style={styles.content}>
            <Text style={styles.title}>¡Eleva tu inglés a otro nivel!</Text>
            <Text style={styles.subtitle}>Elige un plan</Text>
            <RadioButton
              selectedBillingCycle={selectedBillingCycle}
              setSelectedBillingCycle={setSelectedBillingCycle}
            />
            <SwitchComponent
              isDisabled={alreadySelectedPlan}
              isTrialActive={isTrialActive}
              onToggleTrial={(value) => {
                setIsTrialActive(value);
                if (value) {
                  alert(
                    "Activa prueba gratis\n\nPuedes cancelar la prueba gratuita antes de que terminen los 7 días. Si no la cancelas, tu suscripción se renovará automáticamente por €69,99/ año."
                  );
                }
              }}
            />
            <TouchableOpacity onPress={() => setPromoModalVisible(true)}>
              <Text style={styles.promoText}>
                ¿Tiene un código promocional?
              </Text>
            </TouchableOpacity>
            {promoSuccess ? (
              <Text style={styles.promoSuccess}>{promoSuccess}</Text>
            ) : null}
            <ButtonComponent
              selectedPlan={selectedPlan}
              selectedBillingCycle={selectedBillingCycle}
              setIsSubscribing={setIsSubscribing}
              inAppBuySubscription={inAppBuySubscription}
              setIsTimeoutActive={setIsTimeoutActive}
              setChatCount={setChatCount}
              setTrialChatCount={setTrialChatCount}
              setRemainingTime={setRemainingTime}
              saveToSupabase={saveToSupabase}
              setCurrentPlan={setCurrentPlan}
              setCurrentBillingCycle={setCurrentBillingCycle}
              setPage={setPage}
              isTrialActive={isTrialActive}
              alreadySelectedPlan={alreadySelectedPlan}
              currentPlan={currentPlan}
              currentBillingCycle={currentBillingCycle}
              isOnboarding={true}
              onNext={onNext}
            />
            <DiscountCodePopup
              visible={promoModalVisible}
              onClose={() => setPromoModalVisible(false)}
              onPromoApplied={handlePromoApplied}
              handleTesterButtonPress={handleTesterButtonPress}
              setTesterUsed={setTesterUsed}
              setPage={setPage}
              testerUsed={testerUsed}
              isOnboarding={true}
              onNext={onNext}
            />
          </View>
        </ScrollView>

        {/* Bottom actions */}
        <OnboardingMenu onNext={onNext} showMainButton={false} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: yellow,
  },
  container: {
    flex: 1,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
  },
  avatarContainer: {
    alignItems: "center",
    marginTop: 32,
    marginBottom: 16,
    width: "100%",
  },
  avatar: {
    width: 144,
    height: 144,
    borderRadius: 140,
    backgroundColor: light,
    marginBottom: 8,
  },
  content: {
    flex: 1,
    justifyContent: "flex-start",
    width: "100%",
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 32,
    color: brown,
    fontFamily: nunitoBlack,
    marginTop: 16,
    marginBottom: 16,
  },
  subtitle: {
    fontSize: 20,
    color: brown,
    fontFamily: sourceSans,
  },
  promoText: {
    color: blue,
    margin: 16,
    fontSize: 16,
    textAlign: "left",
    fontFamily: nunitoBold,
  },
  promoSuccess: {
    color: "green",
    marginLeft: 16,
    marginBottom: 8,
    fontSize: 15,
    fontFamily: nunitoBold,
  },
});
