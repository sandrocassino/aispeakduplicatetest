import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import ProgressBar from "../components/ProgressBar";
import { GiftedChat, Bubble } from "react-native-gifted-chat";
import {
  View,
  Image,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import ChatInputToolbar from "../../Chat/components/ChatInputToolbar";
import {
  light,
  lightBlue,
  blue,
  darkGray,
  dark,
  nunito,
  nunitoBold,
  yellow,
} from "../../../constants";
import supabase from "../../../supabaseClient";
import AsyncStorage from "@react-native-async-storage/async-storage";


const userAvatar = require("../../../assets/images/capy.png");
const aispeakAvatar = require("../../../assets/images/capy.png");
const typingIndicatorGif = require("../../../assets/images/typing-dots.gif");

const mockMessages = [
  {
    _id: 1,
    text: "How should I call you?",
    createdAt: new Date(),
    user: { _id: 1, name: "Capy" },
  },
  {
    _id: 2,
    text: "¡Hola! Soy Capy, tu nuevo amigo para practicar inglés.",
    createdAt: new Date(),
    user: { _id: 1, name: "Capy" },
  },
];

const LEVELS = [
  { label: "Principiante", value: "Principiante" },
  { label: "Intermedio", value: "Intermedio" },
  { label: "Avanzado", value: "Avanzado" },
];

export default function MockChat({
  onNext,
  selectedOption,
  setSelectedOption,
  name,
  setName,
}) {
  const [messages, setMessages] = useState(mockMessages);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [loading, setLoading] = useState(false);
  const [failCount, setFailCount] = useState(1);
  const [nameValidated, setNameValidated] = useState(false);

  // Custom renderBubble to show Capy's avatar on the left of Capy's messages
  const renderBubble = (props) => {
    const isCapy = props.currentMessage.user._id === 1;

    // Render typing indicator as a Capy bubble with gif
    if (props.currentMessage.isTypingIndicator) {
      return (
        <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
          <Image source={aispeakAvatar} style={styles.capyBubbleAvatar} />
          <View style={[styles.typingBubble]}>
            <Image
              source={typingIndicatorGif}
              style={{ width: 40, height: 20 }}
              resizeMode="contain"
            />
          </View>
        </View>
      );
    }

    return (
      <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
        {isCapy && (
          <Image source={aispeakAvatar} style={styles.capyBubbleAvatar} />
        )}
        <View>
          <Bubble
            {...props}
            wrapperStyle={{
              left: isCapy ? { maxWidth: "80%" } : {},
            }}
          />
        </View>
      </View>
    );
  };

  // Handle sending user's name for validation
  const handleSend = async () => {
    if (!name.trim()) return;

    // Add user's message to chat
    const userMsg = {
      _id: messages.length + 1,
      text: name,
      createdAt: new Date(),
      user: { _id: 2, name: "You" },
    };
    setMessages((prev) => GiftedChat.append(prev, [userMsg]));
    setName(""); // Clear the input

    // Add typing indicator bubble
    const typingIndicatorMsg = {
      _id: "typing-indicator",
      isTypingIndicator: true,
      createdAt: new Date(),
      user: { _id: 1, name: "Capy" },
    };
    setMessages((prev) => GiftedChat.append(prev, [typingIndicatorMsg]));
    setLoading(true);

    try {
      const response = await fetch(
        "https://ojcsvhfkvajrpjwdvbkc.supabase.co/functions/v1/GetUserName",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: userMsg.text, failCount }),
        }
      );

      const data = await response.json();

      // Remove typing indicator
      setMessages((prev) =>
        prev.filter((msg) => msg._id !== "typing-indicator")
      );

      if (response.ok && data && data.valid) {
        setMessages((prev) =>
          GiftedChat.append(prev, [
            {
              _id: prev.length + 1,
              text: data.capyMessage,
              createdAt: new Date(),
              user: { _id: 1, name: "Capy" },
            },
          ])
        );
        setFailCount(1);
        setName(userMsg.text); 
        setNameValidated(true);

        await AsyncStorage.setItem("pending_registration_name", userMsg.text);
      } else {
        setMessages((prev) =>
          GiftedChat.append(prev, [
            {
              _id: prev.length + 1,
              text:
                data?.capyMessage ||
                "Sorry, that name is not valid. Try again!",
              createdAt: new Date(),
              user: { _id: 1, name: "Capy" },
            },
          ])
        );
        setFailCount((prev) => prev + 1);
      }
    } catch (error) {
      setMessages((prev) =>
        GiftedChat.append(prev, [
          {
            _id: prev.length + 1,
            text: "Oops! Something went wrong. Please try again.",
            createdAt: new Date(),
            user: { _id: 1, name: "Capy" },
          },
        ])
      );
    } finally {
      setLoading(false);
    }
  };

  // Level selection UI
  const renderLevelSelection = () => (
    <View style={styles.levelContainer}>
      {LEVELS.map((level) => (
        <TouchableOpacity
          key={level.value}
          style={[
            styles.levelButton,
            selectedOption === level.value && styles.levelButtonSelected,
          ]}
          onPress={() => setSelectedOption(level.value)}
        >
          <Text style={[styles.levelButtonText]}>{level.label}</Text>
        </TouchableOpacity>
      ))}
      <TouchableOpacity
        style={[styles.joinButton, !selectedOption && { opacity: 0.5 }]}
        disabled={!selectedOption}
        onPress={onNext}
      >
        <Text style={styles.joinButtonText}>¡Únete ahora!</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: yellow }}>
      <ProgressBar progress={2 / 6} />
      <View style={styles.headerContainer}>
        <View style={styles.imagesRow}>
          <Image source={userAvatar} style={styles.avatar} />
          <Image source={aispeakAvatar} style={styles.avatar} />
        </View>
        <Text style={styles.headerTitle}>¡Seamos compis de chat!</Text>
      </View>
      <GiftedChat
        messages={messages}
        user={{ _id: 2, name: "You" }}
        onSend={handleSend}
        renderBubble={renderBubble}
        renderInputToolbar={
          nameValidated
            ? () => null // Hide input when name validated
            : (props) => (
                <ChatInputToolbar
                  {...props}
                  isRecording={false}
                  newMessage={name}
                  onIsInputFocused={setIsInputFocused}
                  handleStopRecording={() => {}}
                  handleCancelRecording={() => {}}
                  onHandleMessageChange={setName}
                  handleOnSend={handleSend}
                  isInputFocused={isInputFocused}
                  onHandleOnLongPress={() => {}}
                  onHandleQuestionMarkClick2={() => {}}
                  keyboardVisible={isInputFocused}
                  thirdchat={false}
                  isTimeoutActive={false}
                />
              )
        }
        showAvatarForEveryMessage={false}
        renderAvatar={null}
      />
      {nameValidated && renderLevelSelection()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    alignItems: "center",
    marginTop: 16,
    marginBottom: 8,
  },
  imagesRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 28,
    marginHorizontal: -4,
    backgroundColor: light,
  },
  headerTitle: {
    fontSize: 16,
    fontFamily: nunitoBold,
    color: darkGray,
    textAlign: "center",
  },
  capyBubbleAvatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginRight: 6,
    backgroundColor: light,
    alignSelf: "flex-start",
  },
  levelContainer: {
    backgroundColor: yellow,
    padding: 16,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    alignItems: "center",
    marginTop: 8,
    paddingHorizontal: 24,
  },
  levelButton: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 24,
    paddingVertical: 10,
    paddingHorizontal: 24,
    marginVertical: 6,
    backgroundColor: light,
    width: "100%",
    justifyContent: "flex-start",
  },
  levelButtonSelected: {
    backgroundColor: lightBlue,
  },
  levelButtonText: {
    fontSize: 16,
    color: dark,
    fontFamily: nunitoBold,
  },
  joinButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: "center",
    height: 48,
    marginTop: 18,
    marginBottom: 8,
    width: "100%",
  },
  joinButtonText: {
    color: light,
    fontSize: 16,
    lineHeight: 20,
    fontFamily: nunitoBold,
  },
  typingBubble: {
    backgroundColor: light,
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginVertical: 4,
    maxWidth: "80%",
    alignSelf: "flex-start",
    justifyContent: "center",
    alignItems: "center",
  },
});
