import React, { useEffect } from "react";
import { SafeAreaView, View, Text, Image, StyleSheet, Alert } from "react-native";
import ProgressBar from "../components/ProgressBar";
import OnboardingMenu from "../components/OnboardingMenu";
import { nunitoBlack, brown, yellow, light } from "../../../constants";

const capybaraAvatar = require("../../../assets/images/capy.png");

export default function Success({ onNext, currentPage, setIsLoggedIn, setPage, isLoggedIn, setPreviousPage }) {
 
// Check user login status to determine if user has to complete registration process confirming by email
// If user has registered from onboarding flow, app gives a message to check the mail and navigates to LoginPage
// If user logs in from onboarding flow, app navigates to Homepage
// Setting previous page to control if back button appears in login page

 const checkUserStatus = () => {

    setPreviousPage({ page: 1800, onboardingStep: 5, source: 'onboarding' });

  if (isLoggedIn) {
    setPage(6); 
  } else {
    Alert.alert(
      "Verifica tu cuenta",
      "Revisa tu correo electrónico para confirmar tu cuenta.",
      [{ text: "OK", onPress: () => setPage(124) }]
    );
  }
};

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Progress bar */}
        <ProgressBar progress={6 / 6} />

        {/* Capybara illustration */}
        <View style={styles.avatarContainer}>
          <Image source={capybaraAvatar} style={styles.avatar} />
        </View>

        {/* Main content */}
        <View style={styles.content}>
          <Text style={styles.title}>
            ¡Enhorabuena! Estás a un paso de empezar a practicar inglés como
            nunca.
          </Text>
        </View>

        {/* Bottom actions */}
        <OnboardingMenu onNext={checkUserStatus} ctaText="Start Chatting >" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: yellow,
  },
  container: {
    flex: 1,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
  },
  avatarContainer: {
    alignItems: "center",
    marginTop: 32,
    marginBottom: 16,
    width: "100%",
  },
  avatar: {
    width: 282,
    height: 282,
    borderRadius: 140,
    backgroundColor: light,
    marginBottom: 8,
  },
  content: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-start",
    width: "100%",
  },
  title: {
    fontSize: 32,
    color: brown,
    fontFamily: nunitoBlack,
    textAlign: "center",
    marginTop: 16,
    marginBottom: 32,
  },
});
