import React from "react";
import { SafeAreaView, View, Text, Image, StyleSheet } from "react-native";
import OnboardingMenu from "../components/OnboardingMenu";
import ProgressBar from "../components/ProgressBar";
import {
  nunitoBlack,
  nunitoBold,
  nunito,
  sourceSansBold,
  sourceSans,
  brown,
  yellow,
  light,
} from "../../../constants";

const capybaraIcon = require("../../../assets/images/capy.png");
const bubbleIcon = require("../../../assets/icons/onboarding-features-bubble.png");
const conversationIcon = require("../../../assets/icons/onboarding-features-conversation.png");
const microphoneIcon = require("../../../assets/icons/onboarding-features-microphone.png");
const practiceIcon = require("../../../assets/icons/onboarding-features-practice.png");

export default function Benefits({ onNext }) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Progress bar */}
        <ProgressBar progress={1 / 6} />

        {/* Capybara illustration (right side, partial) */}
        <Image
          source={capybaraIcon}
          style={styles.capybaraRight}
          resizeMode="contain"
        />

        {/* Main content */}
        <View style={styles.content}>
          <Text style={styles.title}>
            ¡Hola! Soy Capy,{"\n"}tu nuevo amigo{"\n"}para practicar inglés
          </Text>
          <View style={styles.benefitList}>
            <BenefitItem
              icon={bubbleIcon}
              title="Aprende inglés chateando"
              subtitle="Gana confianza en cada conversación"
            />
            <BenefitItem
              icon={conversationIcon}
              title="Mejora tu fluidez"
              subtitle="Conversaciones inteligentes y amigables"
            />
            <BenefitItem
              icon={microphoneIcon}
              title="Habla con libertad"
              subtitle="Sin presiones, solo práctica"
            />
            <BenefitItem
              icon={practiceIcon}
              title="Consigue un inglés real"
              subtitle="Aprende de forma natural"
            />
          </View>
        </View>

        {/* Bottom actions */}
        <OnboardingMenu onNext={onNext} ctaText="¡Vamos allá! >" />
      </View>
    </SafeAreaView>
  );
}

function BenefitItem({ icon, title, subtitle }) {
  return (
    <View style={styles.benefitItem}>
      <Image source={icon} style={styles.benefitIcon} />
      <View>
        <Text style={styles.benefitTitle}>{title}</Text>
        <Text style={styles.benefitSubtitle}>{subtitle}</Text>
      </View>
    </View>
  );
}

// --- Styles ---
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: yellow,
  },
  container: {
    flex: 1,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
  },
  capybaraRight: {
    position: "absolute",
    right: -340,
    height: 385,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    zIndex: 2,
  },
  title: {
    fontSize: 32,
    color: brown,
    marginBottom: 36,
    marginTop: 96,
    fontFamily: nunitoBlack,
  },
  benefitList: {
    marginBottom: 32,
  },
  benefitItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 24,
  },
  benefitIcon: {
    width: 60,
    height: 60,
    marginRight: 14,
    borderRadius: 18,
  },
  benefitTitle: {
    fontSize: 24,
    color: brown,
    fontFamily: nunitoBold,
  },
  benefitSubtitle: {
    fontSize: 14,
    color: brown,
    fontFamily: nunito,
  },
});
