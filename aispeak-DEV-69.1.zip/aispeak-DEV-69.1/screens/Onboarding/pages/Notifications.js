import React, { useState } from "react";
import { SafeAreaView, View, Text, StyleSheet, Image, TextInput } from "react-native";
import OnboardingMenu from "../components/OnboardingMenu";
import ProgressBar from "../components/ProgressBar";
import { light, yellow, brown, nunitoBold, nunitoBlack } from "../../../constants";

export default function NotificationsScreen({ onNext }) {
  const [hours, setHours] = useState("18");
  const [minutes, setMinutes] = useState("30");

  // Only allow 2 digits, 00-23 for hours, 00-59 for minutes
  const handleHoursChange = (text) => {
    let formatted = text.replace(/[^0-9]/g, "").slice(0, 2);
    if (formatted.length === 2 && parseInt(formatted, 10) > 23) {
      formatted = "23";
    }
    setHours(formatted);
  };

  const handleMinutesChange = (text) => {
    let formatted = text.replace(/[^0-9]/g, "").slice(0, 2);
    if (formatted.length === 2 && parseInt(formatted, 10) > 59) {
      formatted = "59";
    }
    setMinutes(formatted);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <ProgressBar progress={5 / 6} />
        <View style={styles.content}>
          <View style={styles.imageContainer}>
            <Image
              source={require("../../../assets/images/alarm-clock.png")}
              style={styles.image}
              resizeMode="contain"
            />
            <View style={styles.overlayTimeRow}>
              <TextInput
                style={styles.overlayInput}
                value={hours}
                onChangeText={handleHoursChange}
                keyboardType="numeric"
                maxLength={2}
                placeholder="13"
                placeholderTextColor="gray"
                textAlign="center"
                returnKeyType="done"
              />
              <Text style={styles.colon}>:</Text>
              <TextInput
                style={styles.overlayInput}
                value={minutes}
                onChangeText={handleMinutesChange}
                keyboardType="numeric"
                maxLength={2}
                placeholder="37"
                placeholderTextColor="gray"
                textAlign="center"
                returnKeyType="done"
              />
            </View>
          </View>
          <Text style={styles.title}>¿Qué hora te viene mejor para nuestra quedada diaria?</Text>
        </View>
        <OnboardingMenu
          onNext={onNext}
          ctaText="Configura la alarma >"
          showSecondaryButton={true}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: yellow,
  },
  container: {
    flex: 1,
    backgroundColor: "transparent",
    justifyContent: "flex-start",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  imageContainer: {
    width: "100%",
    aspectRatio: 1,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 0,
  },
  image: {
    width: "100%",
    height: "100%",
  },
  overlayTimeRow: {
    position: "absolute",
    top: "50%",
    left: "50%",
    flexDirection: "row",
    alignItems: "center",
    transform: [{ translateX: -92 }, { translateY: -28 }],
    zIndex: 2,
  },
  overlayInput: {
    color: light,
    fontFamily: nunitoBold,
    fontSize: 64,
    borderRadius: 12,
    textAlign: "center",
    minWidth: 80,
    maxWidth: 80,
  },
  colon: {
    fontSize: 64,
    color: light,
    fontFamily: nunitoBold,
    marginHorizontal: 4,
  },
  title: {
    fontSize: 32,
    color: brown,
    fontFamily: nunitoBlack,
    textAlign: "center",
    marginTop: 24,
  },
});