import "react-native-url-polyfill/auto";
import { View, Image, Text, TouchableOpacity } from "react-native";
import styles from "../../Styles";
import "react-native-gesture-handler";

const WelcomeScreens = ({
  page,
  setPage,
  screenHeight,
  screenWidth,
  panResponder,
  panResponder1800,
  panResponder3,
  isTallAspectRatio,
  fontSizeMedium,
}) => {
  const navigateToSubscription = () => {
    setPage(4000, 7); // Force return to HomeScreen to avoid blocking app's path introduction-subscription-introductions
  };

  // PAGE 1
  if (page === 1) {
    return (
      <View
        style={{
          ...styles.container,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image
          source={require("../../assets/images/old-logo-and-brand.png")}
          style={{ ...styles.image44, resizeMode: "contain" }}
        />
      </View>
    );

    // PAGE 1800
  } else if (page === 1800) {
    return (
      <View style={styles.container} {...panResponder1800.panHandlers}>
        {/* Image on first page */}
        <Image
          source={require("../../assets/images/old-logo-and-brand.png")}
          style={[
            styles.image,
            screenHeight <= 667
              ? { width: 80, height: 80, top: 15, left: 140 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 80, height: 80, top: 25, left: 140 }
                : { width: 80, height: 80, top: 25, left: 170 },
            {
              position: "absolute",
              resizeMode: "contain",
              alignSelf: "center",
              left: "43%",
            },
          ]}
        />
        <Image
          source={require("../../assets/images/man-looking-at-big-screen.png")}
          style={[
            styles.image1,
            screenHeight <= 667
              ? { width: 262.5, height: 262.5, top: 130, left: 45 }
              : { width: 350, height: 350, top: 170, left: 30 },
            { position: "absolute" },
          ]}
        />
        <Image
          source={require("../../assets/images/capy.png")}
          style={[
            styles.image2,
            screenHeight <= 667
              ? { width: 45, height: 45, top: 250, left: 162 }
              : { width: 60, height: 60, top: 320, left: 185 },
            { position: "absolute" },
          ]}
        />
        <Image
          source={require("../../assets/icons/white-round-bubble-no-bg.png")}
          style={[
            styles.image3,
            screenHeight <= 667
              ? { width: 100, height: 100, top: 90, left: 70 }
              : { width: 140, height: 140, top: 100, left: 50 },
            { position: "absolute", resizeMode: "contain" },
          ]}
        />
        <Text
          style={[
            styles.text1,
            screenHeight <= 667
              ? { position: "absolute", top: 380, left: 50 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 520, left: 50 }
                : { position: "absolute", top: 520, left: 80 }, // adjust left as needed for iPhone 13 Pro and above
          ]}
        >
          La mejor manera de {"\n"}aprender un idioma!
        </Text>

        <Text
          style={[
            styles.text2,
            {
              marginTop: 10, // Add marginTop for spacing
            },
            screenHeight <= 667
              ? { position: "absolute", top: 450, left: 50 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 590, left: 50 }
                : { position: "absolute", top: 590, left: 80 }, // adjust left as needed for iPhone 13 Pro and above
          ]}
        >
          Aprende un idioma con Aispeak y {"\n"}verás la diferencia.
        </Text>

        <View
          style={[
            styles.paginationContainer,
            {
              position: "absolute",
              bottom: 70,
              left: 130,
              justifyContent: "center",
              alignItems: "center",
            },
          ]}
        >
          <View style={[styles.circle, styles.selectedCircle]} />
          <View style={styles.circle} />
          <View style={styles.circle} />
          <View style={styles.circle} />
        </View>

        <TouchableOpacity
          onPress={() => setPage(2)}
          style={{ position: "absolute", bottom: 45, right: 40 }}
        >
          <Image
            source={require("../../assets/icons/transparent-arrow-right-black-bg.png")}
            style={styles.arrow}
          />
        </TouchableOpacity>
      </View>
    );

    // PAGE 2
  } else if (page === 2) {
    return (
      <View style={styles.container} {...panResponder.panHandlers}>
        {/* Second page */}
        {/* Image on second page */}
        <Image
          source={require("../../assets/images/old-logo-and-brand.png")}
          style={[
            styles.image,
            screenHeight <= 667
              ? { width: 80, height: 80, top: 15, left: 140 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 80, height: 80, top: 25, left: 140 }
                : { width: 80, height: 80, top: 25, left: 170 },
            {
              position: "absolute",
              resizeMode: "contain",
              alignSelf: "center",
              left: "43%",
            },
          ]}
        />
        <TouchableOpacity
          onPress={() => setPage(3)}
          style={{ position: "absolute", bottom: 45, right: 40 }}
        >
          <Image
            source={require("../../assets/icons/transparent-arrow-right-black-bg.png")}
            style={styles.arrow}
          />
        </TouchableOpacity>
        <View
          style={[
            styles.paginationContainer,
            { position: "absolute", bottom: 70, left: 130 },
          ]}
        >
          <View style={styles.circle} />
          <View style={[styles.circle, styles.selectedCircle]} />
          <View style={styles.circle} />
          <View style={styles.circle} />
        </View>

        {/* Copy of images and text from first page */}
        <Image
          source={require("../../assets/images/man-and-woman-solving-puzzle.png")}
          style={[
            styles.image1,
            screenHeight <= 667
              ? { width: 262.5, height: 262.5, top: 90, left: 45 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 350, height: 350, top: 150, left: 10 }
                : { width: 350, height: 350, top: 150, left: 40 },
            { position: "absolute" },
          ]}
        />
        <Image
          source={require("../../assets/images/capy.png")}
          style={[
            styles.image2,
            screenHeight <= 667
              ? { width: 45, height: 45, top: 285, left: 260 }
              : { width: 60, height: 60, top: 410, left: 270 },
            { position: "absolute" },
          ]}
        />

        <Text
          style={[
            styles.text1,
            screenHeight <= 667
              ? { position: "absolute", top: 340, left: 50 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 500, left: 50 }
                : { position: "absolute", top: 500, left: 80 }, // adjust left as needed for iPhone 13 Pro and above
          ]}
        >
          Aprende lo mejor de {"\n"}cada día memorizando.
        </Text>

        <Text
          style={[
            styles.text2,
            {
              marginTop: 10, // Add marginTop for spacing
            },
            screenHeight <= 667
              ? { position: "absolute", top: 410, left: 50 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 570, left: 50 }
                : { position: "absolute", top: 570, left: 80 }, // adjust left as needed for iPhone 13 Pro and above
          ]}
        >
          Cuando repites la misma{"\n"}gramática y palabras, pronto puedes{"\n"}
          armar las piezas del rompecabezas.
        </Text>
      </View>
    );

    // PAGE 3
  } else if (page === 3) {
    return (
      <View style={styles.container} {...panResponder3.panHandlers}>
        {/* Third page */}
        {/* Image on third page */}
        <Image
          source={require("../../assets/images/old-logo-and-brand.png")}
          style={[
            styles.image,
            screenHeight <= 667
              ? { width: 80, height: 80, top: 15, left: 140 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 80, height: 80, top: 25, left: 140 }
                : { width: 80, height: 80, top: 25, left: 170 },
            {
              position: "absolute",
              resizeMode: "contain",
              alignSelf: "center",
              left: "43%",
            },
          ]}
        />
        <TouchableOpacity
          onPress={navigateToSubscription}
          style={{ position: "absolute", bottom: 45, right: 40 }}
        >
          <Image
            source={require("../../assets/icons/transparent-arrow-right-black-bg.png")}
            style={styles.arrow}
          />
        </TouchableOpacity>

        <View
          style={[
            styles.paginationContainer,
            { position: "absolute", bottom: 70, left: 130 },
          ]}
        >
          <View style={styles.circle} />
          <View style={styles.circle} />
          <View style={[styles.circle, styles.selectedCircle]} />
          <View style={styles.circle} />
        </View>

        {/* Copy of images and text from first page */}
        <Image
          source={require("../../assets/images/man-happy-raising-arms-in-park.png")}
          style={[
            styles.image1,
            screenHeight <= 667
              ? { width: 262.5, height: 262.5, top: 130, left: 45 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 350, height: 350, top: 170, left: 10 }
                : { width: 350, height: 350, top: 170, left: 40 },
            { position: "absolute" },
          ]}
        />
        <Image
          source={require("../../assets/images/capy.png")}
          style={[
            styles.image2,
            screenHeight <= 667
              ? { width: 45, height: 45, top: 300, left: 90 }
              : screenHeight > 667 && screenHeight <= 896
                ? { width: 60, height: 60, top: 400, left: 70 }
                : { width: 60, height: 60, top: 400, left: 100 },
            { position: "absolute" },
          ]}
        />

        <Text
          style={[
            styles.text01,

            screenHeight <= 667
              ? { position: "absolute", top: 410, left: 50 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 540, left: 50 }
                : { position: "absolute", top: 540, left: 80 }, // adjust left as needed for iPhone 13 Pro and above
          ]}
        >
          Comienza ahora &{"\n"}tu viaje comienza aquí!
        </Text>
        <Text
          style={[
            styles.text2,
            screenHeight <= 667
              ? { position: "absolute", top: 480, left: 70 }
              : screenHeight > 667 && screenHeight <= 896
                ? { position: "absolute", top: 590, left: 70 }
                : { position: "absolute", top: 590, left: 110 },
          ]}
        >
          {"\n"}
        </Text>
      </View>
    );
  }
};

export default WelcomeScreens;
