import React, { useEffect, useState } from "react";
import Benefits from "./pages/Benefits";
import MockChat from "./pages/MockChat";
import Registration from "./pages/Registration";
import Subscription from "./pages/Subscription";
import Notifications from "./pages/Notifications";
import Success from "./pages/Success";
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Platform,
} from "react-native";
import { darkBlue, dark, yellow, light } from "../../constants";

const UserContext = React.createContext();

export default function OnboardingScreens({
  setPage,
  selectedOption,
  setSelectedOption,
  name,
  setName,
  setIsOnboardingCompleted,
  selectedPlan,
  selectedBillingCycle,
  setSelectedBillingCycle,
  currentPlan,
  currentBillingCycle,
  alreadySelectedPlan,
  handleTesterButtonPress,
  testerUsed,
  setTesterUsed,
  isTrialActive,
  setIsTrialActive,
  setCurrentPlan,
  setCurrentBillingCycle,
  setIsTimeoutActive,
  setChatCount,
  setTrialChatCount,
  setRemainingTime,
  saveToSupabase,
  inAppBuySubscription,
  setIsSubscribing,
  signUp,
  email,
  password,
  setEmail,
  setPassword,
  emailError,
  setEmailError,
  validateEmail,
  activeField,
  setActiveField,
  passwordError,
  setPasswordError,
  setPreviousPage,
  previousPage,
  setLoginFlowSource,
  page,
  setIsLoggedIn,
  isLoggedIn,
}) {
  const [currentPage, setCurrentPage] = useState(0);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  useEffect(() => {
    if (page === 23) {
      setCurrentPage(3);
      return;
    }
    if (
      previousPage?.source === "onboarding" &&
      previousPage?.onboardingStep !== undefined
    ) {
      setCurrentPage(previousPage.onboardingStep);
    }
    if (
      (previousPage?.source === "ChangePasswordEmail" ||
        previousPage?.source === "onboarding") &&
      typeof previousPage?.onboardingStep === "number"
    ) {
      setCurrentPage(previousPage.onboardingStep);
    }
  }, [previousPage]);

  const handleNext = () => {
    if (currentPage < 5) {
      setCurrentPage(currentPage + 1);
    } else {
      setPage(6);
      setIsOnboardingCompleted(true);
    }
  };

  const handleSignUp = async () => {
    const { error, user } = await signUp(email, password, name, {
      navigateAfterSignup: false, 
      onSuccess: () => {
        setShowSuccessMessage(true);
        setTimeout(() => {
          setEmail("");
          setPassword("");
          handleNext();
        }, 2000);
      },
    });

    if (error) {
      setLoginError("No se pudo crear la cuenta");
      return;
    }
  };

  const onboardingPages = [
    <Benefits onNext={handleNext} />,
    <MockChat
      onNext={handleNext}
      selectedOption={selectedOption}
      setSelectedOption={setSelectedOption}
      name={name}
      setName={setName}
    />,
    showSuccessMessage ? (
      <View style={styles.successMessageContainer}>
        <Text style={styles.successMessageText}>
          ¡Has creado una{"\n"}cuenta con éxito!{"\n"} 🎉{"\n"}
          Revisa tu correo para verificar tu cuenta.
        </Text>
      </View>
    ) : (
      <Registration
        onNext={handleNext}
        signUp={signUp}
        email={email}
        password={password}
        setEmail={setEmail}
        setPassword={setPassword}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        name={name}
        setName={setName}
        validateEmail={validateEmail}
        emailError={emailError}
        setEmailError={setEmailError}
        activeField={activeField}
        setActiveField={setActiveField}
        passwordError={passwordError}
        setPasswordError={setPasswordError}
        onPrimaryAction={handleSignUp}
        setPage={setPage}
        setPreviousPage={setPreviousPage}
        setLoginFlowSource={setLoginFlowSource}
        previousPage={previousPage}
        setIsLoggedIn={setIsLoggedIn}
        isLoggedIn={isLoggedIn}
      />
    ),
    <Subscription onNext={handleNext} handleTesterButtonPress={handleTesterButtonPress} setTesterUsed={setTesterUsed} />,
    <Notifications onNext={handleNext} />,
    <Success
      onNext={handleNext}
      setIsLoggedIn={setIsLoggedIn}
      currentPage={currentPage}
      setPage={setPage}
      isLoggedIn={isLoggedIn}
      setPreviousPage={setPreviousPage}
    />,
  ];

  return (
    <View style={{ flex: 1, backgroundColor: yellow }}>
      {onboardingPages[currentPage]}
    </View>
  );
}

const styles = StyleSheet.create({
  successMessageContainer: {
    position: "absolute",
    top: 310,
    zIndex: 200,
    left: 50,
    right: 50,
    justifyContent: "center",
    alignItems: "center",
    borderColor: darkBlue,
    borderWidth: 1,
    backgroundColor: light,
    padding: 25,
    borderRadius: 10,
    ...Platform.select({
      ios: {
        shadowColor: dark,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 5,
      },
    }),
  },

  successMessageText: { fontSize: 18, color: dark, textAlign: "center" },
}); 