import { useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, Image } from "react-native";
import Styles from "../Styles";
export default function NameInputScreen({
  name,
  setName,
  setPage,
  setIsOnboardingCompleted,
  setChatHistory,
  setShouldLoadMessages,
  setCurrentChatKey,
  setChatKey,
  selectedOption,
  setCurrentCountPrincipiante,
  setCurrentCountIntermedio,
  setCurrentCountAvanzado,
  styles,
}) {
  useEffect(() => {
    console.log("NameInputScreen mounted (entered)");
    return () => {
      console.log("NameInputScreen unmounted (left)");
    };
  }, []);

  return (
    <View style={Styles.container}>
      {/* Blank page */}
      <View style={[Styles.blankPage, { marginTop: "10%" }]}>
        <View style={Styles.lightBox}>
          <Text style={Styles.question}>Cual es tu nombre?</Text>
          <TextInput
            style={Styles.input}
            onChangeText={setName}
            value={name}
            placeholder="Introduzca su nombre"
          />
          <Image
            source={require("/assets/images/old-logo-and-brand.png")}
            style={[
              Styles.image90,
              {
                position: "absolute",
                top: 30,
                left: 65,
                resizeMode: "contain",
                width: 140,
                height: 140,
              },
            ]}
          />
          <Text
            style={[
              Styles.text13,
              { position: "absolute", top: 260, left: 40 },
            ]}
          >
            Aprendamos!
          </Text>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-around" }}>
          <TouchableOpacity
            onPress={() => {
              setPage(6);
              setIsOnboardingCompleted(true);
              setChatHistory([]);
              setShouldLoadMessages(false);
              setCurrentChatKey((prevKey) => {
                const newKey = prevKey + 1; // Increment currentChatKey
                setChatKey(newKey); // Set chatKey to the new key
                return newKey;
              });
              if (selectedOption === "Principiante") {
                setCurrentCountPrincipiante(1);
              } else if (selectedOption === "Intermedio") {
                setCurrentCountIntermedio(1);
              } else if (selectedOption === "Avanzado") {
                setCurrentCountAvanzado(1);
              }
            }}
            style={{ position: "absolute", bottom: 30, right: -10 }}
          >
            <Image
              source={require("assets/images/union-jack.png")}
              style={Styles.image7}
            />
          </TouchableOpacity>
          <Image
            source={require("/assets/images/orange-left-arrow.gif")}
            style={[
              Styles.image5,
              {
                resizeMode: "contain",
                position: "absolute",
                top: -85,
                left: 20,
              },
            ]}
          />
        </View>
      </View>
    </View>
  );
}
