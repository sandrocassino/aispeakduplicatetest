import "react-native-url-polyfill/auto";
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  Keyboard,
  Image,
  Alert,
  StyleSheet,
  Platform,
} from "react-native";
import "react-native-gesture-handler";
import { Ionicons } from "@expo/vector-icons";
import React, { useState, useEffect } from "react";
import {
  blue,
  red,
  yellow,
  dark,
  light,
  nunito,
  nunitoBold,
  sourceSans,
  lightBlue,
  inputRed,
  lightRed,
  textGray,
  veryLightRed,
} from "../../constants";
import BlueBackButton from "./BlueBackButton";
import { useInputStyles } from "../../hooks/useInputStyles";

const LoginScreen = ({
  setPage,
  page,
  screenHeight,
  email,
  setEmail,
  password,
  setPassword,
  logIn,
  loginError,
  setLoginError,
  loginSuccess,
  isLoggedIn,
  emailError,
  setEmailError,
  passwordError,
  setPasswordError,
  name,
  setName,
  setIsLoggedIn,
  previousPage,
  currentScreen,
  setCurrentScreen,
  setPreviousPage,
  isAppFlow = false,
  loginFlowSource,
  setLoginFlowSource,
  currentPage,
  setCurrentPage,
}) => {
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [activeField, setActiveField] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasAttemptedLogin, setHasAttemptedLogin] = useState(false);

  const { getInputStyle, getIconColor } = useInputStyles({
    activeField,
    emailError,
    passwordError,
    styles,
  });

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => setKeyboardVisible(true)
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => setKeyboardVisible(false)
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const [navigationDone, setNavigationDone] = useState(false);

  useEffect(() => {
    if (!isLoggedIn || !previousPage || navigationDone) {
      return;
    }

    const cameFromOnboarding = previousPage.source === "onboarding";

    if (cameFromOnboarding && Number(previousPage.page) === 1800) {
      setPage(6);
    } else if (cameFromOnboarding) {
      setPage(23);
    } else {
      setPage(7);
    }

    setNavigationDone(true);
  }, [isLoggedIn, previousPage, navigationDone]);

  const handleLogin = async () => {
    // Clear error states
    setEmailError("");
    setPasswordError("");
    setErrorMessage(null);
    setLoginError(null);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let hasError = false;

    if (!email.trim()) {
      setEmailError("Por favor, introduce tu correo electrónico");
      hasError = true;
    } else if (!emailRegex.test(email)) {
      setEmailError("Introduce un correo electrónico válido.");
      hasError = true;
    }

    if (!password.trim()) {
      setPasswordError("Por favor, introduce tu contraseña");
      hasError = true;
    }

    if (!password) {
      setPasswordError("Por favor, introduce una contraseña válida.");
      return;
    } else if (password.length < 6) {
      setPasswordError("La contraseña debe tener al menos 6 caracteres.");
      return;
    }

    if (hasError) {
      setHasAttemptedLogin(false);
      return;
    }

    setHasAttemptedLogin(true);

    let user;
    try {
      user = await logIn(
        email,
        password,
        setIsLoggedIn,
        setName,
        setEmail,
        name
      );
    } catch (error) {
      console.error("🔥 logIn threw an error:", error);
      setLoginError("Ocurrió un error durante el inicio de sesión.");
      return;
    }

    if (!user) {
      return;
    }

    setEmail("");
    setPassword("");
  };

  return (
    <SafeAreaView style={styles.newLoginContainer}>
      <View style={{ marginTop: 16, marginLeft: 24 }}>
        {(previousPage?.source !== "onboarding" ||
          previousPage?.onboardingStep === 2) && (
          <BlueBackButton
            setPage={setPage}
            page={page}
            previousPage={previousPage}
            setPreviousPage={setPreviousPage}
            currentScreen={currentScreen}
            setCurrentScreen={setCurrentScreen}
            setLoginFlowSource={setLoginFlowSource}
            setEmail={setEmail}
          />
        )}
      </View>
      <View style={styles.newLoginHeader}>
        <Text style={styles.newLoginTitle}>{`¡Nos alegra volver a 
verte!`}</Text>
        <Text style={styles.newLoginSubtitle}>
          Inicia sesión y continúa chateando con Capy 💬
        </Text>
      </View>

      <View style={styles.newLoginForm}>
        {/* Email field */}
        <View style={getInputStyle("email")}>
          <Ionicons
            name="mail-outline"
            size={20}
            color={getIconColor("email")}
            style={styles.inputIcon}
          />
          <TextInput
            style={[
              styles.newLoginInput,
              emailError && { color: inputRed },
              activeField === "email" && { color: textGray },
            ]}
            onChangeText={(text) => {
              setEmail(text);
              setEmailError("");
            }}
            value={email}
            placeholder="Correo electrónico"
            placeholderTextColor={
              emailError && activeField !== "email" ? inputRed : textGray
            }
            autoCapitalize="none"
            onFocus={() => {
              setActiveField("email");
              setEmailError("");
            }}
            onBlur={() => {
              setActiveField(null);
              const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
              if (!email.trim()) {
                setEmailError("Por favor, introduce tu correo electrónico");
              } else if (!emailRegex.test(email)) {
                setEmailError("Introduce un correo electrónico válido.");
              }
            }}
          />
        </View>
        {emailError ? (
          <Text style={styles.errorTextUnderField}>{emailError}</Text>
        ) : null}

        {/* Password field */}
        <View
          style={[
            getInputStyle("password"),
            (passwordError || (hasAttemptedLogin && loginError)) && {
              color: inputRed,
              backgroundColor: veryLightRed,
              borderColor: inputRed,
            },
          ]}
        >
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={getIconColor("password")}
            style={[
              styles.inputIcon,
              (passwordError || (hasAttemptedLogin && loginError)) && {
                color: inputRed,
              },
            ]}
          />
          <TextInput
            style={[
              styles.newLoginInput,

              activeField === "password" &&
                !passwordError && {
                  color: textGray,
                },
            ]}
            onChangeText={(text) => {
              setPassword(text);
              setPasswordError("");
              setHasAttemptedLogin(false);
            }}
            value={password}
            secureTextEntry={isLoggedIn || !passwordVisible}
            placeholder="Contraseña"
            placeholderTextColor={
              passwordError || (hasAttemptedLogin && loginError)
                ? inputRed
                : textGray
            }
            onFocus={() => {
              setActiveField("password");
              setPasswordError("");
            }}
            onBlur={() => setActiveField(null)}
          />
          <TouchableOpacity
            onPress={() => setPasswordVisible(!passwordVisible)}
            style={styles.eyeIcon}
          >
            <Image
              source={require("assets/icons/gray-eye-no-bg.png")}
              style={styles.eyeImage}
            />
          </TouchableOpacity>
        </View>
        {passwordError ? (
          <Text style={styles.errorTextUnderField}>{passwordError}</Text>
        ) : null}

        {errorMessage && (
          <Text style={styles.errorTextUnderField}>{errorMessage}</Text>
        )}
        {hasAttemptedLogin && loginError && (
          <Text style={styles.errorTextUnderField}>{loginError}</Text>
        )}
        {loginSuccess && <Text style={styles.successText}>{loginSuccess}</Text>}
        <TouchableOpacity onPress={handleLogin} style={styles.newLoginButton}>
          <Text style={styles.newLoginButtonText}>Iniciar sesión</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.forgotPassContainer}
          onPress={() => {
            setEmailError("");
            setPasswordError("");
            setEmail("");
            setPage("ForgotPassword");
          }}
        >
          <Text style={styles.forgotPassText}>Olvidé mi contraseña</Text>
        </TouchableOpacity>
      </View>

      {isAppFlow && ( //To show this part only on app flow, not on onboarding flow
        <View style={styles.newLoginFooter}>
          <Text style={styles.footerQuestion}>¿Aún no te has registrado? </Text>
          <TouchableOpacity onPress={() => setPage(122)}>
            <Text style={styles.footerLink}>Crea una cuenta</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  newLoginContainer: {
    paddingTop: 32,
    flex: 1,
    backgroundColor: yellow,
    justifyContent: "flex-start",
    paddingHorizontal: 16,
  },

  // Header section: big title + subtitle
  newLoginHeader: {
    marginTop: 40,
    paddingHorizontal: 24,
  },
  newLoginTitle: {
    fontSize: 30,
    color: dark,
    marginBottom: 10,
    fontFamily: nunitoBold,
    lineHeight: 36,
  },
  newLoginSubtitle: {
    fontSize: 16,
    color: dark,
    marginBottom: 45,
    fontFamily: sourceSans,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: 24,
  },

  // Form area for inputs and button
  newLoginForm: {
    padding: 8,
    marginBottom: 24,
    marginHorizontal: Platform.OS === "ios" ? 16 : 0,
  },

  // Wrapper around each TextInput (slightly rounded, light background)
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 24,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  newLoginInput: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 15,
    color: dark,
    paddingLeft: 8,
  },

  newLoginInputError: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 15,
    color: inputRed,
  },

  termsConditionsButton: {
    color: light,
    backgroundColor: light,
    borderRadius: 8,
    marginBottom: 8,
  },

  // Blue login button
  newLoginButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 24,
    marginTop: 32,
  },
  newLoginButtonText: {
    color: light,
    fontFamily: nunitoBold,
    fontSize: 16,
  },

  // "Forgot password" text
  forgotPassContainer: {
    alignSelf: "center",
  },
  forgotPassText: {
    color: dark,
    fontSize: 16,
    fontFamily: nunito,
  },

  // Footer (register link) at the bottom
  newLoginFooter: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 100,
  },
  footerQuestion: {
    color: dark,
    fontFamily: nunito,
    fontSize: 16,
  },
  footerLink: {
    color: blue,
    fontFamily: nunito,
    fontSize: 16,
    textDecorationLine: "underline",
  },
  errorTextUnderField: {
    color: inputRed,
    fontSize: 16,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: -10,
  },
});

export default LoginScreen;
