import {
  Image,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
} from "react-native";
import BlueBackButton from "./BlueBackButton";
import {
  blue,
  dark,
  light,
  nunito,
  nunitoBold,
  sourceSans,
  yellow,
} from "../../constants";

const ChangePasswordEmail = ({
  setPage,
  setPreviousPage,
  setLoginFlowSource,
  setEmail
}) => {
  return (
    <SafeAreaView style={styles.newLoginContainer}>
      <View style={styles.newLoginHeader}>
        <Text style={styles.newLoginTitle}>Revisa tu correo electrónico</Text>
        <Text style={styles.newLoginSubtitle}>
          Te hemos enviado un correo para que cambies la contraseña. No olvides
          revisar el spam!
        </Text>
      </View>
      <View style={styles.emailSentContainer}>
        <Image
          style={styles.emailSentImage}
          source={require("/assets/images/emailsend.png")}
        />
      </View>
      <TouchableOpacity
        style={styles.newLoginButton}
        onPress={() => {
          setEmail("");
          setLoginFlowSource("ChangePasswordemail");
          setPreviousPage({
            page: 3,
            onboardingStep: 2,
            source: "ChangePasswordEmail",
          });

          setPage(124);
        }}
      >
        <Text style={styles.newLoginButtonText}>Entendido</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  newLoginContainer: {
    paddingTop: 104,
    flex: 1,
    backgroundColor: yellow,
    justifyContent: "flex-start",
    paddingHorizontal: 16,
  },

  // Header section: big title + subtitle
  newLoginHeader: {
    marginTop: 40,
    paddingHorizontal: 24,
  },
  newLoginTitle: {
    fontSize: 30,
    color: dark,
    marginBottom: 10,
    fontFamily: nunitoBold,
    lineHeight: 36,
  },
  newLoginSubtitle: {
    fontSize: 16,
    color: dark,
    fontFamily: sourceSans,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: 24,
    marginTop: 16,
  },

  // Form area for inputs and button
  newLoginForm: {
    padding: 8,
    marginBottom: 24,
    marginHorizontal: Platform.OS === "ios" ? 16 : 0,
  },

  // Wrapper around each TextInput (slightly rounded, light background)
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 24,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  emailSentContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  emailSentImage: {
    width: 200,
    height: 200,
    marginVertical: 48,
  },

  // Blue login button
  newLoginButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 24,
    marginHorizontal: Platform.OS === "ios" ? 16 : 0,
  },
  newLoginButtonText: {
    color: light,
    fontFamily: nunitoBold,
    fontSize: 16,
  },

  // Footer (register link) at the bottom
  newLoginFooter: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 100,
  },
  footerQuestion: {
    color: dark,
    fontFamily: nunito,
    fontSize: 16,
  },
  footerLink: {
    color: blue,
    fontFamily: nunito,
    fontSize: 16,
    textDecorationLine: "underline",
  },
});

export default ChangePasswordEmail;
