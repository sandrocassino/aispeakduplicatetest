import React from "react";
import { TouchableOpacity, View, Image } from "react-native";
import { blue } from "../../constants";

const BlueBackButton = ({
  page,
  setPage,
  previousPage,
  setLoginFlowSource,
  setEmail,
}) => {
  const handleBack = () => {
    if (previousPage?.source === "ChangePasswordEmail") {
      setEmail("");
      setPage(previousPage?.page); // Registration page from onboarding
    } else if (page === "ForgotPassword") {
      setEmail("");

      setPage(124); // Back to login
    } else if (previousPage?.source === "onboarding") {
      setEmail("");

      setPage(3); // Back to onboarding container
    } else if (previousPage?.source === "app") {
      setEmail("");

      setPage(previousPage?.page ?? 9); // Back to app Register/Profile
    } else {
      setEmail("");

      setPage(9); // Default fallback
    }
    setLoginFlowSource(null);
  };

  return (
    <TouchableOpacity onPress={handleBack}>
      <View
        style={{
          width: 40,
          height: 40,
          backgroundColor: blue,
          borderRadius: 50,
          justifyContent: "center",
          alignItems: "center",
          padding: 8,
          marginTop: 8,
        }}
      >
        <Image
          source={require("assets/icons/arrow-left.png")}
          style={{ width: 24, height: 24 }}
        />
      </View>
    </TouchableOpacity>
  );
};

export default BlueBackButton;
