import React, { useState } from "react";
import {
  Image,
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
} from "react-native";
import {
  yellow,
  blue,
  nunitoBold,
  dark,
  sourceSans,
  textGray,
  light,
  lightBlue,
  inputRed,
} from "../../constants";
import BlueBackButton from "./BlueBackButton";
import supabase from "../../supabaseClient";
import { useInputStyles } from "../../hooks/useInputStyles";

const ForgotPasswordPage = ({
  setPage,
  validateEmail,
  email,
  page,
  setLoginFlowSource,
  setEmail,
  emailError,
  passwordError,
  setEmailError,
}) => {
  const [activeField, setActiveField] = useState(null);

  const { getInputStyle, getIconColor } = useInputStyles({
    activeField,
    emailError,
    passwordError,
    styles,
  });

  const getSupabaseRedirectUrl = () => {
    const baseUrl = "https://www.aispeakapp.com";
    return `${baseUrl}/auth/reset-password`;
  };

  const handlePasswordReset = async () => {
    console.log(">>> handlePasswordReset function HAS BEEN CALLED <<<");

    const emailRegex = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/; // stricter regex

    if (!email || email.trim() === "") {
      Alert.alert("Error", "Por favor ingresa un correo válido.");
      return;
    }

    if (!emailRegex.test(email)) {
      Alert.alert("Error", "Introduce un correo electrónico válido.");
      return;
    }

    console.log("Sending password reset to:", email);

    const redirectToValue = "https://www.aispeakapp.com/auth/reset-password";

    console.log("Redirect URL being sent to Supabase:", redirectToValue);

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectToValue,
    });

    if (error) {
      Alert.alert("Error", error.message);
    } else {
      setPage("ChangePasswordEmail");
    }
  };

  return (
    <SafeAreaView style={styles.newLoginContainer}>
      <View style={{ marginTop: 16, marginLeft: 24 }}>
        <BlueBackButton
          setPage={setPage}
          page={page}
          setLoginFlowSource={setLoginFlowSource}
          setEmail={setEmail}
        />
      </View>
      <View style={styles.newLoginHeader}>
        <Text style={styles.newLoginTitle}>¿Has olvidado tu contraseña?</Text>
        <Text style={styles.newLoginSubtitle}>
          No te preocupes, indícanos tu correo electrónico y te enviaremos un
          enlace para recuperarla.
        </Text>
      </View>
      <View style={getInputStyle("email")}>
        <Image
          source={require("/assets/icons/mail.png")}
          style={styles.inputIcon}
        />
        <TextInput
          style={[
            styles.newLoginInput,
            emailError && { color: inputRed },
            activeField === "email" && { color: textGray },
          ]}
          onChangeText={(text) => validateEmail(text, true)}
          value={email}
          placeholder="Correo electrónico"
          placeholderTextColor={
            emailError && activeField !== "email" ? inputRed : textGray
          }
          autoCapitalize="none"
          onFocus={() => {
            setActiveField("email");
            setEmailError("");
          }}
          onBlur={() => {
            setActiveField(null);
            validateEmail(email, true);
          }}
        />
      </View>
      {emailError ? (
        <Text style={styles.errorTextUnderField}>{emailError}</Text>
      ) : null}
      <TouchableOpacity
        style={styles.newLoginButton}
        onPress={handlePasswordReset}
      >
        <Text style={styles.newLoginButtonText}>Recuperar contraseña</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  newLoginContainer: {
    paddingTop: 32,
    flex: 1,
    backgroundColor: yellow,
    justifyContent: "flex-start",
    paddingHorizontal: 16,
  },
  newLoginHeader: {
    marginTop: 40,
    paddingHorizontal: 24,
  },
  newLoginTitle: {
    fontSize: 30,
    color: dark,
    fontFamily: nunitoBold,
    lineHeight: 36,
  },
  newLoginSubtitle: {
    fontSize: 16,
    color: dark,
    marginBottom: 48,
    fontFamily: sourceSans,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: 24,
    marginTop: 16,
  },
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 24,
    paddingHorizontal: Platform.OS === "android" ? 16 : 24,
    marginHorizontal: Platform.OS === "ios" ? 16 : 0,
  },
  newLoginInput: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 16,
    color: dark,
    paddingLeft: 8,
  },
  inputIcon: {
    color: dark,
  },

  // Blue login button
  newLoginButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 32,
    marginBottom: 80,
    marginHorizontal: Platform.OS === "ios" ? 16 : 0,
  },
  newLoginButtonText: {
    color: light,
    fontFamily: nunitoBold,
    fontSize: 16,
  },

  errorTextUnderField: {
    color: inputRed,
    fontSize: 16,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: 5,
  },
});

export default ForgotPasswordPage;
