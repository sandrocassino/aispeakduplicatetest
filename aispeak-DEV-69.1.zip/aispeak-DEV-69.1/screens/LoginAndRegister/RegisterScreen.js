import "react-native-url-polyfill/auto";
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  Linking,
  StyleSheet,
  Platform,
} from "react-native";
import "react-native-gesture-handler";
import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import {
  blue,
  dark,
  nunito,
  nunitoBold,
  sourceSans,
  yellow,
  light,
  textGray,
  lightBlue,
  sourceSansBold,
  veryLightRed,
  inputRed,
} from "constants";
import BlueBackButton from "./BlueBackButton";
import { useInputStyles } from "../../hooks/useInputStyles";
import TermsAndConditions from "../../components/TermsAndCondition";

const RegisterScreen = ({
  page,
  setPage,
  validateEmail,
  email,
  setEmail,
  emailError,
  setEmailError,
  password,
  setPassword,
  passwordError,
  setPasswordError,
  signUp,
  setisregistered,
  setPreviousPage,
  setLoginFlowSource,
}) => {
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);

  // State for tracking active/focused fields
  const [activeField, setActiveField] = useState(null);
  const [registrationName, setRegistrationName] = useState("");
  const [nameError, setNameError] = useState("");
  const [termsError, setTermsError] = useState("");

  const { getInputStyle, getIconColor } = useInputStyles({
    activeField,
    nameError,
    emailError,
    passwordError,
    styles,
  });

  return (
    <SafeAreaView style={styles.newLoginContainer}>
      {/* Back Button (same as ChatHeader.js, goes to SETTINGS page) */}
      <View
        style={{
          marginTop: Platform.OS === "android" ? 16 : 0,
          marginLeft: 24,
        }}
      >
        <BlueBackButton
          setPage={setPage}
          page={page}
          setEmail={setEmail}
          setLoginFlowSource={setLoginFlowSource}
        />
      </View>
      {/* Header Section */}
      <View style={styles.newLoginHeader}>
        <Text style={styles.newLoginTitle}>
          Regístrate para empezar a aprender
        </Text>
        <Text style={styles.newLoginSubtitle}>
          Crea una cuenta y chatea con Capy para llevar tu Inglés a otro nivel
          🚀
        </Text>
      </View>

      {/* Form Area */}
      <View style={styles.newLoginForm}>
        {/* Name Field */}
        <View style={getInputStyle("name")}>
          <Image
            source={require("/assets/icons/user.png")}
            style={[styles.inputIcon, { tintColor: getIconColor("name") }]}
          />
          <TextInput
            style={[
              styles.newLoginInput,
              nameError && styles.newLoginInputError,
              activeField === "name" && { color: textGray },
            ]}
            placeholder="Nombre"
            placeholderTextColor={
              nameError && activeField !== "name" ? inputRed : textGray
            }
            value={registrationName}
            onChangeText={(text) => {
              setRegistrationName(text);
              setNameError("");
            }}
            onFocus={() => setActiveField("name")}
            onBlur={() => {
              setActiveField(null);
              if (!registrationName.trim()) {
                setNameError("Por favor, introduce tu nombre");
              }
            }}
          />
        </View>
        {nameError ? (
          <Text style={styles.errorTextUnderField}>{nameError}</Text>
        ) : null}

        {/* Email Field */}
        <View style={getInputStyle("email")}>
          <Image
            source={require("/assets/icons/mail.png")}
            style={[styles.inputIcon, { tintColor: getIconColor("email") }]}
          />
          <TextInput
            style={[
              styles.newLoginInput,
              emailError && styles.newLoginInputError,
              activeField === "email" && { color: textGray },
            ]}
            onChangeText={validateEmail}
            value={email}
            placeholder="Correo electrónico"
            placeholderTextColor={
              emailError && activeField !== "email" ? inputRed : textGray
            }
            autoCapitalize="none"
            onFocus={() => {
              setActiveField("email");
              setEmailError("");
            }}
            onBlur={() => {
              setActiveField(null);
              validateEmail(email, true); // trigger validation on blur
            }}
          />
        </View>
        {emailError ? (
          <Text style={styles.errorTextUnderField}>{emailError}</Text>
        ) : null}

        {/* Password Field */}
        <View style={getInputStyle("password")}>
          <Image
            source={require("/assets/icons/lock.png")}
            style={[styles.inputIcon, { tintColor: getIconColor("password") }]}
          />
          <TextInput
            style={[
              styles.newLoginInput,
              passwordError && styles.newLoginInputError,
              activeField === "password" && { color: textGray },
            ]}
            onChangeText={(text) => {
              setPassword(text);
              setPasswordError("");
            }}
            value={password}
            placeholder="Contraseña"
            placeholderTextColor={
              passwordError && activeField !== "password" ? inputRed : textGray
            }
            secureTextEntry={!passwordVisible}
            onFocus={() => {
              setActiveField("password");
              setPasswordError("");
            }}
            onBlur={() => setActiveField(null)}
          />
          <TouchableOpacity
            onPress={() => setPasswordVisible(!passwordVisible)}
            style={styles.eyeIcon}
          >
            <Image
              source={require("assets/icons/gray-eye-no-bg.png")}
              style={styles.eyeImage}
            />
          </TouchableOpacity>
        </View>
        {passwordError ? (
          <Text style={styles.errorTextUnderField}>{passwordError}</Text>
        ) : null}

        <TermsAndConditions 
        acceptTerms={acceptTerms}
        setAcceptTerms={setAcceptTerms}
        termsError={termsError}
        /> 

        {/* Register Button */}
        <TouchableOpacity
          onPress={() => {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Reset all errors
            setNameError("");
            setEmailError("");
            setPasswordError("");
            setTermsError("");

            // Validate name
            if (!registrationName.trim()) {
              setNameError("Por favor, introduce tu nombre.");
              return;
            }

            // Validate email
            if (!email) {
              setEmailError(
                "Por favor, introduce un correo electrónico válido."
              );
              return;
            } else if (!emailRegex.test(email)) {
              setEmailError("Introduce un correo electrónico válido.");
              return;
            }

            // Validate password
            if (!password) {
              setPasswordError("Por favor, introduce una contraseña válida.");
              return;
            } else if (password.length < 6) {
              setPasswordError(
                "La contraseña debe tener al menos 6 caracteres."
              );
              return;
            }

            // Validate terms
            if (!acceptTerms) {
              setTermsError(
                "Debes aceptar los Términos y Condiciones para continuar"
              );
              return;
            }

            // If all validations pass
            signUp(email, password, registrationName);
            setisregistered(true);
          }}
          style={styles.newLoginButton}
        >
          <Text style={styles.newLoginButtonText}>Crear cuenta</Text>
        </TouchableOpacity>

        {/* Login Link */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "center",
            marginTop: Platform.OS === "android" ? 20 : -10,
          }}
        >
          <Text style={styles.footerQuestion}>¿Ya tienes cuenta? </Text>
          <TouchableOpacity
            onPress={() => {
              setEmailError("");
              setPasswordError("");
              setEmail("");
              setLoginFlowSource("app");
              setPreviousPage({ page: 9, source: "app" });
              setPage(124);
            }}
          >
            <Text style={styles.footerLink}>Inicia sesión</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  // Overall container with yellow background
  newLoginContainer: {
    paddingTop: 32,
    flex: 1,
    backgroundColor: yellow,
    justifyContent: "flex-start",
    paddingHorizontal: Platform.OS === "ios" ? 16 : 10,
  },

  // Header section: big title + subtitle
  newLoginHeader: {
    marginTop: 40,
    paddingHorizontal: 24,
  },
  newLoginTitle: {
    fontSize: 30,
    color: dark,
    marginBottom: 10,
    fontFamily: nunitoBold,
    lineHeight: 36,
  },
  newLoginSubtitle: {
    fontSize: 16,
    color: dark,
    marginBottom: 45,
    fontFamily: sourceSans,
    fontStyle: "normal",
    fontWeight: 400,
    lineHeight: 24,
  },

  // Form area for inputs and button
  newLoginForm: {
    padding: 8,
    marginBottom: 24,
    paddingHorizontal: Platform.OS === "ios" ? 20 : 10,
  },

  // Wrapper around each TextInput (slightly rounded, light background)
  inputWrapperYellow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: light,
    borderRadius: 24,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  newLoginInput: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 16,
    color: dark,
    paddingLeft: 8,
  },

  newLoginInputError: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 16,
    color: inputRed,
  },
  checkboxBox: {
    width: 20,
    height: 20,
    backgroundColor: "white",
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },

  // Blue login button
  newLoginButton: {
    backgroundColor: blue,
    borderRadius: 24,
    paddingVertical: 16,
    alignItems: "center",
    marginBottom: 80,
  },
  newLoginButtonText: {
    color: light,
    fontFamily: nunitoBold,
    fontSize: 16,
  },

  // Footer (register link) at the bottom
  newLoginFooter: {
    position: "absolute",
    bottom: 40,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "center",
  },
  footerQuestion: {
    color: dark,
    fontFamily: nunito,
    fontSize: 16,
  },
  footerLink: {
    color: blue,
    fontFamily: nunito,
    fontSize: 16,
  },
  errorTextUnderField: {
    color: inputRed,
    fontSize: 16,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: -10,
  },
  successText: {
    backgroundColor: blue,
    color: light,
    fontSize: 16,
  },
});

export default RegisterScreen;
