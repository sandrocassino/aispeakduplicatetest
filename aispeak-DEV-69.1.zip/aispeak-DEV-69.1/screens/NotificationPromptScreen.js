import React, { useState } from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import styles from "../Styles";
import { light, dark } from "../constants";

export default function NotificationPromptScreen({
  showfirst2,
  setShowfirst2,
  showfirst,
  setShowfirst,
  showsecond,
  setShowsecond,
  showthird,
  setShowthird,
  showfourth,
  setShowfourth,
  showfifth,
  setShowfifth,
  showPopup,
  setShowPopup,
  showText72,
  setShowText72,
  showText73,
  setShowText73,
  showImage72,
  setShowImage72,
  showFinger2,
  setShowFinger2,
  showButton,
  setShowButton,
  screenHeight,
  showSecond2,
  setShowsecond2,
  askForPermissions,
  setPage,
}) {
  return (
    <View style={styles.container}>
      <Image
        style={{
          width: 30,
          height: 30,
          position: "absolute",
          top: 250,
          left: 320,
          resizeMode: "contain",
        }}
        source={require("../assets/icons/black-1-circle-no-bg.png")}
      />

      {showfirst2 && (
        <TouchableOpacity
          onPress={() => {
            setShowButton(true);
            setShowfirst2(false);
          }}
          style={{
            position: "absolute",
            bottom: screenHeight <= 667 ? 15 : 160,
            alignSelf: "center",
            borderRadius: 10,
            backgroundColor: light,
            borderWidth: 1,
            borderColor: light,
            paddingVertical: -2.5,
            paddingHorizontal: 30,
          }}
        >
          <Text
            style={{
              color: dark,
              paddingVertical: 10,
              paddingHorizontal: 20,
              fontSize: 18,
            }}
          >
            No gracias
          </Text>
        </TouchableOpacity>
      )}

      {showfirst && (
        <Image
          style={{
            width: 200,
            height: 200,
            position: "absolute",
            top: 350,
            left: 100,
            resizeMode: "contain",
          }}
          source={require("../assets/icons/white-circle-no-bg-hd.png")}
        />
      )}
      {showsecond && (
        <TouchableOpacity
          onPress={() => {
            askForPermissions();
            setShowButton(true);
            setShowfirst2(false);
          }}
        >
          <Image
            style={{
              width: 85,
              height: 85,
              position: "absolute",
              top: 380,
              left: 135,
              resizeMode: "contain",
            }}
            source={require("../assets/images/girl-typing-on-computer-with-cat.gif")}
          />
          <Image
            style={{
              width: 70,
              height: 70,
              position: "absolute",
              top: 460,
              left: 160,
              resizeMode: "contain",
            }}
            source={require("../assets/images/finger-tapping.gif")}
          />
        </TouchableOpacity>
      )}

      {showfourth && (
        <Image
          style={{
            width: 40,
            height: 40,
            position: "absolute",
            top: 330,
            left: "27%",
            resizeMode: "contain",
          }}
          source={require("../assets/icons/white-3-dots-blue-bubble-bg.png")}
        />
      )}
      {showfifth && (
        <Image
          style={{
            width: 30,
            height: 30,
            position: "absolute",
            top: 430,
            left: 280,
            resizeMode: "contain",
          }}
          source={require("../assets/icons/black-2-circle-no-bg.png")}
        />
      )}
      {showthird && (
        <Image
          style={{
            width: 60,
            height: 60,
            position: "absolute",
            top: 360,
            right: "80%",
          }}
          source={require("../assets/images/capy-in-white-circle-yellow-bg.png")}
        />
      )}
      {showPopup && (
        <View
          style={{
            flex: 1,
            alignItems: "center",
            position: "absolute",
            top: 600,
            left: 0,
            right: 0,
            bottom: 0,
          }}
        >
          <View
            style={{
              backgroundColor: light,
              padding: 20,
              borderRadius: 10,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                textAlign: "center",
              }}
            >
              Accept notifications?
            </Text>
            <TouchableOpacity
              onPress={askForPermissions}
              style={{
                marginTop: 20,
                backgroundColor: dark,
                borderRadius: 10,
              }}
            >
              <Text
                style={{
                  color: light,
                  paddingVertical: 10,
                  paddingHorizontal: 20,
                  textAlign: "center",
                }}
              >
                Accept
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <TouchableOpacity
        onPress={() => {
          setShowText72(false);
          setShowImage72(false);
          setTimeout(() => {
            setShowText73(true);
            setShowImage72(true);
          }, 500);
          setShowFinger2(false);
          setShowthird(true);
          setShowsecond(true);
          setShowsecond2(true);
          setShowfourth(true);
          setShowfirst(true);
          setShowfirst2(true);
          setShowfifth(true);
        }}
      >
        <Image
          style={{
            width: 125,
            height: 125,
            position: "absolute",
            top: 170,
            left: 180,
          }}
          source={require("../assets/images/capy.png")}
        />
        {showFinger2 && (
          <Image
            source={require("../assets/images/finger-tapping.gif")}
            style={{
              width: 70,
              height: 70,
              position: "absolute",
              top: 240,
              left: 240,
              resizeMode: "contain",
              zIndex: 10,
            }}
          />
        )}
      </TouchableOpacity>
      {/* Image components */}

      {showImage72 && (
        <Image
          source={require("../assets/icons/white-square-bubble-no-bg.png")}
          style={[
            styles.image44,
            {
              position: "absolute",
              top: 50,
              left: 10,
              resizeMode: "contain",
            },
          ]}
        />
      )}

      {showText72 && (
        <View style={{ position: "absolute", top: 90, left: 40 }}>
          <Text
            style={[
              styles.text3,
              {
                fontSize: 15,
                fontWeight: "bold",
                alignSelf: "center",
                marginBottom: 15,
              },
            ]}
          >
            Hola de nuevo!{"\n"}Hay una otra{"\n"}cosa que{"\n"}debemos hacer!
          </Text>
        </View>
      )}
      {showText73 && (
        <View style={{ position: "absolute", top: 90, left: 25 }}>
          <Text
            style={[
              styles.text3,
              {
                fontSize: 15,
                fontWeight: "bold",
                alignSelf: "center",
                marginBottom: 15,
              },
            ]}
          >
            Acepta notificaciones{"\n"}para que pueda{"\n"}enviarte mensajes de
            {"\n"}chat por mi cuenta.
          </Text>
        </View>
      )}

      {showButton ? (
        <TouchableOpacity
          onPress={async () => {
            console.log("Button pressed");
            try {
              await schedulePushNotification();
              console.log("Notification scheduled");
            } catch (error) {
              console.error("Error scheduling notification:", error);
            }
            try {
              setPage(121);
              setFirstClick(true);
              console.log("Page set");
            } catch (error) {
              console.error("Error setting page:", error);
            }
          }}
          style={{
            position: "absolute",
            bottom: screenHeight <= 667 ? 15 : 115,
            alignSelf: "center",
            borderRadius: 10,
            borderWidth: 1,
            borderColor: dark,
            paddingVertical: -2.5,
            paddingHorizontal: 30,
          }}
        >
          <Text
            style={{
              color: dark,
              paddingVertical: 10,
              paddingHorizontal: 20,
              fontSize: 18,
            }}
          >
            Continuar
          </Text>
        </TouchableOpacity>
      ) : (
        console.log("showButton is false")
      )}
    </View>
  );
}
