import { View, Image, Text, TouchableOpacity, ScrollView } from "react-native";
import styles from "./Styles";
import "react-native-url-polyfill/auto";
import "react-native-gesture-handler";
import { dark } from "./constants.js";

export default function LegalScreens({ page, setPage, originPage }) {
  if (page === 4210) {
    return (
      <View style={styles.container}>
        <View style={styles.rectanglenewer}>
          {/* Wrap the Text component in a ScrollView */}
          <ScrollView contentContainerStyle={{ padding: 10 }}>
            <Text style={styles.titlenewer}>
              Aispeak concede gran importancia a la privacidad de sus datos.
            </Text>
            <Text style={styles.textnewer}>
              Nuestro objetivo es enseñar un idioma a nuestros clientes, no
              hacer nada más con sus datos o información. Es por eso que sólo
              utilizamos la información de tus chats para:
              {"\n"}• Para corregir errores/errores o fallos en nuestra
              aplicación
              {"\n"}Nunca compartiremos la información de sus chats fuera de
              nuestro equipo por ningún motivo que no sea el indicado
              anteriormente.
              {"\n"}Entendemos la impresión que la inteligencia artificial a
              veces deja en las personas y es por eso que apoyamos firmemente
              que toda la información que nos dejes sea súper segura.
              {"\n\n"}Saludos,{"\n"}El equipo de Aipeak
            </Text>
          </ScrollView>
        </View>

        <TouchableOpacity
          onPress={() => setPage(originPage)}
          style={{
            borderColor: dark,
            borderWidth: 1.8,
            paddingVertical: 4, // Adjust vertical padding
            paddingHorizontal: 10, // Horizontal padding
            borderRadius: 5,
            flexDirection: "column", // Stack vertically
            alignItems: "center",
            marginBottom: 30,
            position: "absolute",
            top: 124,
            right: 30,
            justifyContent: "center",
            height: 45,
            width: 90,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "bold",
              color: dark,
              marginBottom: -6,
              textAlign: "center",
            }}
          >
            Volver
          </Text>
          <Image
            source={require("./assets/icons/transparent-arrow-right-black-bg.png")}
            style={{
              width: 20,
              height: 21,
              transform: [{ scaleX: -1 }],
              marginTop: 2,
            }}
          />
        </TouchableOpacity>
      </View>
    );
  } else if (page === 4211) {
    return (
      <View style={styles.container}>
        <View style={styles.rectanglenewer}>
          {/* Wrap the Text component in a ScrollView */}
          <ScrollView contentContainerStyle={{ padding: 10 }}>
            <Text style={styles.titlenewer}>Política de privacidad</Text>
            <Text style={styles.textnewer}>
              Última actualización: 26 de noviembre de 2024
            </Text>

            <Text style={styles.titlenewer}>Introducción</Text>
            <Text style={styles.textnewer}>
              ¡Bienvenido a Aispeak! Esta Política de privacidad, propiedad de
              Aispeak, determina cómo procesamos la información recopilada a
              través de nuestra aplicación móvil de aprendizaje de inglés (la
              "Aplicación") y nuestro sitio web aispeakapp.com. Te recomendamos
              leer esta Política de privacidad antes de usar nuestros servicios.
            </Text>

            <Text style={styles.titlenewer}>Alcance</Text>
            <Text style={styles.textnewer}>
              Esta política se aplica principalmente a nuestra Aplicación móvil.
              Nuestro sitio web aispeakapp.com funciona únicamente como página
              informativa y de redirección a las tiendas de aplicaciones.
            </Text>

            <Text style={styles.titlenewer}>Información que Recopilamos</Text>
            <Text style={styles.textnewer}>
              En la Aplicación Móvil Recopilamos y almacenamos únicamente:
              {"\n"}• Correo electrónico (solo si eliges iniciar sesión)
              {"\n"}• Nombre de usuario (solo si eliges iniciar sesión)
              {"\n"}• Progreso del nivel de aprendizaje (solo si eliges iniciar
              sesión)
            </Text>

            <Text style={styles.titlenewer}>En el Sitio Web</Text>
            <Text style={styles.textnewer}>
              Cuando visitas aispeakapp.com, podemos recopilar automáticamente:
              {"\n"}• Información básica del dispositivo
              {"\n"}• Dirección IP
              {"\n"}• Zona horaria
              {"\n"}• Información básica de navegación
            </Text>

            <Text style={styles.titlenewer}>
              Cómo Utilizamos tu Información
            </Text>
            <Text style={styles.textnewer}>
              Utilizamos tu información exclusivamente para:
              {"\n"}• Mantener tu progreso de aprendizaje
              {"\n"}• Permitir el acceso a tus datos guardados en diferentes
              dispositivos
              {"\n"}• Proporcionar nuestros servicios educativos principales
              {"\n"}• Autenticación de cuenta
              {"\n"}• Seguridad y prevención de fraude
              {"\n\n"}NO realizamos:
              {"\n"}• Uso de tus datos para fines de marketing
              {"\n"}• Compartición o venta de tus datos a terceros
              {"\n"}• Seguimiento de tu comportamiento o creación de perfiles de
              usuario
              {"\n"}• Almacenamiento de tus conversaciones con nuestro asistente
              AI capybara
            </Text>

            <Text style={styles.titlenewer}>Seguridad de la Información</Text>
            <Text style={styles.textnewer}>
              {"\n"}• Todos los datos se almacenan de forma segura utilizando
              cifrado estándar
              {"\n"}• Las conversaciones con nuestro asistente de IA se procesan
              en tiempo real y no se almacenan
              {"\n"}• Mantenemos medidas de seguridad administrativas, técnicas
              y físicas razonables
              {"\n"}• Los datos se almacenan en un entorno controlado y seguro
            </Text>

            <Text style={styles.titlenewer}>Tus Derechos</Text>
            <Text style={styles.textnewer}>
              Tienes los siguientes derechos sobre tus datos personales:
              {"\n"}• El derecho a ser informado
              {"\n"}• El derecho de acceso
              {"\n"}• El derecho a la rectificación
              {"\n"}• El derecho a borrar
              {"\n"}• El derecho a restringir el procesamiento
              {"\n"}• El derecho a la portabilidad de datos
              {"\n"}• El derecho a oponerte
              {"\n"}• Derechos en relación con la toma de decisiones
              automatizada
            </Text>

            <Text style={styles.titlenewer}>Enlaces a Otros Sitios Web</Text>
            <Text style={styles.textnewer}>
              No somos responsables de las prácticas de privacidad de sitios web
              de terceros. Te recomendamos leer las políticas de privacidad de
              otros sitios web que visites.
            </Text>

            <Text style={styles.titlenewer}>Divulgación Legal</Text>
            <Text style={styles.textnewer}>
              Divulgaremos información cuando:
              {"\n"}• Sea requerido por ley
              {"\n"}• Sea necesario para cumplir con procesos legales
              {"\n"}• Sea necesario para proteger nuestros derechos o tu
              seguridad
              {"\n"}• Sea necesario para investigar fraude
            </Text>

            <Text style={styles.titlenewer}>Contacto</Text>
            <Text style={styles.textnewer}>
              Si tienes preguntas sobre esta Política o sobre tus derechos
              individuales, puedes contactarnos en: Contact@aispeakapp.com
            </Text>
          </ScrollView>
        </View>

        <TouchableOpacity
          onPress={() => setPage(originPage)}
          style={{
            borderColor: dark,
            borderWidth: 1.8,
            paddingVertical: 4,
            paddingHorizontal: 10,
            borderRadius: 5,
            flexDirection: "column",
            alignItems: "center",
            marginBottom: 30,
            position: "absolute",
            top: 124,
            right: 30,
            justifyContent: "center",
            height: 45,
            width: 90,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "bold",
              color: dark,
              marginBottom: -6,
              textAlign: "center",
            }}
          >
            Volver
          </Text>
          <Image
            source={require("./assets/icons/transparent-arrow-right-black-bg.png")}
            style={{
              width: 20,
              height: 21,
              transform: [{ scaleX: -1 }],
              marginTop: 2,
            }}
          />
        </TouchableOpacity>
      </View>
    );
  } else if (page === 4212) {
    return (
      <View style={styles.container}>
        <View style={styles.rectanglenewer}>
          {/* Wrap the Text component in a ScrollView */}
          <ScrollView contentContainerStyle={{ padding: 10 }}>
            <Text style={styles.titlenewer}>Términos y condiciones</Text>
            <Text style={styles.textnewer}>
              Última actualización: 26 de noviembre de 2024
            </Text>

            <Text style={styles.titlenewer}>Introducción</Text>
            <Text style={styles.textnewer}>
              ¡Bienvenido a Aispeak! Estos términos y condiciones describen las
              reglas y regulaciones para el uso tanto de la aplicación móvil
              Aispeak (la "Aplicación") como del sitio web ubicado en
              https://aispeakapp.com/.
              {"\n"}Al utilizar nuestra Aplicación o acceder a nuestro Sitio
              Web, asumimos que aceptas estos términos y condiciones. No
              continúes usando Aispeak si no estás de acuerdo con todos los
              términos y condiciones establecidos en esta página.
            </Text>

            <Text style={styles.titlenewer}>Servicios</Text>
            <Text style={styles.textnewer}>
              Aplicación Móvil
              {"\n"}• La Aplicación proporciona servicios de aprendizaje del
              idioma inglés a través de la interacción con nuestro asistente de
              IA (Aispeak el capybara)
              {"\n"}• El asistente de IA es únicamente para fines educativos
              {"\n"}• El seguimiento del progreso de aprendizaje está disponible
              para usuarios registrados
            </Text>

            <Text style={styles.titlenewer}>Sitio Web</Text>
            <Text style={styles.textnewer}>
              El Sitio Web funciona principalmente como punto de información y
              redirección a las tiendas de aplicaciones donde puedes descargar
              la Aplicación.
            </Text>

            <Text style={styles.titlenewer}>Cuentas de Usuario</Text>
            <Text style={styles.textnewer}>
              • La creación de cuenta es opcional
              {"\n"}• Si decides crear una cuenta, eres responsable de mantener
              la confidencialidad de tus credenciales
              {"\n"}• Debes proporcionar información precisa y completa al crear
              una cuenta
            </Text>

            <Text style={styles.titlenewer}>Propiedad Intelectual</Text>
            <Text style={styles.textnewer}>
              Aispeak y/o sus licenciantes poseen los derechos de propiedad
              intelectual de todo el material en Aispeak. Todos los derechos de
              propiedad intelectual están reservados. Esto incluye, pero no se
              limita a:
              {"\n"}• El asistente de IA y sus respuestas
              {"\n"}• El personaje Aispeak el capybara y toda la marca
              relacionada
              {"\n"}• Contenido educativo y materiales de aprendizaje
              {"\n"}• Diseños, gráficos e interfaces
            </Text>

            <Text style={styles.textnewer}>
              No debes:
              {"\n"}• Copiar o volver a publicar material de Aispeak
              {"\n"}• Vender, alquilar o sublicenciar material de Aispeak
              {"\n"}• Reproducir, duplicar o copiar material de Aispeak
              {"\n"}• Redistribuir contenido de Aispeak
              {"\n"}• Intentar acceder al código fuente o algoritmos de la
              Aplicación
            </Text>

            <Text style={styles.titlenewer}>Uso Aceptable</Text>
            <Text style={styles.textnewer}>
              Te comprometes a no:
              {"\n"}• Utilizar la Aplicación o el Sitio Web para cualquier
              propósito ilegal
              {"\n"}• Intentar eludir o manipular nuestros sistemas
              {"\n"}• Compartir credenciales de cuenta con otros
              {"\n"}• Subir contenido dañino o malware
              {"\n"}• Acosar, abusar o dañar a otros a través de nuestros
              servicios
              {"\n"}• Intentar interferir con el funcionamiento del asistente de
              IA
            </Text>

            <Text style={styles.titlenewer}>
              Enlaces y Sitios Web de Terceros
            </Text>
            <Text style={styles.textnewer}>
              • No somos responsables del contenido de sitios web externos
              {"\n"}• Los enlaces a nuestro Sitio Web están permitidos siempre
              que el enlace no sea engañoso
              {"\n"}• Las organizaciones pueden enlazar a nuestro Sitio Web
              siempre que no implique falsamente patrocinio o aprobación
            </Text>

            <Text style={styles.titlenewer}>Cookies</Text>
            <Text style={styles.textnewer}>
              El Sitio Web utiliza cookies para:
              {"\n"}• Mejorar la experiencia del usuario
              {"\n"}• Recopilar información estadística básica
              {"\n"}• Facilitar funciones técnicas necesarias
            </Text>

            <Text style={styles.titlenewer}>Modificaciones del Servicio</Text>
            <Text style={styles.textnewer}>
              Nos reservamos el derecho a:
              {"\n"}• Modificar o descontinuar la Aplicación o el Sitio Web en
              cualquier momento
              {"\n"}• Actualizar estos términos con aviso razonable
              {"\n"}• Cambiar características o funcionalidad
              {"\n"}• Modificar el asistente de IA y sus capacidades
            </Text>

            <Text style={styles.titlenewer}>Limitación de Responsabilidad</Text>
            <Text style={styles.textnewer}>
              No seremos responsables por:
              {"\n"}• Cualquier interrupción en el servicio
              {"\n"}• Errores o imprecisiones en las respuestas del asistente de
              IA
              {"\n"}• Pérdida de datos o daños indirectos
              {"\n"}• La precisión o disponibilidad continua del contenido
              educativo
            </Text>

            <Text style={styles.titlenewer}>Terminación</Text>
            <Text style={styles.textnewer}>
              Podemos terminar o suspender el acceso a nuestros servicios por:
              {"\n"}• Violación de estos términos
              {"\n"}• Actividad sospechosa de fraude
              {"\n"}• Cualquier otra razón que consideremos apropiada
            </Text>

            <Text style={styles.titlenewer}>Ley Aplicable</Text>
            <Text style={styles.textnewer}>
              Estos términos se regirán e interpretarán de acuerdo con las leyes
              de [Insertar jurisdicción aplicable].
            </Text>

            <Text style={styles.titlenewer}>Contacto</Text>
            <Text style={styles.textnewer}>
              Si tienes preguntas sobre estos Términos y Condiciones, puedes
              contactarnos en: Contact@aispeakapp.com
            </Text>
          </ScrollView>
        </View>

        <TouchableOpacity
          onPress={() => setPage(originPage)}
          style={{
            borderColor: dark,
            borderWidth: 1.8,
            paddingVertical: 4,
            paddingHorizontal: 10,
            borderRadius: 5,
            flexDirection: "column",
            alignItems: "center",
            marginBottom: 30,
            position: "absolute",
            top: 124,
            right: 30,
            justifyContent: "center",
            height: 45,
            width: 90,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "bold",
              color: dark,
              marginBottom: -6,
              textAlign: "center",
            }}
          >
            Volver
          </Text>
          <Image
            source={require("./assets/icons/transparent-arrow-right-black-bg.png")}
            style={{
              width: 20,
              height: 21,
              transform: [{ scaleX: -1 }],
              marginTop: 2,
            }}
          />
        </TouchableOpacity>
      </View>
    );
  }
}
