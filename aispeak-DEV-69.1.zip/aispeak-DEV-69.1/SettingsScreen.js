// SettingsScreen.js

import "react-native-url-polyfill/auto";
import {
  StyleSheet,
  View,
  Image,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import { Linking } from "react-native";
import { Switch } from "react-native";
import { Alert, Dimensions } from "react-native";
import "react-native-gesture-handler";
import {
  light,
  dark,
  lightBlue,
  lightGray,
  gray,
  darkGray,
  black,
  yellow,
} from "./constants";

export default function SettingsScreen(props) {
  // Destructure everything you need from props:
  const {
    setPage,
    setOriginPage,
    notificationsEnabled,
    askForPermissions,
    schedulePushNotification,
    isLoggedIn,
    setIsLoggedIn,
    isPopupVisible,
    setPopupVisible,
    currentPage,
    setEmail,
    setPassword,
    setName,
    setActiveField,
    setPasswordError,
    setEmailError,
    setNameError,
  } = props;

  // If you want local dimension logic:
  const { width: screenWidth, height: screenHeight } = Dimensions.get("window");
  const ratio = screenHeight / screenWidth;
  const scaleFactor = ratio < 1.9 ? 0.6 : 1.0;

  const navigateToSubscription = () => {
    setPage(4000, currentPage); // Returning to origin page, 'Configuracion' page
  };

  const handleLogoutConfirm = () => {
  setIsLoggedIn(false);
  setName("");
  setEmail("");
  setPassword("");
  setPage(122.1);
};

  return (
    <View
      style={[styles.container, { backgroundColor: yellow, paddingTop: 120 }]}
    >
      <View style={{ flex: 1, marginTop: screenHeight <= 736 ? -70 : 0 }}>
        {screenHeight > 896 && (
          <Image
            source={require("./assets/images/old-logo-and-brand.png")}
            style={{
              width: 150,
              height: 150,
              marginLeft: 130,
              marginBottom: 10,
              marginTop: -100,
              resizeMode: "contain",
            }}
          />
        )}

        {/* “Inicio” button (top-right corner) */}
        <TouchableOpacity
          onPress={() => setPage(7)}
          style={{
            borderColor: dark,
            borderWidth: 1.8,
            paddingVertical: 4,
            paddingHorizontal: 10,
            borderRadius: 5,
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            position: "absolute",
            right: 30,
            zIndex: 3,
            height: 45,
            width: 75,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "bold",
              color: dark,
              marginBottom: -6,
              textAlign: "center",
            }}
          >
            Inicio
          </Text>

          <Image
            source={require("./assets/icons/transparent-arrow-right-black-bg.png")}
            style={{
              width: 20,
              height: 21,
              transform: [{ scaleX: -1 }],
              marginTop: 2,
            }}
          />
        </TouchableOpacity>

        {/* “Configuración” label inside an oval */}
        <View
          style={{
            alignSelf: "flex-start",
            paddingHorizontal: 18,
            paddingVertical: 8,
            marginLeft: -30,
            marginHorizontal: 20,
            marginBottom: 20,
            backgroundColor: light,
            borderRadius: 50,
            paddingLeft: 50,
          }}
        >
          <Text style={{ fontSize: 26, fontWeight: "bold", color: dark }}>
            Configuración
          </Text>
        </View>

        {/* CUENTA */}
        <TouchableOpacity onPress={() => setPage(125)}>
          <View style={styles.rowContainer}>
            <View style={styles.optionBubble}>
              <Text style={{ fontSize: 18 }}>Cuenta</Text>
            </View>
            <Text style={styles.rowRightArrow}>{">"}</Text>
          </View>
        </TouchableOpacity>

        {/* NOTIFICACIONES */}
        <View style={styles.rowContainer}>
          <View style={styles.optionBubble}>
            <Text style={{ fontSize: 18 }}>Notificaciones</Text>
          </View>
          <Switch
            trackColor={{ false: darkGray, true: lightBlue }}
            thumbColor={props.notificationsEnabled ? black : lightGray}
            ios_backgroundColor={darkGray}
            onValueChange={async () => {
              if (notificationsEnabled) {
                Alert.alert(
                  "Desactivar las notificaciones",
                  "Para desactivar las notificaciones, vaya a la configuración de su dispositivo.",
                  [{ text: "OK", onPress: () => console.log("OK Pressed") }]
                );
              } else {
                const permission = await askForPermissions();
                if (permission.status === "granted") {
                  schedulePushNotification();
                }
              }
            }}
            value={notificationsEnabled}
          />
        </View>

        {/* PRIVACIDAD */}
        <TouchableOpacity
          onPress={() => {
            setPage(4210);
            setOriginPage(9); // 9 is the SettingsScreen page code
          }}
        >
          <View style={styles.rowContainer}>
            <View style={styles.optionBubble}>
              <Text style={{ fontSize: 18 }}>Privacidad</Text>
            </View>
            <Text style={styles.rowRightArrow}>{">"}</Text>
          </View>
        </TouchableOpacity>

        {/* CAMBIAR TU PLAN DE SUSCRIPCIÓN */}
        <TouchableOpacity onPress={navigateToSubscription}>
          <View style={styles.rowContainer}>
            <View style={styles.optionBubble}>
              <Text style={{ fontSize: 18 }}>
                Cambiar tu plan de suscripción
              </Text>
            </View>
            <Text style={styles.rowRightArrow}>{">"}</Text>
          </View>
        </TouchableOpacity>

        {/* CONTACTA CON NOSOTROS (opens external link) */}
        <TouchableOpacity
          onPress={() => Linking.openURL("https://www.aispeakapp.com/contacto")}
        >
          <View style={[styles.rowContainer, { borderBottomWidth: 1 }]}>
            <View style={styles.optionBubble}>
              <Text style={{ fontSize: 18 }}>Contacta con nosotros</Text>
            </View>
            <Text style={styles.rowRightArrow}>{">"}</Text>
          </View>
        </TouchableOpacity>

        {/* Combined bottom row: Términos, Login/Logout, Política */}
        <View style={styles.bottomRowContainer}>
          <TouchableOpacity
            onPress={() => {
              setPage(4212); // set the page
              setOriginPage(9); // set the origin page to settings
            }}
            style={{ width: "30%", zIndex: 10, alignItems: "center" }}
          >
            <Text style={{ fontSize: 12 * scaleFactor, textAlign: "center" }}>
              Términos y{"\n"}condiciones
            </Text>
          </TouchableOpacity>

          {/* Botón Iniciar/Cerrar sesión */}
          <TouchableOpacity
            style={{
              width: "40%",
              paddingVertical: "2%",
              height: 50,
              backgroundColor: light,
              borderWidth: 2,
              borderColor: dark,
              borderRadius: 400,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => {
              if (isLoggedIn) {
                setPopupVisible(true);
              } else {
                handleLogoutConfirm()
              }
            }}
          >
            <Text style={{ fontSize: 15 }}>
              {isLoggedIn ? "Cerrar sesión" : "Iniciar sesión"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              setPage(4211); // set the page
              setOriginPage(9); // set the origin page to settings
            }}
            style={{ width: "30%", zIndex: 10, alignItems: "center" }}
          >
            <Text style={{ fontSize: 12 * scaleFactor, textAlign: "center" }}>
              Política de{"\n"}privacidad
            </Text>
          </TouchableOpacity>
        </View>

        {/* The “Are you sure you want to log out?” popup */}
        {isPopupVisible && (
          <View style={styles.popupContainer}>
            <View style={styles.popupContent}>
              <Text style={{ color: dark, marginBottom: 10 }}>
                ¿Estás seguro de que quieres cerrar sesión?
              </Text>
              <Text style={{ color: gray, marginBottom: 20 }}>
                Si cierra sesión, sus datos ya no se guardarán.
              </Text>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <TouchableOpacity
                  style={{
                    backgroundColor: dark,
                    padding: 10,
                    borderRadius: 5,
                  }}
                  onPress={() => {
                    setIsLoggedIn(false);
                    setPopupVisible(false);
                  }}
                >
                  <Text style={{ color: light }}>Sí</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={{
                    backgroundColor: dark,
                    padding: 10,
                    borderRadius: 5,
                  }}
                  onPress={() => setPopupVisible(false)}
                >
                  <Text style={{ color: light }}>No</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    marginLeft: -5,
    marginTop: 20,
    borderTopWidth: 1,
  },
  optionBubble: {
    backgroundColor: light,
    borderRadius: 50,
    paddingHorizontal: 18,
    paddingVertical: 8,
    ...Platform.select({
      ios: {
        shadowColor: dark,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 5,
      },
    }),
  },
  rowRightArrow: {
    fontSize: 24,
    color: light,
    fontWeight: "bold",
    marginRight: 18,
  },
  bottomRowContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: "5%",
    flex: 1,
    justifyContent: "flex-end",
  },
  popupContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  popupContent: {
    padding: 20,
    backgroundColor: light,
    borderRadius: 10,
    width: "80%",
  },
});
