// Colors 
export const light = '#F8F9FA'
export const dark = '#2B2929'

export const lightGray = '#F2F2F2'
export const gray = '#D1D1D1'
export const darkGray = '#595959'
export const textGray = '#615E5A'

export const newGray = '#615E5A'

export const yellow = '#FFC84A'
export const brown = '#774505'

export const veryLightBlue = '#F3F9FF'
export const lightBlue = '#D4E9FF'
export const blue = '#017CFE'
export const darkBlue = '#075AB2'

export const veryLightRed = '#F0D4D4'
export const lightRed = '#CA9492'
export const red = '#E53935'
export const darkRed = '#AD2B28'
export const inputRed = '#C62828'

export const green = '#2E7D32'


// Fonts
export const nunitoBlack = 'NunitoBlack';
export const nunitoBold = 'NunitoBold' // For titles and headings
export const nunito = 'NunitoRegular'

export const sourceSansBold = 'SourceSans-Bold' // For bold body text
export const sourceSans = 'SourceSans' // For body text